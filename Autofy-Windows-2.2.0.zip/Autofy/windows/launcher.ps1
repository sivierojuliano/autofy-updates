﻿# Autofy - iniciador para Windows.
# Inicia o servidor em segundo plano (sem janela) e abre o painel no navegador.
# Se o Autofy já estiver aberto, apenas reabre o painel. Para encerrar, use o botão Encerrar do painel.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$title = 'Autofy'
function Show-Message([string]$text, [string]$icon = 'Warning', [string]$buttons = 'OK') {
  return [System.Windows.Forms.MessageBox]::Show($text, $title, $buttons, $icon)
}
function Test-Node([string]$path) {
  try {
    $version = & $path -p "process.versions.node" 2>$null
    if ($LASTEXITCODE -eq 0 -and "$version" -match '^(\d+)\.') { return ([int]$Matches[1] -ge 22) }
  } catch {}
  return $false
}

try {
  $root = Split-Path -Parent $PSScriptRoot
  $start = Join-Path $root 'start.mjs'
  if (-not (Test-Path -LiteralPath $start)) {
    Show-Message 'Não encontrei o arquivo start.mjs. Extraia o ZIP inteiro e mantenha todos os arquivos juntos na mesma pasta.' | Out-Null
    exit 1
  }
  # Dentro do OneDrive (ou outra nuvem) a sincronização mexe nos arquivos e o painel deixa de abrir.
  if ($root -match '(?i)\\(OneDrive|Dropbox|Google Drive|iCloudDrive)') {
    Show-Message ("O Autofy está dentro do OneDrive (ou outra nuvem):`n`n$root`n`nAssim ele não funciona: a nuvem mexe nos arquivos enquanto sincroniza.`n`nO que fazer:`n1. Clique em OK.`n2. Clique com o botão direito no ZIP e escolha 'Extrair tudo...'.`n3. Na caixa da pasta, apague tudo e digite exatamente:  C:\Autofy`n4. Abra a pasta C:\Autofy\Autofy e dê dois cliques em 'Criar atalho na Area de Trabalho.bat'.`n5. Abra pelo ícone novo da Área de Trabalho.") | Out-Null
    exit 1
  }
  $dataDir = Join-Path $env:LOCALAPPDATA 'JSAutopost'
  $logDir = Join-Path $dataDir 'logs'
  New-Item -ItemType Directory -Force -Path $logDir | Out-Null

  # 1) Node.js: usa o da pasta runtime, depois o instalado no Windows; se não houver, oferece baixar.
  $runtimeDir = Join-Path $root 'runtime'
  $runtime = Join-Path $runtimeDir 'node.exe'
  $node = $null
  if ((Test-Path -LiteralPath $runtime) -and (Test-Node $runtime)) { $node = $runtime }
  if (-not $node) {
    $installed = Get-Command node.exe -ErrorAction SilentlyContinue
    if ($installed -and (Test-Node $installed.Source)) { $node = $installed.Source }
  }
  if (-not $node) {
    $answer = Show-Message "O Autofy precisa do Node.js 22 ou superior, que não foi encontrado neste computador.`n`nBaixar agora a versão oficial (nodejs.org, cerca de 80 MB) para dentro da pasta do Autofy?`n`nNada é instalado no Windows. O download pode levar alguns minutos e o painel abre sozinho no final." 'Question' 'YesNo'
    if ("$answer" -ne 'Yes') {
      Show-Message 'Sem o Node.js o Autofy não abre. Você também pode instalar o Node.js 22 LTS ou superior em https://nodejs.org/pt/download e abrir de novo.' | Out-Null
      exit 1
    }
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $base = 'https://nodejs.org/dist/latest-v22.x'
    New-Item -ItemType Directory -Force -Path $runtimeDir | Out-Null
    $part = Join-Path $runtimeDir 'node.exe.part'
    $client = New-Object System.Net.WebClient
    try {
      $sums = $client.DownloadString("$base/SHASUMS256.txt")
      $line = ($sums -split "`n") | Where-Object { $_ -match '\swin-x64/node\.exe\s*$' } | Select-Object -First 1
      $expected = if ($line) { (($line.Trim()) -split '\s+')[0].ToLower() } else { '' }
      $client.DownloadFile("$base/win-x64/node.exe", $part)
    } finally { $client.Dispose() }
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $part).Hash.ToLower()
    if (-not $expected -or $actual -ne $expected) {
      Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
      Show-Message 'O download do Node.js não passou na conferência de integridade e foi descartado. Tente de novo ou instale o Node.js manualmente em https://nodejs.org/pt/download.' | Out-Null
      exit 1
    }
    Move-Item -LiteralPath $part -Destination $runtime -Force
    if (-not (Test-Node $runtime)) {
      Show-Message 'O Node.js baixado não pôde ser executado neste computador. Instale o Node.js manualmente em https://nodejs.org/pt/download.' | Out-Null
      exit 1
    }
    $node = $runtime
  }

  # 2) Inicia o servidor sem janela, com o registro em arquivo.
  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $out = Join-Path $logDir "inicio-$stamp.log"
  $err = Join-Path $logDir "inicio-$stamp.erro.log"
  Get-ChildItem -LiteralPath $logDir -Filter 'inicio-*' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -Skip 20 | Remove-Item -Force -ErrorAction SilentlyContinue
  foreach ($name in 'NODE_OPTIONS', 'NODE_PATH', 'PORT') { Remove-Item "Env:$name" -ErrorAction SilentlyContinue }
  $process = Start-Process -FilePath $node -ArgumentList @("`"$start`"", '--background') -WorkingDirectory $root -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err -PassThru
  $null = $process.Handle

  # 3) Espera o painel ficar pronto, ou o processo terminar (já estava aberto, ou deu erro).
  $urlFile = Join-Path $dataDir 'painel-url.json'
  for ($i = 0; $i -lt 80; $i++) {
    Start-Sleep -Milliseconds 500
    if ($process.HasExited) {
      if ($process.ExitCode -ne 0) {
        $tail = ''
        foreach ($file in $out, $err) {
          if (Test-Path -LiteralPath $file) { $tail += ((Get-Content -LiteralPath $file -Tail 4 -Encoding UTF8) -join "`n") + "`n" }
        }
        Show-Message ("Não foi possível abrir o Autofy.`n`n" + $tail.Trim() + "`n`nRegistros: $logDir") | Out-Null
      }
      exit $process.ExitCode
    }
    if (Test-Path -LiteralPath $urlFile) {
      try {
        $info = Get-Content -Raw -LiteralPath $urlFile -Encoding UTF8 | ConvertFrom-Json
        if ($info.pid -eq $process.Id) { exit 0 }
      } catch {}
    }
  }
  exit 0
} catch {
  Show-Message ("Não foi possível abrir o Autofy.`n`n" + $_.Exception.Message) | Out-Null
  exit 1
}
