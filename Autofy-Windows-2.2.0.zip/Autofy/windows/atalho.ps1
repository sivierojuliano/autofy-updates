﻿# Cria o atalho "Autofy" na Área de Trabalho, com o ícone do Autofy.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
try {
  $root = Split-Path -Parent $PSScriptRoot
  $desktop = [Environment]::GetFolderPath('Desktop')
  $shell = New-Object -ComObject WScript.Shell
  $shortcut = $shell.CreateShortcut((Join-Path $desktop 'Autofy.lnk'))
  $shortcut.TargetPath = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $PSScriptRoot 'launcher.ps1') + '"'
  $shortcut.WorkingDirectory = $root
  $shortcut.IconLocation = (Join-Path $PSScriptRoot 'js-autopost.ico')
  $shortcut.WindowStyle = 7
  $shortcut.Description = 'Autofy'
  $shortcut.Save()
  [System.Windows.Forms.MessageBox]::Show('Atalho "Autofy" criado na Área de Trabalho. Se você mover esta pasta de lugar, crie o atalho de novo.', 'Autofy', 'OK', 'Information') | Out-Null
} catch {
  [System.Windows.Forms.MessageBox]::Show('Não foi possível criar o atalho: ' + $_.Exception.Message, 'Autofy', 'OK', 'Warning') | Out-Null
  exit 1
}
