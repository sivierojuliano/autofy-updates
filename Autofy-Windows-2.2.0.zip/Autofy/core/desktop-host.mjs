import { createInterface } from 'node:readline';
import { mkdir, open, readFile, unlink } from 'node:fs/promises';
import { join, resolve, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { createApp } from './server.mjs';

// Private stdin/stdout control channel. There is deliberately no shutdown HTTP endpoint.
export async function acquireDataLock(directory) {
  // Protect newly created per-user data on POSIX; existing directories are preserved.
  await mkdir(directory,{recursive:true,mode:0o700});
  const path=join(directory,'desktop.lock'), nonce=randomUUID();
  for(let attempt=0;attempt<2;attempt++) {
    let handle;
    try { handle=await open(path,'wx',0o600); }
    catch(error) {
      if(error.code!=='EEXIST')throw error;
      let previous;
      try { previous=JSON.parse(await readFile(path,'utf8')); } catch { throw new Error('DATA_LOCK'); }
      if(!Number.isSafeInteger(previous.pid)||previous.pid<1)throw new Error('DATA_LOCK');
      try { process.kill(previous.pid,0); throw new Error('DATA_LOCK'); }
      catch(error) { if(error.code!=='ESRCH')throw new Error('DATA_LOCK'); }
      // Recover only the exact stale lease observed above, never an active process.
      if(await readFile(path,'utf8')!==JSON.stringify(previous))throw new Error('DATA_LOCK');
      await unlink(path); continue;
    }
    try { await handle.writeFile(JSON.stringify({pid:process.pid,nonce})); }
    finally { await handle.close(); }
    return async()=>{
      try { const current=JSON.parse(await readFile(path,'utf8'));if(current.nonce===nonce)await unlink(path); }
      catch(error) { if(error.code!=='ENOENT')throw error; }
    };
  }
  throw new Error('DATA_LOCK');
}
export async function listenDesktop(app,preferred=3032) {
  const listen=port=>new Promise((resolve,reject)=>{
    const fail=error=>{app.server.off('listening',ready);reject(error);};
    const ready=()=>{app.server.off('error',fail);resolve();};
    app.server.once('error',fail);app.server.once('listening',ready);app.server.listen(port,'127.0.0.1');
  });
  try { await listen(preferred); } catch(error) { if(error.code!=='EADDRINUSE')throw error;await listen(0); }
  return 'http://127.0.0.1:'+app.server.address().port+'/';
}
export async function runDesktop({directory,input=process.stdin,output=process.stdout,makeApp=createApp,preferred=3032}={}) {
  if(!directory||!isAbsolute(directory))throw new Error('DATA_PATH');
  const release=await acquireDataLock(directory);
  let app, closing=false, lines, chain=Promise.resolve();
  const emit=value=>output.write(JSON.stringify(value)+'\n');
  let finishing;
  const finish=()=>{
    if(closing)return finishing||Promise.resolve();
    closing=true;
    finishing=(async()=>{lines?.close();input.pause();input.unref?.();try{if(app)await app.close();}finally{await release();}})();
    return finishing;
  };
  try {
    app=await makeApp({directory});
    const url=await listenDesktop(app,preferred);
    lines=createInterface({input,crlfDelay:Infinity});
    lines.on('line',line=>{
      if(line.length>4096||closing)return;
      chain=chain.then(async()=>{
        if(closing)return;
        let command;try {command=JSON.parse(line);}catch{return;}
        if(!command||typeof command.id!=='string'||command.id.length>80)return;
        if(command.command==='status')emit({type:'status',id:command.id,busy:app.isBusy()});
        if(command.command==='shutdown') {
          if(app.isBusy()){emit({type:'busy',id:command.id});return;}
          // closeIfIdle checks again synchronously and blocks new requests before its first await.
          if(!await app.closeIfIdle()){emit({type:'busy',id:command.id});return;}
          emit({type:'stopped',id:command.id});await finish();
        }
      }).catch(async()=>{emit({type:'error',code:'CONTROL_ERROR'});await finish();});
    });
    lines.on('close',()=>{void finish();});
    emit({type:'ready',url});
    return {app,close:finish};
  } catch(error) { await finish();throw error; }
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  try {
    const host=await runDesktop({directory:process.env.PUBLISHER_DATA_DIR});
    for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{void host.close();});
  } catch(error) {
    // Do not serialize arbitrary exception messages, credentials, URLs or stack traces.
    const code=['DATA_LOCK','DATA_PATH'].includes(error.message)?error.message:'START_FAILED';
    process.stdout.write(JSON.stringify({type:'error',code})+'\n');process.exitCode=1;
  }
}
