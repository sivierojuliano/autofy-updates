(() => {
  const el=id=>document.getElementById(id), key=document.querySelector('meta[name=publisher-key]').content;
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const MAX_FILES=100;
  let data={files:[],pages:[]},files=new Set(),pages=new Set(),plan=null,working=false,loaded=false,revision=0,timer,product='all';
  // Conta do Facebook do lote (abas no topo). Cada conta tem a sua pasta carregada, prévia e registro.
  let account='main';try{account=localStorage.getItem('autofy-drive-conta')||'main';}catch{}
  // Páginas que aparecem na lista conforme a chave de produto (ED/WL vem do Miwra; sem produto só entra em Todos).
  const shownPages=()=>data.pages.filter(p=>product==='all'||p.product===product);
  // Página que já recebeu um vídeo do Drive hoje: aparece marcada e não pode ser escolhida até a meia-noite.
  const free=p=>!p.postedToday;
  const hour=value=>value&&Number.isFinite(Date.parse(value))?new Date(value).toLocaleTimeString('pt-BR',{timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit'}):'';
  const blockedSig=()=>JSON.stringify(data.pages.filter(p=>p.postedToday).map(p=>[p.id,p.postedToday.at]));
  const pool=kind=>kind==='files'?data.files:shownPages().filter(free);
  function error(message){el('drive-error').textContent=message||'';el('drive-error').hidden=!message;}
  async function api(path,body){if(body!==undefined)body={...body,account};else path+=(path.includes('?')?'&':'?')+'account='+encodeURIComponent(account);const r=await fetch('/api/drive'+path,{method:body===undefined?'GET':'POST',headers:{'x-publisher-key':key,'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});const result=await r.json();if(r.status===401){location.assign('/login');throw Error('Entre novamente no Autofy.');}if(!r.ok)throw Error(result.error||'Falha ao carregar o Google Drive.');return result;}
  function controls(){
    const busy=working||data.publisherBusy;
    el('drive-load').disabled=busy;
    el('drive-prepare').disabled=busy||!loaded||!files.size||files.size>MAX_FILES||!pages.size;
    el('drive-start').disabled=busy||!plan;
    el('drive-stop').disabled=!data.operation?.running;
    for(const [kind,selected] of [['files',files],['pages',pages]]){
      const selectableCount=kind==='files'?Math.min(MAX_FILES,data[kind].length):pool(kind).length;
      el('drive-all-'+kind).disabled=busy||!loaded||!pool(kind).length;
      el('drive-all-'+kind).checked=Boolean(selected.size&&selected.size===selectableCount);
      el('drive-all-'+kind).indeterminate=Boolean(selected.size&&selected.size<selectableCount);
      el('drive-'+kind).querySelectorAll('input').forEach(input=>{input.disabled=busy||!loaded||input.dataset.blocked==='1'||(kind==='files'&&files.size>=MAX_FILES&&!files.has(input.dataset.id));});
    }
    el('drive-product').disabled=busy||!loaded;
    if(loaded)el('drive-counts').textContent=data.files.length+' vídeo(s) carregado(s) · '+files.size+' de '+MAX_FILES+' permitidos selecionado(s) · '+pages.size+' de '+pool('pages').length+' Página(s) livres selecionada(s)'+(product==='all'?'':' de '+product.toUpperCase())+(shownPages().length-pool('pages').length?' · '+(shownPages().length-pool('pages').length)+' já postada(s) hoje pelo Drive (liberam à meia-noite)':'')+(data.ignored?' · '+data.ignored+' item(ns) ignorado(s): subpastas, outros formatos ou tamanho inválido.':'');
  }
  // Caixas de descrição da prévia (ED e WL). O que o usuário digitou nesta tela não é trocado
  // pelo texto guardado enquanto ele não publicar ou pedir as de Publicações.
  let captionsEdited=false;
  function captions(source){
    if(!captionsEdited){el('drive-caption-ed').value=source.caption||'';el('drive-caption-wl').value=source.captionWl||'';}
    const count=product=>(source.pairs||[]).filter(pair=>(pair.page.product==='wl'?'wl':'ed')===product).length;
    el('drive-caption-ed-count').textContent='· '+count('ed')+' Página(s) neste lote'+(source.noProduct?' ('+source.noProduct+' sem produto, tratadas como ED)':'');
    el('drive-caption-wl-count').textContent='· '+count('wl')+' Página(s) neste lote';
  }
  for(const id of ['drive-caption-ed','drive-caption-wl'])el(id).addEventListener('input',()=>{captionsEdited=true;});
  // Método (Chrome ou API) e comentário: preenchidos uma vez com o guardado; depois valem as caixas desta tela.
  let optionsFilled=false;
  const daysView=()=>{const all=el('drive-comment-scope').value==='all';el('drive-comment-days-box').hidden=all;el('drive-comment-scope-help').hidden=all;};
  const methodView=()=>{const api=el('drive-method').value==='api';el('drive-method-help').hidden=!api;el('drive-comment-help').textContent=api?'Logo depois de a Meta confirmar o Reel, a própria Página comenta nele pela API (o token precisa da permissão pages_manage_engagement). Cada Reel recebe o comentário do produto da Página; caixa vazia, sem comentário. Estes textos valem só para os lotes do Google Drive.':'Depois de cada Postar, a automação espera o Reel aparecer na Página e comenta nele como a Página. Cada Reel recebe o comentário do produto da Página; caixa vazia, sem comentário. Estes textos valem só para os lotes do Google Drive.';};
  function fillOptions(source){
    if(optionsFilled||!source||source.method===undefined)return;optionsFilled=true;
    el('drive-method').value=source.method==='api'?'api':'chrome';
    if(source.apiAvailable===false)el('drive-method').querySelector('option[value="api"]').disabled=true;
    el('drive-comment-on').checked=source.commentOn===true;
    el('drive-comment-ed').value=source.comment||'';el('drive-comment-wl').value=source.commentWl||'';
    el('drive-comment-scope').value=source.commentScope==='all'?'all':'new';el('drive-comment-days').value=String(source.commentMaxDays||7);
    daysView();methodView();
  }
  el('drive-comment-scope').addEventListener('change',daysView);el('drive-method').addEventListener('change',methodView);
  daysView();methodView();
  el('drive-caption-reset').onclick=()=>{const saved=data.captionsFromSettings||{};el('drive-caption-ed').value=saved.caption||'';el('drive-caption-wl').value=saved.captionWl||'';captionsEdited=true;};
  function invalidate(){revision++;plan=null;el('drive-preview').hidden=true;controls();}
  function clearCatalog(message){loaded=false;data.files=[];data.pages=[];files.clear();pages.clear();el('drive-files').innerHTML='<p class="hint">Nenhum vídeo carregado.</p>';el('drive-pages').innerHTML='<p class="hint">Nenhuma Página carregada.</p>';el('drive-product-state').textContent='';el('drive-counts').textContent=message;invalidate();}
  function lists(result){
    data=result;loaded=true;files=new Set(result.files.slice(0,MAX_FILES).map(v=>v.id));pages=new Set();
    el('drive-files').innerHTML=result.files.map(v=>'<label class="views-choice"><input type="checkbox" data-id="'+esc(v.id)+'"'+(files.has(v.id)?' checked':'')+'><span>'+esc(v.name)+'<small>'+(v.size/1024/1024).toFixed(1)+' MB</small></span></label>').join('')||'<p class="hint">Nenhum MP4 disponível nesta pasta.</p>';
    pageList();
    controls();
  }
  function pageList(){
    const tag=p=>p.product?'<span class="product-tag product-'+esc(p.product)+'">'+esc(p.product.toUpperCase())+'</span> ':'<span class="product-tag product-none" title="Página sem ID salvo em Publicações ou fora do perfil no Miwra">—</span> ';
    el('drive-pages').innerHTML=shownPages().map(p=>'<label class="views-choice'+(p.postedToday?' posted-today':'')+'"><input type="checkbox" data-id="'+esc(p.id)+'"'+(p.postedToday?' data-blocked="1" disabled':pages.has(p.id)?' checked':'')+'><span>'+tag(p)+esc(p.name)+'<small>ID '+esc(p.id)+'</small>'+(p.postedToday?'<small class="posted-today-note">'+(p.postedToday.uncertain?'Envio de hoje com resultado incerto':'Postada hoje pelo Drive')+(hour(p.postedToday.at)?' às '+hour(p.postedToday.at):'')+' · libera à meia-noite</small>':'')+'</span></label>').join('')||'<p class="hint">'+(data.pages.length?'Nenhuma Página de '+esc(product.toUpperCase())+' entre as Páginas da Meta.':'Nenhuma Página retornada pela Meta.')+'</p>';
    const count=value=>data.pages.filter(p=>p.product===value).length,none=data.pages.filter(p=>!p.product).length;
    el('drive-product-state').textContent=data.productError||('Páginas da Meta: '+count('ed')+' de ED e '+count('wl')+' de WL'+(none?' · '+none+' sem produto (sem ID salvo em Publicações ou fora do Miwra): só aparecem em Todos':'')+'.');
  }
  el('drive-product').onchange=()=>{
    if(working||data.publisherBusy||!loaded){el('drive-product').value=product;return;}
    // Trocar o produto refaz a lista e limpa as Páginas marcadas, para não sobrar Página do outro produto.
    product=el('drive-product').value;pages=new Set();pageList();error('');invalidate();
  };
  function renderTabs(result){
    const all=result.accounts||[];el('drive-acct-bar').hidden=all.length<2;
    if(all.length&&!all.some(item=>item.account===account)){account=all[0].account;}
    const tabs=all.map(item=>'<button type="button" role="tab" data-account="'+esc(item.account)+'" aria-selected="'+(item.account===account)+'" class="acct-tab'+(item.running?' running':'')+(item.token?'':' no-token')+'"><b>'+esc(item.name)+'</b><small>'+esc((item.running?'Lote em andamento':item.token?'Token salvo':'Sem token da Meta')+(item.main?' · principal':''))+'</small></button>').join('');
    if(el('drive-tabs').dataset.sig!==tabs){el('drive-tabs').innerHTML=tabs;el('drive-tabs').dataset.sig=tabs;}
  }
  el('drive-tabs').addEventListener('click',event=>{
    const button=event.target.closest('button[data-account]');
    if(!button||button.dataset.account===account||working)return;
    account=button.dataset.account;try{localStorage.setItem('autofy-drive-conta',account);}catch{}
    clearTimeout(timer);clearCatalog('Cole o link e carregue a pasta para começar.');error('');el('drive-log').textContent='Sem atividade.';el('drive-status').textContent='Nenhum lote em andamento.';
    el('drive-tabs').dataset.sig='';void poll(true);
  });
  function progress(result){
    renderTabs(result);
    data.publisherBusy=result.publisherBusy;data.operation=result.operation;data.captionsFromSettings=result.captionsFromSettings;fillOptions(result);
    // Atualiza quem já foi postada hoje (depois de cada envio e na virada do dia) sem recarregar a pasta.
    if(loaded&&Array.isArray(result.pages)&&result.pages.length){const before=blockedSig();data.pages=result.pages;if(blockedSig()!==before){for(const p of data.pages)if(p.postedToday)pages.delete(p.id);pageList();if(plan&&plan.pairs.some(pair=>data.pages.find(p=>p.id===pair.page.id)?.postedToday))invalidate();}}
    const operation=result.operation||{};
    el('drive-status').textContent=operation.running?'Publicando lote do Drive…':({done:'Lote concluído.',error:'Lote interrompido por erro.',stopped:'Lote parado.'}[operation.phase]||'Nenhum lote em andamento.');
    if(operation.results?.length)el('drive-status').textContent+=' '+operation.results.filter(v=>['drive_sent','drive_posted'].includes(v.status)).length+' envio(s); '+operation.results.filter(v=>['failed','uncertain'].includes(v.status)).length+' ocorrência(s).';
    el('drive-log').textContent=operation.logs?.length?operation.logs.map(v=>v.at+'  '+v.message).join('\n'):'Sem atividade.';controls();
  }
  el('drive-folder').oninput=()=>{clearCatalog('Link alterado. Carregue a pasta novamente.');error('');};
  el('drive-load').onclick=async()=>{
    clearCatalog('Carregando a pasta completa e conferindo os vídeos… Pastas maiores podem levar alguns minutos.');const current=revision;working=true;controls();error('');
    try{const result=await api('/load',{folderUrl:el('drive-folder').value.trim()});if(current!==revision)return;lists(result);el('drive-folder').value=result.folderUrl;}
    catch(cause){if(current===revision){clearCatalog('Não foi possível carregar a pasta. Nenhuma lista anterior está selecionada.');error(cause.message);}}finally{working=false;controls();}
  };
  for(const kind of ['files','pages']){
    el('drive-'+kind).onchange=event=>{if(working||data.publisherBusy||!loaded)return;const selected=kind==='files'?files:pages,id=event.target.dataset.id;if(!pool(kind).some(v=>v.id===id))return;if(event.target.checked&&kind==='files'&&!files.has(id)&&files.size>=MAX_FILES){event.target.checked=false;error('Limite de 100 vídeos selecionados. Desmarque um vídeo antes de escolher outro.');controls();return;}if(event.target.checked)selected.add(id);else selected.delete(id);error('');invalidate();};
    el('drive-all-'+kind).onchange=()=>{if(working||data.publisherBusy||!loaded)return;const selected=new Set(el('drive-all-'+kind).checked?pool(kind).slice(0,kind==='files'?MAX_FILES:undefined).map(v=>v.id):[]);if(kind==='files')files=selected;else pages=selected;el('drive-'+kind).querySelectorAll('input').forEach(input=>input.checked=selected.has(input.dataset.id));error('');invalidate();};
  }
  el('drive-prepare').onclick=async()=>{
    if(!loaded||working||data.publisherBusy)return;invalidate();const current=revision;working=true;controls();error('');
    try{
      const result=await api('/prepare',{fileIds:[...files],pageIds:[...pages],product});if(current!==revision)return;plan=result;
      el('drive-preview').hidden=false;captions(plan);
      el('drive-plan-count').textContent=plan.pairs.length+' postagens · '+({all:'Todos (ED + WL)',ed:'Somente ED',wl:'Somente WL'}[plan.product||'all'])+' · '+plan.reusedFiles+' reutilização(ões) em Páginas diferentes';
      el('drive-plan-rows').innerHTML=plan.pairs.map((p,i)=>'<tr><td>'+(i+1)+'</td><td>'+esc(p.file.name)+'</td><td>'+(p.page.product?'<span class="product-tag product-'+esc(p.page.product)+'">'+esc(p.page.product.toUpperCase())+'</span> ':'')+esc(p.page.name)+'<small>ID '+esc(p.page.id)+'</small></td></tr>').join('');
      el('drive-skipped').textContent=(plan.skipped||[]).map(v=>v.page.name+': '+v.reason).join('\n');
    }catch(cause){error(cause.message);}finally{working=false;controls();}
  };
  el('drive-start').onclick=async()=>{
    if(!plan||working||data.publisherBusy)return;working=true;controls();error('');
    const days=Number(el('drive-comment-days').value);
    if(el('drive-comment-scope').value==='new'&&(!Number.isInteger(days)||days<1||days>365)){error('Os dias de criação para comentar devem ser um número de 1 a 365.');working=false;controls();return;}
    try{await api('/start',{planId:plan.id,caption:el('drive-caption-ed').value,captionWl:el('drive-caption-wl').value,method:el('drive-method').value,commentOn:el('drive-comment-on').checked,comment:el('drive-comment-ed').value,commentWl:el('drive-comment-wl').value,commentScope:el('drive-comment-scope').value,commentMaxDays:days});captionsEdited=false;invalidate();progress(await api(''));}
    catch(cause){error(cause.message);}finally{working=false;controls();}
  };
  el('drive-stop').onclick=async()=>{try{await api('/stop',{});progress(await api(''));}catch(cause){error(cause.message);}};
  async function poll(initial=false){
    const current=revision;
    const asked=account;
    try{const result=await api('');if(asked!==account)return;if(initial&&current===revision&&!working&&!loaded){el('drive-folder').value=result.folderUrl||'';if(result.files.length||result.pages.length)lists(result);}progress(result);}
    catch(cause){data.publisherBusy=true;controls();error(cause.message);}
    timer=setTimeout(()=>poll(),2000);
  }
  window.addEventListener('pagehide',()=>clearTimeout(timer));void poll(true);
})();
