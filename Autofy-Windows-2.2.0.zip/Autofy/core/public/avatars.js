// Tela "Avatares": banco de imagens e foto de perfil sorteada para as Páginas (lib/page-avatars.mjs).
// Usa api(), esc(), guarded() e notice() de app.js. Nenhum token passa por aqui.
(() => {
  const el = id => document.getElementById(id);
  const stamp = new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const when = time => time ? stamp.format(new Date(time)).replace(', ', ' às ') : '';
  let report = null, list = null, loading = false, uploading = false, timer = null, entered = false, ticket = 0;
  // Modo da tela: foto de perfil (avatares) ou foto de capa (capas). Cada um com banco e registro próprios.
  const MODES = {
    avatars: { api: 'avatars', img: '/avatar-img/', one: 'avatar', drawn: 'avatar sorteado', plural: 'avatares', title: 'Banco de avatares', none: 'Sem avatar do Autofy', applied: 'Com avatar do Autofy', column: 'Avatar', w: 512, h: 512, min: 180, shape: 'quadrado (512×512)', field: 'a foto de perfil' },
    covers: { api: 'covers', img: '/cover-img/', one: 'capa', drawn: 'capa sorteada', plural: 'capas', title: 'Banco de capas', none: 'Sem capa do Autofy', applied: 'Com capa do Autofy', column: 'Capa', w: 1640, h: 624, min: 400, shape: 'de capa (1640×624)', field: 'a foto de capa' },
  };
  let mode = (() => { try { return localStorage.getItem('autofy-avatares-modo') === 'covers' ? 'covers' : 'avatars'; } catch { return 'avatars'; } })();
  const M = () => MODES[mode];
  const call = (path, body) => api(M().api + (path ? '/' + path : ''), body);
  let current = (() => { try { return localStorage.getItem('autofy-avatares-conta') || ''; } catch { return ''; } })();
  const selected = new Set();
  let shown = [];

  // Cada conta tem a sua aplicação (rodam ao mesmo tempo). Servidor antigo: uma só, em report.progress.
  const runOf = account => report?.runs ? report.runs[account] || null : (report?.progress?.account === account ? report.progress : null);
  const anyRunning = () => report?.runs ? Object.values(report.runs).some(run => run.running) : Boolean(report?.progress?.running);
  const running = () => Boolean(runOf(current)?.running);
  const profiles = () => report?.profiles || [];
  const profile = () => { const all = profiles(); return all.find(item => item.account === current) || all[0] || null; };
  const record = row => report?.records?.[row.id] || row.record || null;
  const state = row => { const r = record(row); return !r ? 'none' : r.state === 'applied' ? 'applied' : r.state === 'failed' ? 'failed' : 'none'; };
  const imageName = id => report?.images?.find(item => item.id === id)?.name || '';

  // ---------- banco ----------
  // Corta no centro em quadrado e reduz para 512×512 JPEG antes de enviar (arquivo leve, formato que a Meta aceita).
  async function squareJpeg(file, source = null) {
    const url = source || URL.createObjectURL(file);
    try {
      const img = await new Promise((resolve, reject) => { const image = new Image(); image.onload = () => resolve(image); image.onerror = () => reject(new Error('Não consegui abrir ' + file.name + '.')); image.src = url; });
      // Recorte no centro na proporção do modo (quadrado para avatar, 1640×624 para capa).
      const { w, h, min } = M(), ratio = w / h, iw = img.naturalWidth, ih = img.naturalHeight;
      const cw = Math.min(iw, ih * ratio), ch = cw / ratio;
      if (cw < min) throw new Error(file.name + ' é pequena demais para ' + M().one + '.');
      const scale = Math.min(1, w / cw), canvas = document.createElement('canvas');
      canvas.width = Math.round(cw * scale); canvas.height = Math.round(ch * scale);
      const ctx = canvas.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, (iw - cw) / 2, (ih - ch) / 2, cw, ch, 0, 0, canvas.width, canvas.height);
      return canvas.toDataURL('image/jpeg', 0.9);
    } finally { if (!source) URL.revokeObjectURL(url); }
  }
  function renderBank() {
    const images = report?.images || [];
    el('av-stat-images').textContent = report ? images.length : '—';
    el('av-add').disabled = uploading || anyRunning();
    if (uploading) return;
    el('av-bank-status').textContent = !report ? 'Carregando…' : images.length ? images.length + ' imagem(ns) no banco · ' + images.filter(item => !item.uses).length + ' ainda sem uso.' : 'O banco está vazio. Clique em Adicionar imagens (JPG, PNG ou WEBP; dá para escolher várias de uma vez).';
    const html = images.map(item => '<figure class="av-thumb' + (mode === 'covers' ? ' av-cover' : '') + '"><img src="' + M().img + esc(item.id) + '" alt="' + esc(item.name) + '" loading="lazy"><figcaption>' + (item.uses ? esc(item.uses + ' Página(s)') : 'Sem uso') + '</figcaption><button type="button" class="av-remove" data-remove="' + esc(item.id) + '" aria-label="Remover ' + esc(item.name) + '" title="Remover do banco"' + (anyRunning() ? ' disabled' : '') + '>×</button></figure>').join('');
    if (el('av-grid').dataset.sig !== html) { el('av-grid').innerHTML = html; el('av-grid').dataset.sig = html; }
  }
  el('av-add').onclick = () => el('av-files').click();
  // Importar do Google Drive: o Autofy lista a pasta, baixa cada imagem nova e a tela recorta em 512×512.
  let driveStop = false;
  el('av-drive-import').onclick = guarded(async () => {
    const link = el('av-drive-link').value.trim();
    if (!link) throw new Error('Cole o link da pasta do Google Drive.');
    uploading = true; driveStop = false; el('av-drive-import').disabled = true; el('av-drive-stop').hidden = false; renderBank();
    let added = 0, repeated = 0, skipped = 0; const failed = [];
    try {
      el('av-bank-status').textContent = 'Lendo a pasta do Drive…';
      const listed = await call('drive/list', { link });
      const todo = listed.files.filter(file => !file.imported);
      skipped = listed.files.length - todo.length;
      if (!listed.files.length) throw new Error('Nenhuma imagem JPG, PNG ou WEBP encontrada nessa pasta.');
      for (const [index, file] of todo.entries()) {
        if (driveStop) break;
        el('av-bank-status').textContent = 'Importando do Drive: ' + (index + 1) + ' de ' + todo.length + ' · ' + file.name;
        try {
          const fetched = await call('drive/fetch', { id: file.id, resourceKey: file.resourceKey });
          const result = await call('upload', { name: file.name, data: await squareJpeg({ name: file.name }, fetched.data), driveFile: file.id });
          result.duplicate ? repeated++ : added++; report = { ...report, ...result };
        } catch (error) { failed.push(file.name + ': ' + error.message); }
      }
    } finally { uploading = false; el('av-drive-import').disabled = false; el('av-drive-stop').hidden = true; render(); }
    notice('Drive: ' + added + ' imagem(ns) nova(s)' + (skipped ? ', ' + skipped + ' já importada(s) antes' : '') + (repeated ? ', ' + repeated + ' repetida(s)' : '') + (driveStop ? ' (parado por você)' : '') + (failed.length ? '. Não entraram ' + failed.length + ': ' + failed.slice(0, 2).join(' · ') : '.'));
  });
  el('av-drive-stop').onclick = () => { driveStop = true; el('av-bank-status').textContent = 'Parando depois da imagem atual…'; };
  el('av-files').addEventListener('change', guarded(async () => {
    const files = [...el('av-files').files]; el('av-files').value = '';
    if (!files.length) return;
    uploading = true; renderBank();
    let added = 0, repeated = 0; const failed = [];
    try {
      for (const [index, file] of files.entries()) {
        el('av-bank-status').textContent = 'Adicionando ' + (index + 1) + ' de ' + files.length + '…';
        try { const result = await call('upload', { name: file.name, data: await squareJpeg(file) }); result.duplicate ? repeated++ : added++; report = { ...report, ...result }; }
        catch (error) { failed.push(error.message); }
      }
    } finally { uploading = false; render(); }
    notice(added + ' imagem(ns) adicionada(s)' + (repeated ? ', ' + repeated + ' já estava(m) no banco' : '') + (failed.length ? '. Não entraram: ' + failed.slice(0, 3).join(' ') : '.'));
  }));
  el('av-grid').addEventListener('click', guarded(async event => {
    const id = event.target.closest('[data-remove]')?.dataset.remove; if (!id) return;
    if (!confirm('Remover esta imagem do banco?\n\nAs Páginas que já usam ela continuam com a foto; ela só deixa de ser sorteada.')) return;
    report = { ...report, ...await call('remove', { id }) }; render();
  }));

  // ---------- Páginas ----------
  function renderTabs() {
    const all = profiles(), chosen = profile();
    if (chosen) current = chosen.account;
    el('av-acct-bar').hidden = all.length < 2;
    const done = id => Object.values(report?.records || {}).filter(item => item.account === id && item.state === 'applied').length;
    const tabs = all.map(item => {
      const run = runOf(item.account), busy = Boolean(run?.running), count = done(item.account);
      const note = busy ? 'Aplicando · ' + run.done + '/' + run.total : !item.token ? 'Sem token da Meta' : count ? count + ' com ' + M().one : 'Token salvo';
      return '<button type="button" role="tab" data-account="' + esc(item.account) + '" aria-selected="' + (item.account === current) + '" class="acct-tab' + (busy ? ' running' : '') + (item.token ? '' : ' no-token') + '"><b>' + esc(item.name) + '</b><small>' + esc(note + (item.main ? ' · principal' : '')) + '</small></button>';
    }).join('');
    if (el('av-tabs').dataset.sig !== tabs) { el('av-tabs').innerHTML = tabs; el('av-tabs').dataset.sig = tabs; }
    const missing = Boolean(chosen && !chosen.token);
    el('av-notoken').hidden = !missing;
    if (missing) el('av-notoken-name').textContent = chosen.name;
  }
  function situation(row) {
    const r = record(row), s = state(row);
    if (s === 'applied') return '<div class="av-cell"><img src="' + M().img + esc(r.image) + '" alt="" class="av-mini' + (mode === 'covers' ? ' av-mini-cover' : '') + '"><div><span class="cr-badge cr-applied">Aplicado</span><small>' + esc('Em ' + when(r.at)) + '</small>' + (r.error ? '<small>' + esc('⚠ ' + r.error) + '</small>' : '') + '</div></div>';
    if (s === 'failed') return '<span class="cr-badge cr-failed">Falhou</span><small>' + esc(r.error || '') + '</small>';
    return '<span class="cr-badge">' + M().none + '</span>' + (row.manage === false ? '<small>O token pode não ter acesso total a esta Página.</small>' : '');
  }
  const missing = () => (list?.rows || []).filter(row => (list.miwraMissing || row.miwra?.active) && (el('av-product').value === 'all' || row.miwra?.product === el('av-product').value) && state(row) !== 'applied');
  function render() {
    renderBank(); renderTabs();
    const busy = loading || running(), progress = runOf(current), empty = !(report?.images || []).length;
    el('av-load').disabled = busy || !profile()?.token;
    el('av-stop').hidden = !running();
    el('av-state').textContent = running() ? 'Aplicando · ' + progress.done + '/' + progress.total : progress?.phase === 'done' ? 'Concluído' : progress?.phase === 'stopped' ? 'Parado' : progress?.phase === 'error' ? 'Parou com erro' : 'Aguardando';
    const logs = progress?.logs?.length ? progress.logs.map(line => line.at + '  ' + line.message).join('\n') : 'Sem atividade.';
    if (el('av-log').textContent !== logs) { el('av-log').textContent = logs; el('av-log').scrollTop = el('av-log').scrollHeight; }
    const rows = list?.rows || [], marked = rows.filter(row => selected.has(row.id)), faltam = list ? missing().length : 0;
    el('av-test').disabled = busy || empty || !marked.length;
    el('av-apply').disabled = busy || empty || !marked.length;
    el('av-apply').textContent = 'Aplicar nas marcadas' + (marked.length ? ' (' + marked.length + ')' : '');
    el('av-apply-missing').disabled = busy || empty || !faltam;
    el('av-apply-missing').textContent = 'Aplicar nas que não têm' + (list ? ' (' + faltam + ')' : '');
    if (!list) return;
    el('av-stat-total').textContent = rows.length;
    el('av-stat-applied').textContent = rows.filter(row => state(row) === 'applied').length;
    el('av-stat-failed').textContent = rows.filter(row => state(row) === 'failed').length;
    const show = el('av-show').value, product = el('av-product').value, search = el('av-search').value.trim().toLocaleLowerCase('pt-BR');
    const wanted = { active: row => list.miwraMissing || row.miwra?.active, all: () => true, none: row => state(row) === 'none', applied: row => state(row) === 'applied', failed: row => state(row) === 'failed' }[show];
    shown = rows.filter(row => wanted(row) && (product === 'all' || row.miwra?.product === product) && (!search || row.name.toLocaleLowerCase('pt-BR').includes(search) || row.id.includes(search)));
    el('av-summary').textContent = 'Exibindo ' + shown.length + ' de ' + rows.length + ' Página(s) do token de ' + list.accountName + ' · ' + marked.length + ' marcada(s).';
    el('av-select-all').checked = shown.length > 0 && shown.every(row => selected.has(row.id));
    const html = shown.map(row => '<tr>'
      + '<td class="cr-pick"><input type="checkbox" data-id="' + esc(row.id) + '"' + (selected.has(row.id) ? ' checked' : '') + (busy ? ' disabled' : '') + ' aria-label="Marcar ' + esc(row.name) + '"></td>'
      + '<td>' + (row.miwra ? '<span class="product-tag product-' + esc(row.miwra.product) + '">' + esc(row.miwra.product.toUpperCase()) + '</span> ' : '') + esc(row.name)
        + '<small>Facebook ' + esc(row.id) + '</small><small><a href="https://www.facebook.com/' + esc(row.id) + '" target="_blank" rel="noopener noreferrer">Abrir Página</a></small></td>'
      + '<td>' + (row.miwra ? (row.miwra.active ? 'Ativa' : 'Inativa') : 'Fora do Miwra') + '</td>'
      + '<td>' + situation(row) + '</td></tr>').join('') || '<tr><td colspan="4" class="empty">Nenhuma Página neste filtro.</td></tr>';
    if (el('av-rows').dataset.sig !== html) { el('av-rows').innerHTML = html; el('av-rows').dataset.sig = html; }
  }
  // Textos da tela conforme o modo.
  function renderMode() {
    for (const button of document.querySelectorAll('[data-av-mode]')) button.setAttribute('aria-pressed', String(button.dataset.avMode === mode));
    el('av-bank-title').textContent = M().title;
    el('av-bank-text').textContent = 'As imagens ficam guardadas dentro do Autofy, neste computador. Na hora de aplicar, cada Página recebe uma imagem sorteada entre as menos usadas: nenhuma repete enquanto houver imagem sem uso. O Autofy corta no centro em formato ' + M().shape + ' ao adicionar.';
    el('av-list-text').textContent = 'Troca ' + M().field + ' pela API da Meta, uma Página por vez, com 30 segundos de pausa entre elas. A foto enviada não aparece no feed da Página. Comece com "Testar em 1 Página" e confira no Facebook.';
    el('av-stat-applied-label').textContent = M().applied;
    el('av-col').textContent = M().column;
    const show = el('av-show');
    show.querySelector('option[value="none"]').textContent = M().none;
    show.querySelector('option[value="applied"]').textContent = M().applied;
    el('av-grid').classList.toggle('av-grid-cover', mode === 'covers');
  }
  el('av-modes').addEventListener('click', guarded(async event => {
    const button = event.target.closest('[data-av-mode]');
    if (!button || button.dataset.avMode === mode) return;
    mode = button.dataset.avMode; try { localStorage.setItem('autofy-avatares-modo', mode); } catch {}
    report = null; list = null; selected.clear(); ticket++; loading = false;
    el('av-rows').innerHTML = '<tr><td colspan="4" class="empty">Nada carregado ainda.</td></tr>'; el('av-rows').dataset.sig = ''; el('av-grid').dataset.sig = '';
    el('av-drive-link').value = '';
    renderMode(); await refresh();
    if (profile()?.token) await load();
  }));
  async function refresh() {
    report = { ...report, ...await call('') }; if (report.driveLink && !el('av-drive-link').value) el('av-drive-link').value = report.driveLink; render();
    clearTimeout(timer);
    if (location.hash === '#avatares' && anyRunning()) timer = setTimeout(() => refresh().catch(() => {}), 2000);
  }
  async function load() {
    if (!profile()?.token) { list = null; render(); return; }
    const mine = ++ticket; loading = true; render();
    el('av-status').textContent = 'Lendo as Páginas no token da Meta e a situação delas no Miwra (pode levar até 1 minuto)…';
    try {
      const asked = current;
      const fresh = await call('pages', { account: asked || undefined });
      if (asked !== current) return;
      list = fresh; report = { ...report, ...fresh };
      if (list.miwraMissing && el('av-show').value === 'active') el('av-show').value = 'all';
      for (const id of [...selected]) if (!list.rows.some(row => row.id === id)) selected.delete(id);
      el('av-status').textContent = list.rows.length + ' Página(s) no token de ' + list.accountName + (list.miwraMissing ? '. O Miwra não respondeu a tempo: mostrando todas as Páginas do token.' : ', ' + list.rows.filter(row => row.miwra?.active).length + ' ativa(s) no Miwra.');
    } finally { if (mine === ticket) loading = false; render(); }
  }
  async function start(ids) {
    report = { ...report, ...await call('start', { account: list.account, ids }) };
    render(); clearTimeout(timer); timer = setTimeout(() => refresh().catch(() => {}), 1500);
  }
  const minutes = count => Math.max(1, Math.round(count * 45 / 60));
  el('av-load').onclick = guarded(load);
  el('av-test').onclick = guarded(async () => {
    const page = shown.find(row => selected.has(row.id)) || list.rows.find(row => selected.has(row.id));
    if (!page) throw new Error('Marque uma Página para o teste.');
    if (!confirm('Testar em 1 Página: ' + page.name + '\n\n' + (mode === 'covers' ? 'A foto de capa dela vira uma capa sorteada do banco.' : 'A foto de perfil dela vira um avatar sorteado do banco.') + ' Depois confira no Facebook.')) return;
    await start([page.id]);
  });
  el('av-apply').onclick = guarded(async () => {
    const pages = list.rows.filter(row => selected.has(row.id));
    if (!confirm('Trocar ' + M().field + ' de ' + pages.length + ' Página(s) por ' + M().plural + ' sorteados do banco?\n\nLeva uns ' + minutes(pages.length) + ' minuto(s).')) return;
    await start(pages.map(row => row.id));
  });
  el('av-apply-missing').onclick = guarded(async () => {
    const pages = missing();
    if (!pages.length) throw new Error('Todas as Páginas ativas já têm ' + M().one + ' do Autofy.');
    if (!confirm('Aplicar ' + M().drawn + ' nas ' + pages.length + ' Página(s) ativas que ainda não têm?\n\n' + pages.slice(0, 12).map(row => row.name).join(', ') + (pages.length > 12 ? '…' : '') + '\n\nLeva uns ' + minutes(pages.length) + ' minuto(s).')) return;
    await start(pages.map(row => row.id));
  });
  el('av-stop').onclick = guarded(async () => { report = { ...report, ...await call('stop', { account: current }) }; render(); });
  el('av-tabs').addEventListener('click', guarded(async event => {
    const button = event.target.closest('button[data-account]');
    if (!button || button.dataset.account === current) return;
    current = button.dataset.account; try { localStorage.setItem('autofy-avatares-conta', current); } catch {}
    list = null; selected.clear();
    el('av-rows').innerHTML = '<tr><td colspan="4" class="empty">Nada carregado ainda.</td></tr>'; el('av-rows').dataset.sig = '';
    el('av-status').textContent = 'Clique em Carregar Páginas para ver as Páginas do token da Meta.';
    render();
    if (profile()?.token) await load();
  }));
  for (const id of ['av-show', 'av-product']) el(id).addEventListener('change', render);
  el('av-search').addEventListener('input', render);
  el('av-rows').addEventListener('change', event => { const box = event.target.closest('input[data-id]'); if (!box) return; box.checked ? selected.add(box.dataset.id) : selected.delete(box.dataset.id); render(); });
  el('av-select-all').addEventListener('change', event => { for (const row of shown) event.target.checked ? selected.add(row.id) : selected.delete(row.id); render(); });
  async function enter() {
    if (location.hash !== '#avatares') { clearTimeout(timer); return; }
    renderMode();
    await refresh();
    if (!entered) { entered = true; if (profile()?.token) await load(); }
  }
  window.addEventListener('hashchange', () => enter().catch(error => notice(error.message)));
  enter().catch(error => notice(error.message));
})();
