// Tela "Idade das Páginas": há quanto tempo cada Página ativa existe e quais ainda estão abaixo do
// limite de dias. A data de criação é lida no Facebook (Transparência da Página); enquanto ela não
// foi lida, vale a data do cadastro no Miwra, marcada como tal. Usa api(), esc(), guarded() e
// settings de app.js.
(() => {
  const el = id => document.getElementById(id);
  const DAY = 86400000, HOUR = 3600000, STALE = 5 * 60000;
  const zone = { timeZone: 'America/Sao_Paulo' };
  const fullStamp = new Intl.DateTimeFormat('pt-BR', { ...zone, day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  const dayStamp = new Intl.DateTimeFormat('pt-BR', { ...zone, day: '2-digit', month: '2-digit' });
  const hourStamp = new Intl.DateTimeFormat('pt-BR', { ...zone, hour: '2-digit', minute: '2-digit' });
  const keyStamp = new Intl.DateTimeFormat('en-CA', { ...zone, year: 'numeric', month: '2-digit', day: '2-digit' });
  const when = time => fullStamp.format(new Date(time)).replace(', ', ' às ');
  const dateOnly = key => key.slice(8, 10) + '/' + key.slice(5, 7) + '/' + key.slice(0, 4);
  const keyAfter = (key, count) => new Date(Date.parse(key + 'T00:00:00Z') + count * DAY).toISOString().slice(0, 10);
  let data = null, received = 0, loading = false, shown = [], scan = null, starting = false, timer = null;

  const limit = () => { const value = Math.round(Number(el('age-limit').value)); return value >= 1 && value <= 365 ? value : 7; };
  const days = count => count + (count === 1 ? ' dia' : ' dias');
  // O relógio do servidor na hora da leitura, mais o tempo que a tela ficou aberta desde então.
  const nowMs = () => Date.parse(data.now) + (Date.now() - received);
  function remaining(ms) {
    if (ms < HOUR) return 'menos de 1 h';
    const d = Math.floor(ms / DAY), h = Math.floor((ms % DAY) / HOUR);
    return d ? days(d) + (h ? ' e ' + h + ' h' : '') : h + ' h';
  }
  // Uma linha por Página, já com a idade e a situação para o limite escolhido.
  function rows() {
    const now = nowMs(), max = limit(), today = keyStamp.format(new Date(now));
    return data.pages.map(page => {
      const failure = scan?.failures?.[page.facebookPageId] || '';
      if (page.facebookCreated) {
        // Data do Facebook: só o dia. A idade conta dias de calendário (horário de São Paulo).
        const ageDays = Math.max(0, Math.round((Date.parse(today + 'T00:00:00Z') - Date.parse(page.facebookCreated + 'T00:00:00Z')) / DAY));
        const under = ageDays < max, releaseKey = keyAfter(page.facebookCreated, max);
        return { ...page, failure, known: true, source: 'facebook', age: ageDays * DAY, ageDays, under, release: Date.parse(releaseKey + 'T00:00:00-03:00'), releaseText: dateOnly(releaseKey),
          createdText: dateOnly(page.facebookCreated), ageText: ageDays ? days(ageDays) : 'criada hoje',
          status: under ? 'Completa ' + days(max) + ' em ' + dateOnly(releaseKey) + ' · faltam ' + days(max - ageDays) : 'Completou ' + days(max) + ' em ' + dateOnly(releaseKey) };
      }
      if (!page.createdAt) return { ...page, failure, known: false, source: '', age: null, ageDays: null, ageText: 'Sem data', under: false, release: null, releaseText: '', createdText: '', status: 'Sem data do Facebook e sem data no Miwra.' };
      const created = Date.parse(page.createdAt), age = Math.max(0, now - created), ageDays = Math.floor(age / DAY), under = age < max * DAY, release = created + max * DAY;
      return { ...page, failure, known: true, source: 'miwra', age, ageDays, under, release, releaseText: when(release), createdText: when(created),
        ageText: ageDays >= 1 ? days(ageDays) : 'menos de 1 dia (' + Math.floor(age / HOUR) + ' h)',
        status: under ? 'Completa ' + days(max) + ' em ' + when(release) + ' · faltam ' + remaining(release - now) : 'Completou ' + days(max) + ' em ' + when(release) };
    });
  }
  const missingScan = () => data ? data.pages.filter(page => page.facebookPageId && !page.facebookCreated).length : 0;
  function render() {
    const running = Boolean(scan?.running);
    el('age-refresh').disabled = loading; el('age-refresh').textContent = loading ? 'Lendo o Miwra…' : 'Atualizar agora';
    el('age-csv').disabled = loading || !data;
    el('age-scan').disabled = loading || !data || running || starting || !missingScan();
    el('age-scan').textContent = starting ? 'Iniciando…' : 'Buscar datas no Facebook';
    el('age-scan-stop').hidden = !running;
    el('age-scan-status').hidden = !scan?.message;
    el('age-scan-status').textContent = scan?.message ? scan.message + (running && scan.total ? ' · ' + scan.found + ' lida(s)' + (scan.failed ? ', ' + scan.failed + ' não lida(s)' : '') : '') : '';
    el('age-scan-status').classList.toggle('schedule-on', running);
    if (!data) { if (loading) el('age-status').textContent = 'Lendo as Páginas no Miwra…'; return; }
    const max = limit(), product = el('age-product').value, show = el('age-show').value, sort = el('age-sort').value;
    const search = el('age-search').value.trim().toLowerCase();
    const all = rows().filter(row => product === 'all' || row.product === product);
    const known = all.filter(row => row.known), under = known.filter(row => row.under), over = known.filter(row => !row.under);
    const fromFacebook = all.filter(row => row.source === 'facebook').length, fromMiwra = all.filter(row => row.source === 'miwra').length, noId = all.filter(row => !row.facebookPageId).length;
    el('age-stat-total').textContent = all.length;
    el('age-stat-new-label').textContent = 'Menos de ' + days(max);
    el('age-stat-new').textContent = under.length;
    el('age-stat-old-label').textContent = days(max) + ' ou mais';
    el('age-stat-old').textContent = over.length;
    el('age-stat-source').textContent = fromFacebook + ' de ' + all.length;
    // Quantas Páginas completam o limite em cada dia (horário de São Paulo).
    const perDay = new Map();
    for (const row of under.slice().sort((a, b) => a.release - b.release)) { const key = dayStamp.format(new Date(row.release)); perDay.set(key, (perDay.get(key) || 0) + 1); }
    el('age-calendar').hidden = !perDay.size;
    el('age-calendar').innerHTML = perDay.size ? '<span>Completam ' + esc(days(max)) + ' em:</span>' + [...perDay].map(([day, count]) => '<b class="age-chip">' + esc(day) + ' · ' + count + (count === 1 ? ' Página' : ' Páginas') + '</b>').join('') : '';
    const order = { new: (a, b) => (a.known ? a.age : Infinity) - (b.known ? b.age : Infinity), old: (a, b) => (b.known ? b.age : -1) - (a.known ? a.age : -1), name: () => 0 }[sort];
    const wanted = { all: () => true, new: row => row.known && row.under, old: row => row.known && !row.under, nofb: row => row.source !== 'facebook' }[show];
    shown = all.filter(row => wanted(row) && (!search || row.name.toLowerCase().includes(search) || row.id.toLowerCase().includes(search) || row.facebookPageId.includes(search)))
      .sort((a, b) => order(a, b) || a.name.localeCompare(b.name, 'pt-BR') || a.id.localeCompare(b.id, 'pt-BR', { numeric: true }));
    el('age-status').textContent = all.length + ' Página(s) ativa(s) no Miwra' + (product === 'all' ? '' : ' de ' + product.toUpperCase()) + ' · lido às ' + hourStamp.format(new Date(received)) + '.';
    // Enquanto houver Página com a data do Miwra, os números de cima misturam as duas fontes: avisa.
    el('age-source-note').hidden = !fromMiwra && !noId && known.length === all.length;
    el('age-source-note').textContent = fromFacebook === all.length ? '' : (fromFacebook ? fromFacebook + ' Página(s) com a data de criação do Facebook. ' : 'Nenhuma data de criação lida no Facebook ainda. ')
      + (fromMiwra ? fromMiwra + ' ainda com a data do cadastro no Miwra, que pode ser diferente: clique em Buscar datas no Facebook. ' : '')
      + (noId ? noId + ' sem ID do Facebook salvo em Publicações (use Buscar IDs na Meta), então não dá para ler no Facebook. ' : '')
      + (all.length - known.length ? (all.length - known.length) + ' sem nenhuma data.' : '');
    el('age-summary').textContent = 'Exibindo ' + shown.length + ' de ' + all.length + ' Página(s).';
    el('age-rows').innerHTML = shown.map(row => '<tr class="' + (!row.known ? 'age-unknown' : row.under ? 'age-under' : 'age-over') + '">'
      + '<td><span class="product-tag product-' + esc(row.product) + '">' + esc(row.product.toUpperCase()) + '</span> ' + esc(row.name) + '<small>' + esc(row.id) + (row.profile ? ' · perfil ' + esc(row.profile) : '') + (row.facebookPageId ? ' · Facebook ' + esc(row.facebookPageId) : ' · sem ID do Facebook') + '</small></td>'
      + '<td>' + (row.known ? esc(row.createdText) : '—') + '<small class="age-source age-source-' + esc(row.source || 'none') + '">' + (row.source === 'facebook' ? 'Data de criação no Facebook' : row.source === 'miwra' ? 'Cadastro no Miwra (data do Facebook ainda não lida)' : 'Sem data') + '</small>'
        + (row.source === 'facebook' && row.createdAt ? '<small>Cadastro no Miwra: ' + esc(when(row.createdAt)) + '</small>' : '') + (row.failure ? '<small class="views-warning">Não lida no Facebook: ' + esc(row.failure) + '</small>' : '') + '</td>'
      + '<td><strong>' + esc(row.ageText) + '</strong></td>'
      + '<td><span class="age-badge">' + esc(!row.known ? 'Sem data' : row.under ? 'Menos de ' + days(max) : days(max) + ' ou mais') + '</span><small>' + esc(row.status) + '</small></td></tr>').join('')
      || '<tr><td colspan="4" class="empty">Nenhuma Página neste filtro.</td></tr>';
  }
  // As datas lidas chegam por ID do Facebook; entram nas linhas sem reler o Miwra.
  function applyScan(report) {
    scan = report;
    if (data) for (const page of data.pages) { const found = report.dates?.[page.facebookPageId]; if (found?.date) page.facebookCreated = found.date; }
  }
  async function load() {
    if (loading) return;
    loading = true; el('age-error').hidden = true; render();
    try { const fresh = await api('pages/age'); data = fresh; received = Date.now(); applyScan(fresh.scan); }
    catch (error) { el('age-error').hidden = false; el('age-error').textContent = 'Não foi possível ler as Páginas no Miwra: ' + error.message; if (!data) el('age-status').textContent = 'Sem dados. Confira a conexão com o Miwra em Configurações e clique em Atualizar agora.'; }
    finally { loading = false; render(); watch(); }
  }
  // Acompanha a busca no Facebook enquanto ela roda (a cada 2 s), mesmo com outra aba aberta.
  function watch() {
    if (timer || !scan?.running) return;
    timer = setInterval(async () => {
      try { applyScan(await api('pages/age/scan')); } catch { return; }
      if (!scan.running) { clearInterval(timer); timer = null; }
      render();
    }, 2000);
  }
  // Planilha do que está na tela (com os filtros aplicados). Ponto e vírgula e BOM para abrir
  // direto no Excel e no Numbers em português.
  function csv() {
    const cell = value => { const text = String(value ?? ''); return /[";\n\r]/.test(text) ? '"' + text.replaceAll('"', '""') + '"' : text; };
    const max = limit(), head = ['Página', 'Produto', 'ID no Miwra', 'ID no Facebook', 'Perfil', 'Criada em (Facebook)', 'Cadastro no Miwra', 'Idade em dias', 'Idade contada por', 'Situação', 'Completa ' + days(max) + ' em'];
    const lines = shown.map(row => [row.name, row.product.toUpperCase(), row.id, row.facebookPageId, row.profile, row.facebookCreated ? dateOnly(row.facebookCreated) : '', row.createdAt ? when(row.createdAt) : '', row.known ? row.ageDays : '',
      row.source === 'facebook' ? 'Facebook' : row.source === 'miwra' ? 'Miwra' : '', !row.known ? 'Sem data' : row.under ? 'Menos de ' + days(max) : days(max) + ' ou mais', row.releaseText]);
    const blob = new Blob(['﻿' + [head, ...lines].map(line => line.map(cell).join(';')).join('\r\n') + '\r\n'], { type: 'text/csv;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob); link.download = 'idade-das-paginas-' + keyStamp.format(new Date(nowMs())) + '.csv';
    document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(link.href), 5000);
  }
  // Só consulta o Miwra com a aba aberta; relê sozinho se os dados tiverem mais de 5 minutos.
  function auto() { if (location.hash !== '#idade') return; if (!loading && (!data || Date.now() - received > STALE)) void load(); else if (data) render(); }
  el('age-refresh').onclick = () => { void load(); };
  el('age-csv').onclick = guarded(async () => { if (!data || !shown.length) throw new Error('Não há Páginas neste filtro para baixar.'); csv(); });
  el('age-scan').onclick = guarded(async () => {
    const count = missingScan();
    if (!data || !count) throw new Error('Não há Páginas para buscar: todas as que têm ID do Facebook já estão com a data lida.');
    const browser = data.browser === 'adspower' ? 'AdsPower' : 'Chrome do Autofy';
    if (!confirm('Buscar a data de criação de ' + count + ' Página(s) no Facebook?\n\nO ' + browser + ' abre a Transparência de cada Página, uma por vez (cerca de ' + Math.max(1, Math.round(count * 6 / 60)) + ' minuto(s)). É só leitura: nada é postado, trocado de perfil nem alterado.\n\nEnquanto a busca roda, rodadas e lotes ficam esperando. Você pode parar quando quiser; o que já foi lido fica guardado.')) return;
    starting = true; render();
    try { applyScan((await api('pages/age/scan', {})).scan); } finally { starting = false; render(); }
    watch();
  });
  el('age-scan-stop').onclick = guarded(async () => { await api('pages/age/stop', {}); applyScan(await api('pages/age/scan')); render(); });
  for (const id of ['age-limit', 'age-show', 'age-product', 'age-sort', 'age-search']) el(id).addEventListener('input', () => { if (data) render(); });
  window.addEventListener('hashchange', auto);
  auto();
})();
