// Tela "Excluir Páginas": Páginas fora das ativas do Miwra e o lote que as exclui no Facebook pelo
// navegador da conta dona delas (uma aba por conta). Usa api(), esc() e guarded() de app.js.
(() => {
  const el = id => document.getElementById(id);
  const STALE = 5 * 60000;
  let data = null, received = 0, loading = false, starting = false, progress = null, timer = null, shown = [], account = 'main';
  // Uma aba por conta do Facebook: cada lote exclui só Páginas da conta escolhida, pelo navegador dela.
  const mine = () => data ? data.pages.filter(page => page.conta === account) : [];
  const marked = new Set();
  function filtered() {
    if (!data) return [];
    const show = el('del-show').value, search = el('del-search').value.trim().toLowerCase();
    return mine().filter(page => (show === 'all' || (show === 'ready' && page.elegivel) || (show === 'done' && page.excluida) || (show === 'out' && !page.elegivel && !page.excluida))
      && (!search || page.nome.toLowerCase().includes(search) || page.id.includes(search)));
  }
  function render() {
    const running = Boolean(progress?.running);
    el('del-refresh').disabled = loading; el('del-refresh').textContent = loading ? 'Lendo o Miwra…' : 'Atualizar lista';
    el('del-start').disabled = loading || running || starting || !marked.size;
    el('del-start').textContent = starting ? 'Iniciando…' : 'Excluir marcadas' + (marked.size ? ' (' + marked.size + ')' : '');
    el('del-stop').hidden = !running;
    if (progress) {
      el('del-run-state').textContent = running ? 'Excluindo' : progress.phase === 'done' ? 'Concluído' : progress.phase === 'error' ? 'Parou' : progress.phase === 'stopped' ? 'Interrompido' : 'Aguardando';
      el('del-progress').textContent = progress.total ? (running ? 'Excluindo ' + (progress.current || '') + ' · ' : '') + progress.deleted + ' de ' + progress.total + ' excluída(s)' + ((n => n ? ', ' + n + ' pulada(s)' : '')((progress.results || []).filter(item => item.status === 'pulada').length)) + (progress.error ? ' · Parou: ' + progress.error : '') + (progress.report ? ' · Relatório: ' + progress.report : '') : 'Nenhum lote em andamento.';
      el('del-log').textContent = progress.logs?.length ? progress.logs.join('\n') : 'Sem atividade.';
    }
    if (!data) { if (loading) el('del-status').textContent = 'Lendo as Páginas no Miwra…'; return; }
    const accounts = data.contas || [];
    if (!accounts.some(item => item.id === account)) account = accounts[0]?.id || 'main';
    const current = accounts.find(item => item.id === account) || {};
    const counts = id => data.pages.filter(page => page.conta === id && page.elegivel).length;
    el('del-tabs').innerHTML = accounts.map(item => '<button type="button" role="tab" data-del-account="' + esc(item.id) + '" aria-selected="' + (item.id === account) + '" class="acct-tab' + (running && progress.accounts?.includes(item.id) ? ' running' : '') + '"' + (running ? ' disabled' : '') + '><b>' + esc(item.nome) + '</b><small>' + esc(counts(item.id) + ' para excluir' + (item.principal ? ' · principal' : '') + (item.senhaSalva ? '' : ' · sem senha')) + '</small></button>').join('');
    const ready = mine().filter(page => page.elegivel);
    el('del-stat-total').textContent = mine().length; el('del-stat-ready').textContent = ready.length;
    el('del-stat-done').textContent = mine().filter(page => page.excluida).length;
    el('del-stat-pass').textContent = current.senhaSalva ? 'Salva' : 'Falta salvar';
    const sig = JSON.stringify([account, current]);
    if (el('del-passwords').dataset.sig !== sig) {
      el('del-passwords').dataset.sig = sig;
      el('del-passwords').innerHTML = [current].filter(item => item.id).map(account => '<label>' + esc(account.nome) + (account.principal ? ' (principal)' : '') + '<input type="password" autocomplete="off" maxlength="200" data-pass="' + esc(account.id) + '" placeholder="' + (account.senhaSalva ? 'Senha salva · digite para trocar' : 'Digite a senha do Facebook') + '"><small>' + (account.senhaSalva ? 'Senha salva.' : 'Nenhuma senha salva.') + ' <button type="button" data-save-pass="' + esc(account.id) + '">Salvar senha</button></small></label>').join('');
    }
    el('del-status').textContent = 'Lido às ' + new Date(received).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) + ' · ' + data.ativas + ' Página(s) ativas no Miwra.' + (current.senhaSalva ? '' : ' Salve a senha do Facebook de ' + (current.nome || 'esta conta') + ' antes de excluir.');
    shown = filtered();
    const selectable = shown.filter(page => page.elegivel);
    el('del-all').checked = selectable.length > 0 && selectable.every(page => marked.has(page.id));
    el('del-all').disabled = !selectable.length || running;
    el('del-rows').innerHTML = shown.length ? shown.map(page => '<tr><td>' + (page.elegivel ? '<input type="checkbox" data-del="' + esc(page.id) + '"' + (marked.has(page.id) ? ' checked' : '') + (running ? ' disabled' : '') + ' aria-label="Marcar ' + esc(page.nome) + '">' : '') + '</td><td>' + esc(page.nome) + '</td><td>' + esc(page.id.toUpperCase()) + '</td><td>' + esc(page.facebookId || '—') + '</td><td>' + esc(page.elegivel ? (page.senhaDaConta ? 'Pode ser excluída' : 'Pode ser excluída · falta a senha da conta') : page.motivo) + '</td></tr>').join('')
      : '<tr><td colspan="5" class="empty">Nenhuma Página neste filtro.</td></tr>';
  }
  async function load() {
    if (loading) return;
    loading = true; el('del-error').hidden = true; render();
    try { data = await api('pages/delete'); received = Date.now(); progress = data.progress; for (const id of [...marked]) if (!data.pages.some(page => page.id === id && page.elegivel)) marked.delete(id); }
    catch (error) { el('del-error').hidden = false; el('del-error').textContent = 'Não foi possível ler as Páginas no Miwra: ' + error.message; }
    finally { loading = false; render(); watch(); }
  }
  // Acompanha o lote a cada 3 s enquanto ele roda; no fim relê a lista (as excluídas mudam de situação).
  function watch() {
    if (timer || !progress?.running) return;
    timer = setInterval(async () => {
      try { progress = await api('pages/delete/progress'); } catch { return; }
      if (!progress.running) { clearInterval(timer); timer = null; void load(); }
      render();
    }, 3000);
  }
  el('del-rows').addEventListener('change', event => {
    const id = event.target?.dataset?.del; if (!id) return;
    if (event.target.checked) marked.add(id); else marked.delete(id);
    render();
  });
  el('del-all').addEventListener('change', () => { for (const page of shown.filter(item => item.elegivel)) { if (el('del-all').checked) marked.add(page.id); else marked.delete(page.id); } render(); });
  for (const id of ['del-show', 'del-search']) el(id).addEventListener('input', () => { if (data) render(); });
  el('del-passwords').addEventListener('click', guarded(async event => {
    const id = event.target?.dataset?.savePass; if (!id) return;
    const input = el('del-passwords').querySelector('[data-pass="' + CSS.escape(id) + '"]');
    if (!input.value) throw new Error('Digite a senha antes de salvar.');
    await api('pages/delete/password', { account: id, password: input.value }); input.value = '';
    el('del-passwords').dataset.sig = ''; await load();
  }));
  el('del-tabs').addEventListener('click', event => {
    const id = event.target.closest('[data-del-account]')?.dataset.delAccount;
    if (!id || id === account || progress?.running) return;
    account = id; marked.clear(); el('del-search').value = ''; render();
  });
  el('del-refresh').onclick = () => { void load(); };
  // Abre o Chrome da conta da aba (cada conta tem o seu, com login próprio), para entrar antes de excluir.
  el('del-login').onclick = guarded(async () => {
    if (progress?.running) throw new Error('Espere a exclusão em andamento terminar.');
    const current = (data?.contas || []).find(item => item.id === account);
    notice('Abrindo o Chrome da conta ' + (current?.nome || '') + '. Se não estiver logado, entre com o Facebook dela nessa janela; o login fica guardado para os próximos lotes.');
    await api('login', { account });
  });
  el('del-start').onclick = guarded(async () => {
    if (!marked.size) throw new Error('Marque ao menos uma Página.');
    const chosen = data.pages.filter(page => marked.has(page.id)), missing = [...new Set(chosen.filter(page => !page.senhaDaConta).map(page => page.contaNome))];
    if (missing.length) throw new Error('Salve a senha do Facebook da conta ' + missing.join(', ') + ' (no topo desta aba) antes de excluir.');
    if (chosen.some(page => page.conta !== account)) throw new Error('Há Páginas de outra conta marcadas. Atualize a lista e marque de novo.');
    const names = chosen.map(page => page.nome);
    if (!confirm('EXCLUIR no Facebook ' + names.length + ' Página(s) da conta ' + (chosen[0]?.contaNome || '') + '?\n\n' + names.slice(0, 12).join('\n') + (names.length > 12 ? '\n… e mais ' + (names.length - 12) : '') + '\n\nO navegador dessa conta faz uma por vez (cerca de ' + Math.max(1, Math.round(names.length * 1.5)) + ' minuto(s)). Enquanto isso, as rodadas da conta principal ficam esperando. O Facebook mantém cada Página por alguns dias antes de apagar de vez.')) return;
    starting = true; render();
    try { const result = await api('pages/delete/start', { ids: [...marked], account }); progress = result.progress; marked.clear(); }
    finally { starting = false; render(); }
    watch();
  });
  el('del-stop').onclick = guarded(async () => { await api('pages/delete/stop', {}); progress = await api('pages/delete/progress'); render(); });
  function auto() { if (location.hash !== '#excluir') return; if (!loading && (!data || Date.now() - received > STALE)) void load(); else if (data) render(); }
  window.addEventListener('hashchange', auto);
  auto();
})();
