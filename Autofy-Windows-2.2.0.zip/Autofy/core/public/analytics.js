// Tela "Analytics": plays dos Reels de todas as Páginas por janela (24h, 48h, 7d, 30d), coletados pela
// API da Meta de hora em hora (lib/plays-analytics.mjs). Os números do topo somam as Páginas do filtro
// (Páginas e Produto); a busca só filtra a tabela. Usa api(), esc() e guarded() de app.js.
(() => {
  const el = id => document.getElementById(id);
  const HOUR = 3600000, DAY = 24 * HOUR;
  const zone = { timeZone: 'America/Sao_Paulo' };
  const stamp = new Intl.DateTimeFormat('pt-BR', { ...zone, day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const clock = new Intl.DateTimeFormat('pt-BR', { ...zone, hour: '2-digit', minute: '2-digit' });
  const fileDay = new Intl.DateTimeFormat('en-CA', { ...zone, year: 'numeric', month: '2-digit', day: '2-digit' });
  const number = new Intl.NumberFormat('pt-BR');
  const percent = new Intl.NumberFormat('pt-BR', { maximumFractionDigits: 1 });
  const when = time => stamp.format(new Date(time)).replace(', ', ' às ');
  const LABEL = { '24h': 'últimas 24h', '48h': 'últimas 48h', '7d': 'últimos 7 dias', '30d': 'últimos 30 dias' };
  const PREVIOUS = { '24h': '24h anteriores', '48h': '48h anteriores', '7d': '7 dias anteriores', '30d': '30 dias anteriores' };
  let windowKey = '24h', data = null, loading = false, shown = [], timer = null, lastAt = null, wasRunning = false;
  let sort = { key: 'win', dir: 'desc' };
  try { const saved = localStorage.getItem('analytics-window'); if (['24h', '48h', '7d', '30d'].includes(saved)) windowKey = saved; } catch {}
  const span = ms => {
    if (ms < HOUR) return Math.max(0, Math.round(ms / 60000)) + ' min';
    const d = Math.floor(ms / DAY), h = Math.round((ms % DAY) / HOUR);
    return d ? d + (d === 1 ? ' dia' : ' dias') + (h ? ' e ' + h + ' h' : '') : h + ' h';
  };
  const change = (now, before) => before > 0 ? (now - before) / before : null;
  const changeText = value => value === null ? '' : (value > 0.0005 ? '▲ +' : value < -0.0005 ? '▼ ' : '= ') + percent.format(value * 100) + '%';
  const changeClass = value => value === null ? '' : value > 0.0005 ? 'an-up' : value < -0.0005 ? 'an-down' : 'an-flat';
  // Páginas e Produto valem para os números do topo e para a tabela.
  function scoped() {
    if (!data?.pages) return [];
    const scope = el('an-scope').value, product = el('an-product').value;
    // Sem a lista do Miwra não há como saber ativa/produto: mostra tudo o que a Meta devolveu.
    if (!data.miwraLoaded) return data.pages.slice();
    return data.pages.filter(row => (scope === 'all' || (scope === 'active' ? row.active : row.inMiwra)) && (product === 'all' || row.product === product));
  }
  const value = {
    name: row => row.name.toLocaleLowerCase('pt-BR'), win: row => row.win.t, winI: row => row.win.i, change: row => row.change ?? -Infinity,
    total: row => row.total.t, totalI: row => row.total.i, reels: row => row.reels, best: row => row.best?.plays ?? -1,
  };
  function renderStatus() {
    const status = data?.status;
    el('an-auto').disabled = !status || !status.tokenConfigured; el('an-auto').checked = Boolean(status?.enabled);
    el('an-refresh').disabled = !status || status.running || !status.tokenConfigured; el('an-refresh').textContent = status?.running ? 'Coletando…' : 'Coletar agora';
    el('an-stop').hidden = !status?.running;
    for (const button of document.querySelectorAll('.an-window')) button.setAttribute('aria-pressed', String(button.dataset.window === windowKey));
    if (!status) { el('an-status').textContent = loading ? 'Lendo o Analytics…' : 'Abra esta aba para ver os plays das Páginas.'; return; }
    const parts = [];
    if (!status.tokenConfigured) parts.push('Sem a Conexão com a Meta: configure o token em Configurações → Conexão com a Meta (o mesmo do Postar por API) para começar a coletar.');
    else if (status.running && status.progress) parts.push('Coletando agora: ' + (status.progress.total ? 'Página ' + status.progress.index + ' de ' + status.progress.total + ' (' + status.progress.current + ')' : status.progress.current) + '.');
    if (status.lastRun) {
      const run = status.lastRun;
      parts.push('Última coleta: ' + when(run.startedAt) + (run.finishedAt ? ', levou ' + span(Date.parse(run.finishedAt) - Date.parse(run.startedAt)) : '') + ' · ' + run.pagesOk + ' de ' + run.pages + ' Página(s), ' + number.format(run.reels) + ' Reel(s)' + (run.errors ? ' · ' + run.errors + ' Página(s) com erro' : '') + (run.stopped ? ' · interrompida' : '') + '.');
    } else if (status.tokenConfigured && !status.running) parts.push('Nenhuma coleta feita ainda.');
    if (status.retryAt) parts.push('A Meta pediu uma pausa: a coleta volta às ' + clock.format(new Date(status.retryAt)) + '.');
    else if (!status.running && status.nextAt) parts.push('Próxima coleta às ' + clock.format(new Date(status.nextAt)) + '.');
    else if (status.tokenConfigured && !status.enabled) parts.push('Coleta de hora em hora desligada.');
    el('an-status').textContent = parts.join(' ');
    const errors = [status.error && 'Coleta: ' + status.error, data.miwraError && 'Miwra: ' + data.miwraError + (data.miwraLoaded ? ' (usando a última lista lida)' : ' (nomes vêm da Meta e os filtros de Miwra e produto ficam vazios)')].filter(Boolean);
    el('an-error').hidden = !errors.length; el('an-error').textContent = errors.join(' · ');
  }
  function render() {
    renderStatus();
    el('an-win-label').textContent = 'Plays nas ' + LABEL[windowKey];
    el('an-reels-label').textContent = 'Reels postados nas ' + LABEL[windowKey];
    if (windowKey.endsWith('d')) { el('an-win-label').textContent = 'Plays nos ' + LABEL[windowKey]; el('an-reels-label').textContent = 'Reels postados nos ' + LABEL[windowKey]; }
    el('an-csv').disabled = !shown.length;
    if (!data || !data.ref) {
      for (const id of ['an-total', 'an-win', 'an-reels', 'an-pages']) el(id).textContent = '—';
      for (const id of ['an-total-sub', 'an-win-sub', 'an-win-change', 'an-reels-sub', 'an-pages-sub']) el(id).textContent = '';
      el('an-note').hidden = !data?.status?.tokenConfigured;
      el('an-note').textContent = 'Os números aparecem depois da primeira coleta. A partir dela, cada coleta de hora em hora guarda o total de cada Reel; os plays de 24h, 48h, 7 dias e 30 dias saem da diferença entre as coletas, então a comparação completa de cada janela fica pronta depois desse tempo de coleta.';
      el('an-rows').innerHTML = '<tr><td colspan="9" class="empty">' + (data?.status?.running ? 'Primeira coleta em andamento…' : 'Nenhuma coleta ainda.') + '</td></tr>';
      el('an-summary').textContent = ''; shown = []; el('an-csv').disabled = true; renderRuns(); return;
    }
    const rows = scoped(), sum = (list, pick) => list.reduce((total, row) => total + pick(row), 0);
    const total = sum(rows, r => r.total.t), totalI = sum(rows, r => r.total.i), win = sum(rows, r => r.win.t), winI = sum(rows, r => r.win.i);
    const reelsWindow = sum(rows, r => r.reelsWindow), reels = sum(rows, r => r.reels), withPlays = rows.filter(r => r.win.t > 0).length;
    const comparable = rows.length && rows.every(r => r.prev), prev = comparable ? sum(rows, r => r.prev.t) : 0;
    el('an-total').textContent = number.format(total); el('an-total-sub').textContent = 'Iniciais: ' + number.format(totalI) + ' · ' + number.format(reels) + ' Reel(s)';
    el('an-win').textContent = number.format(win); el('an-win-sub').textContent = 'Iniciais: ' + number.format(winI);
    const overall = comparable ? change(win, prev) : null;
    el('an-win-change').className = changeClass(overall);
    el('an-win-change').textContent = overall !== null ? changeText(overall) + ' vs ' + PREVIOUS[windowKey] + ' (' + number.format(prev) + ')' : 'Comparação com as ' + PREVIOUS[windowKey] + ' depois de ' + span(2 * data.spanMs) + ' de coletas.';
    el('an-reels').textContent = number.format(reelsWindow); el('an-reels-sub').textContent = 'em ' + rows.filter(r => r.reelsWindow).length + ' Página(s) · ' + number.format(reels) + ' Reel(s) monitorado(s)';
    el('an-pages').textContent = withPlays + ' de ' + rows.length; el('an-pages-sub').textContent = rows.length ? 'Média de ' + number.format(Math.round(win / rows.length)) + ' plays por Página' : '';
    // Aviso de histórico curto (como no Miwra): a janela ainda não tem uma coleta no começo dela.
    const covered = data.coveredMs, notes = [];
    if (covered < data.spanMs * 0.9) notes.push('Histórico ainda em formação: a primeira coleta foi em ' + when(data.status.firstAt) + '. Nas ' + LABEL[windowKey] + ', os Reels postados antes disso contam só os plays desde ' + when(data.baseAt) + ' (' + span(covered) + ' de coleta). Os Reels postados dentro da janela contam inteiros.');
    else if (covered > data.spanMs * 1.1) notes.push('Sem coleta no começo exato da janela: os plays são comparados com a coleta de ' + when(data.baseAt) + ' (' + span(covered) + ' atrás).');
    const noBase = sum(rows, r => r.noBase);
    if (noBase) notes.push(number.format(noBase) + ' Reel(s) antigo(s) não estavam na coleta do começo da janela (Página com erro naquela hora) e ficaram fora dos plays da janela.');
    el('an-note').hidden = !notes.length; el('an-note').textContent = notes.join(' ');
    // Tabela
    const search = el('an-search').value.trim().toLocaleLowerCase('pt-BR');
    shown = rows.filter(row => !search || row.name.toLocaleLowerCase('pt-BR').includes(search) || row.metaName.toLocaleLowerCase('pt-BR').includes(search) || row.id.includes(search));
    const pick = value[sort.key], dir = sort.dir === 'asc' ? 1 : -1;
    shown.sort((a, b) => { const x = pick(a), y = pick(b); return (x < y ? -1 : x > y ? 1 : 0) * dir || b.win.t - a.win.t || a.name.localeCompare(b.name, 'pt-BR'); });
    for (const th of document.querySelectorAll('.an-table th[aria-sort]')) th.setAttribute('aria-sort', th.querySelector('.an-sort').dataset.sort === sort.key ? (sort.dir === 'asc' ? 'ascending' : 'descending') : 'none');
    const top = Math.max(1, ...shown.map(r => r.win.t)), now = Date.parse(data.ref);
    el('an-summary').textContent = 'Exibindo ' + shown.length + ' de ' + rows.length + ' Página(s) · janela de ' + when(data.from) + ' até ' + when(data.ref) + '.';
    el('an-rows').innerHTML = shown.map((row, index) => {
      const share = win ? row.win.t / win : 0, stale = row.lastOkAt && now - Date.parse(row.lastOkAt) > 2 * HOUR;
      const notes = [
        row.inMiwra ? (row.active ? '' : 'inativa no Miwra') : 'fora do Miwra',
        stale ? 'última leitura em ' + when(row.lastOkAt) : '',
      ].filter(Boolean);
      return '<tr>'
        + '<td>' + (index + 1) + '</td>'
        + '<td class="an-page">' + (row.product ? '<span class="product-tag product-' + esc(row.product) + '">' + esc(row.product.toUpperCase()) + '</span> ' : '') + esc(row.name)
          + '<small>Facebook ' + esc(row.id) + (notes.length ? ' · ' + esc(notes.join(' · ')) : '') + '</small>'
          + (row.error ? '<small class="views-warning">Última coleta falhou: ' + esc(row.error) + '</small>' : '')
          + (row.noBase ? '<small>' + row.noBase + ' Reel(s) sem a coleta do começo da janela</small>' : '') + '</td>'
        + '<td class="num"><strong>' + number.format(row.win.t) + '</strong><div class="an-bar" title="' + esc(percent.format(share * 100)) + '% dos plays da janela"><i style="width:' + (row.win.t / top * 100).toFixed(1) + '%"></i></div><small>' + percent.format(share * 100) + '% do total</small></td>'
        + '<td class="num">' + number.format(row.win.i) + '</td>'
        + '<td class="num ' + changeClass(row.change) + '">' + (row.change === null ? '<span class="an-flat">—</span>' : esc(changeText(row.change))) + (row.prev ? '<small>antes: ' + number.format(row.prev.t) + '</small>' : '') + '</td>'
        + '<td class="num">' + number.format(row.total.t) + '</td>'
        + '<td class="num">' + number.format(row.total.i) + '</td>'
        + '<td class="num">' + number.format(row.reels) + (row.reelsWindow ? '<small>+' + row.reelsWindow + ' na janela</small>' : '') + '</td>'
        + '<td>' + (row.best && row.best.plays > 0 ? number.format(row.best.plays) + ' plays<small><a href="https://www.facebook.com/reel/' + esc(row.best.id) + '" target="_blank" rel="noopener noreferrer">Abrir Reel</a></small>' : '<span class="an-flat">—</span>') + '</td>'
        + '</tr>';
    }).join('') || '<tr><td colspan="9" class="empty">Nenhuma Página neste filtro.</td></tr>';
    el('an-csv').disabled = !shown.length;
    renderRuns();
  }
  function renderRuns() {
    const runs = data?.status ? data.status.lastRun ? [data.status.lastRun] : [] : [];
    const failed = (data?.pages || []).filter(row => row.error);
    el('an-runs').innerHTML = (data?.status ? '<div class="an-run"><span>Coletas guardadas</span><div>' + number.format(data.status.snapshots) + (data.status.firstAt ? ' · desde ' + esc(when(data.status.firstAt)) : '') + (data.status.mode ? ' · leitura ' + (data.status.mode === 'expand' ? 'por lista (rápida)' : 'Reel por Reel') : '') + '</div></div>' : '')
      + runs.map(run => '<div class="an-run"><span>Última coleta</span><div>' + esc(when(run.startedAt)) + ' · ' + run.pagesOk + ' de ' + run.pages + ' Página(s) · ' + number.format(run.reels) + ' Reel(s)' + (run.error ? ' · ' + esc(run.error) : '') + '</div></div>').join('')
      + (failed.length ? failed.map(row => '<div class="an-run"><span>' + esc(row.name) + '</span><div class="views-warning">' + esc(row.error) + '</div></div>').join('') : '<div class="an-run"><span>Páginas com erro</span><div>Nenhuma na última coleta.</div></div>');
  }
  async function load() {
    if (loading) return;
    loading = true; renderStatus();
    try { data = await api('analytics?window=' + encodeURIComponent(windowKey)); lastAt = data.status?.lastAt || null; wasRunning = Boolean(data.status?.running); }
    catch (error) { el('an-error').hidden = false; el('an-error').textContent = 'Não foi possível ler o Analytics: ' + error.message; }
    finally { loading = false; render(); }
  }
  // Com a aba aberta: acompanha a coleta (a cada 3 s enquanto roda, a cada 20 s parada) e relê os
  // números quando uma coleta termina.
  async function poll() {
    if (location.hash !== '#analytics' || loading) return;
    if (!data) return void load();
    try {
      const status = await api('analytics/status');
      data.status = status;
      if (status.lastAt !== lastAt || (wasRunning && !status.running)) return void load();
      wasRunning = Boolean(status.running);
      renderStatus();
    } catch {}
  }
  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(async () => { await poll(); schedule(); }, data?.status?.running ? 3000 : 20000);
  }
  function csv() {
    const cell = value => { const text = String(value ?? ''); return /[";\n\r]/.test(text) ? '"' + text.replaceAll('"', '""') + '"' : text; };
    const head = ['Posição', 'Página', 'Produto', 'ID no Facebook', 'Situação no Miwra', 'Plays na janela (' + windowKey + ')', 'Plays iniciais na janela', 'Plays na janela anterior', 'Variação', 'Plays acumulados', 'Plays iniciais acumulados', 'Reels', 'Reels postados na janela', 'Melhor Reel na janela', 'Plays do melhor Reel', 'Erro da última coleta'];
    const lines = shown.map((row, index) => [index + 1, row.name, row.product.toUpperCase(), row.id, row.inMiwra ? (row.active ? 'Ativa' : 'Inativa') : 'Fora do Miwra', row.win.t, row.win.i, row.prev ? row.prev.t : '', row.change === null ? '' : percent.format(row.change * 100) + '%',
      row.total.t, row.total.i, row.reels, row.reelsWindow, row.best ? 'https://www.facebook.com/reel/' + row.best.id : '', row.best ? row.best.plays : '', row.error]);
    const blob = new Blob(['﻿' + [head, ...lines].map(line => line.map(cell).join(';')).join('\r\n') + '\r\n'], { type: 'text/csv;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob); link.download = 'analytics-paginas-' + windowKey + '-' + fileDay.format(new Date()) + '.csv';
    document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(link.href), 5000);
  }
  for (const button of document.querySelectorAll('.an-window')) button.addEventListener('click', () => {
    if (button.dataset.window === windowKey) return;
    windowKey = button.dataset.window; try { localStorage.setItem('analytics-window', windowKey); } catch {}
    void load();
  });
  for (const button of document.querySelectorAll('.an-sort')) button.addEventListener('click', () => {
    const key = button.dataset.sort;
    sort = sort.key === key ? { key, dir: sort.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: key === 'name' ? 'asc' : 'desc' };
    render();
  });
  for (const id of ['an-scope', 'an-product']) el(id).addEventListener('change', render);
  el('an-search').addEventListener('input', render);
  el('an-csv').onclick = guarded(async () => { if (!shown.length) throw new Error('Não há Páginas neste filtro para baixar.'); csv(); });
  el('an-refresh').onclick = guarded(async () => { data.status = await api('analytics/refresh', {}); wasRunning = true; renderStatus(); schedule(); });
  el('an-stop').onclick = guarded(async () => { data.status = await api('analytics/stop', {}); renderStatus(); });
  el('an-auto').onchange = guarded(async () => {
    const wanted = el('an-auto').checked;
    try { data.status = await api('analytics/settings', { enabled: wanted }); } catch (error) { el('an-auto').checked = !wanted; throw error; }
    renderStatus();
  });
  function enter() { if (location.hash === '#analytics') { void load(); schedule(); } }
  window.addEventListener('hashchange', enter);
  enter();
})();
