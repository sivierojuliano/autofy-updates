// Tela "Gestão de Páginas": Páginas ativas abaixo do limite de plays no período (Analytics do Miwra),
// verificadas todo dia, com o histórico de cada dia (lib/page-health.mjs). Só leitura: nada é
// excluído nem alterado. Usa api(), esc() e guarded() de app.js.
(() => {
  const el = id => document.getElementById(id);
  const zone = { timeZone: 'America/Sao_Paulo' };
  const stamp = new Intl.DateTimeFormat('pt-BR', { ...zone, day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const number = new Intl.NumberFormat('pt-BR');
  const when = time => stamp.format(new Date(time)).replace(', ', ' às ');
  const dateText = key => key.slice(8, 10) + '/' + key.slice(5, 7) + '/' + key.slice(0, 4);
  const days = count => count + (count === 1 ? ' dia' : ' dias');
  const LABEL = { fraca: 'Abaixo do limite', ok: 'Acima do limite', nova: 'Nova', erro: 'Erro na coleta do Miwra', semdados: 'Sem dados no Miwra', indefinida: 'Não dá para separar' };
  const META = { ok: 'Ativa na Meta', despublicada: 'Despublicada', erro: 'Erro na Meta', fora: 'Fora do token' };
  const metaBad = row => Boolean(row.meta && row.meta.status !== 'ok');
  let data = null, loading = false, shown = [], timer = null, dirty = false;

  const form = () => ({ limit: Math.round(Number(el('hl-limit').value)), days: Math.round(Number(el('hl-days').value)), hour: el('hl-hour').value, enabled: el('hl-enabled').checked });
  function fillForm() {
    if (!data || dirty) return;
    const s = data.settings;
    el('hl-limit').value = s.limit; el('hl-days').value = s.days; el('hl-hour').value = s.hour; el('hl-enabled').checked = s.enabled;
  }
  function render() {
    const running = Boolean(data?.running);
    el('hl-check').disabled = loading || running; el('hl-check').textContent = running ? 'Verificando…' : 'Verificar agora';
    el('hl-save').disabled = !dirty;
    const meta = data?.meta, metaRunning = Boolean(meta?.progress?.running);
    el('hl-meta-check').disabled = loading || metaRunning; el('hl-meta-check').textContent = metaRunning ? 'Conferindo na Meta… ' + meta.progress.done + '/' + (meta.progress.total || '?') : 'Conferir status na Meta';
    if (meta) {
      const parts = [];
      if (metaRunning) parts.push('Conferindo o status das Páginas na Meta' + (meta.progress.account ? ' (' + meta.progress.account + ')' : '') + '…');
      else if (meta.checkedAt) parts.push('Status na Meta conferido em ' + when(meta.checkedAt) + '.');
      else parts.push('Status na Meta ainda não conferido: clique em Conferir status na Meta.');
      for (const item of Object.values(meta.accounts || {})) if (item.error) parts.push(item.name + ': ' + item.error);
      if (meta.progress?.error) parts.push('Parou: ' + meta.progress.error);
      if (data.current) { const bad = data.current.rows.filter(metaBad).length; if (meta.checkedAt) parts.push(bad + ' Página(s) ativa(s) com problema na Meta.'); }
      el('hl-meta-state').textContent = parts.join(' ');
    }
    if (!data) { el('hl-status').textContent = loading ? 'Lendo…' : 'Abra esta aba para ver a verificação de hoje.'; return; }
    const s = data.settings, current = data.current;
    el('hl-rule').textContent = 'Páginas ativas que somaram menos de ' + number.format(s.limit) + ' plays nos últimos ' + days(s.days) + ', segundo o Analytics do Miwra. Páginas com menos de ' + days(s.days) + ' de cadastro no Miwra ficam de fora, porque ainda não tiveram esse tempo. A lista é refeita todo dia às ' + s.hour + ' (com o Autofy aberto) e cada dia fica guardado no histórico. Nada é excluído ou alterado: a exclusão é com você.';
    const status = [];
    if (running) status.push('Verificando agora no Analytics do Miwra…');
    if (current) status.push('Última verificação: ' + when(current.at) + (current.origin === 'auto' ? ' (automática)' : '') + (current.collectedAt ? ' · Analytics do Miwra coletado em ' + when(current.collectedAt) : '') + '.');
    else if (!running) status.push('Nenhuma verificação ainda: clique em Verificar agora.');
    status.push(s.enabled ? 'Verificação automática todo dia às ' + s.hour + '.' : 'Verificação automática desligada.');
    if (data.retryAt) status.push('Nova tentativa automática às ' + when(data.retryAt).slice(-5) + '.');
    el('hl-status').textContent = status.join(' ');
    el('hl-error').hidden = !data.error; el('hl-error').textContent = data.error ? 'A última verificação falhou: ' + data.error : '';
    const label = current ? { limit: current.limit, days: current.days } : s;
    el('hl-stat-weak-label').textContent = 'Abaixo de ' + number.format(label.limit) + ' plays em ' + days(label.days);
    el('hl-stat-young-label').textContent = 'Novas (menos de ' + days(label.days) + ')';
    el('hl-col-plays').textContent = 'Plays em ' + days(label.days);
    renderHistory();
    if (!current) {
      for (const id of ['hl-stat-weak', 'hl-stat-ok', 'hl-stat-young', 'hl-stat-nodata']) el(id).textContent = '—';
      el('hl-stat-weak-sub').textContent = ''; el('hl-stat-ok-sub').textContent = '';
      el('hl-rows').innerHTML = '<tr><td colspan="7" class="empty">' + (running ? 'Verificando…' : 'Nada verificado ainda.') + '</td></tr>';
      el('hl-summary').textContent = ''; shown = []; el('hl-csv').disabled = true; return;
    }
    const product = el('hl-product').value, show = el('hl-show').value, search = el('hl-search').value.trim().toLocaleLowerCase('pt-BR');
    const rows = current.rows.filter(row => product === 'all' || row.product === product);
    const count = test => rows.filter(test).length, judged = count(r => r.status === 'fraca' || r.status === 'ok');
    el('hl-stat-weak').textContent = count(r => r.status === 'fraca');
    el('hl-stat-weak-sub').textContent = 'de ' + judged + ' Página(s) avaliada(s)';
    el('hl-stat-ok').textContent = count(r => r.status === 'ok');
    el('hl-stat-ok-sub').textContent = judged ? Math.round(count(r => r.status === 'ok') / judged * 100) + '% das avaliadas' : '';
    el('hl-stat-young').textContent = count(r => r.status === 'nova');
    el('hl-stat-nodata').textContent = count(r => ['erro', 'semdados', 'indefinida'].includes(r.status));
    const wanted = { fraca: r => r.status === 'fraca', judged: r => r.status === 'fraca' || r.status === 'ok', nova: r => r.status === 'nova', problem: r => ['erro', 'semdados', 'indefinida'].includes(r.status), meta: metaBad, cut: r => r.status === 'fraca' || metaBad(r), all: () => true }[show];
    shown = rows.filter(row => wanted(row) && (!search || row.name.toLocaleLowerCase('pt-BR').includes(search) || row.facebookName.toLocaleLowerCase('pt-BR').includes(search) || row.id.toLowerCase().includes(search) || row.fbPageId.includes(search)))
      .sort((a, b) => a.plays - b.plays || a.plays24 - b.plays24 || a.name.localeCompare(b.name, 'pt-BR'));
    el('hl-summary').textContent = 'Exibindo ' + shown.length + ' de ' + rows.length + ' Página(s) ativa(s)' + (product === 'all' ? '' : ' de ' + product.toUpperCase()) + ' · verificação de ' + when(current.at) + '.';
    el('hl-rows').innerHTML = shown.map(row => '<tr>'
      + '<td><span class="product-tag product-' + esc(row.product) + '">' + esc(row.product.toUpperCase()) + '</span> ' + esc(row.name)
        + '<small>' + esc(row.id) + (row.fbPageId ? ' · Facebook ' + esc(row.fbPageId) : '') + (row.facebookName && row.facebookName !== row.name ? ' · no Facebook: ' + esc(row.facebookName) : '') + '</small>'
        + (row.fbPageId ? '<small><a href="https://www.facebook.com/' + esc(row.fbPageId) + '" target="_blank" rel="noopener noreferrer">Abrir Página</a></small>' : '') + '</td>'
      + '<td class="num"><strong>' + number.format(row.plays) + '</strong></td>'
      + '<td class="num">' + number.format(row.plays24) + '</td>'
      + '<td class="num">' + number.format(row.videos) + '<small>' + number.format(row.playsTotal) + ' plays no total</small></td>'
      + '<td class="num">' + (row.ageDays === null ? '—' : days(row.ageDays)) + '</td>'
      + '<td class="num">' + (row.streak ? days(row.streak.count) + '<small>desde ' + esc(dateText(row.streak.since)) + '</small>' : '—') + '</td>'
      + '<td><span class="hl-badge hl-' + esc(row.status) + '">' + esc(LABEL[row.status] || row.status) + '</span>' + (row.meta ? '<span class="hl-badge hl-meta-' + esc(row.meta.status) + '">' + esc(META[row.meta.status] || row.meta.status) + '</span>' : '') + (row.note ? '<small>' + esc(row.note) + '</small>' : '') + (metaBad(row) && row.meta.detail ? '<small>Meta: ' + esc(row.meta.detail) + '</small>' : '') + '</td>'
      + '</tr>').join('') || '<tr><td colspan="7" class="empty">' + (show === 'fraca' ? 'Nenhuma Página abaixo do limite hoje.' : 'Nenhuma Página neste filtro.') + '</td></tr>';
    el('hl-csv').disabled = !shown.length;
  }
  function renderHistory() {
    const list = data?.history || [];
    el('hl-history').innerHTML = list.map(day => '<details class="hl-day"><summary><b>' + esc(dateText(day.date)) + '</b>'
        + '<span><strong>' + day.counts.weak + '</strong> abaixo de ' + number.format(day.limit) + ' plays em ' + esc(days(day.days)) + ' (de ' + day.counts.judged + ' avaliadas)</span>'
        + (day.entered.length || day.left.length ? '<span>+' + day.entered.length + ' entraram · −' + day.left.length + ' saíram</span>' : '')
        + '<span>' + esc(when(day.at).slice(-5)) + (day.origin === 'auto' ? ' · automática' : '') + '</span></summary>'
        + '<p><strong>Abaixo do limite:</strong> ' + (day.weak.length ? day.weak.slice().sort((a, b) => a.plays - b.plays).map(row => esc(row.name) + ' (' + number.format(row.plays) + ')').join(', ') : 'nenhuma') + '</p>'
        + (day.entered.length ? '<p><strong>Entraram na lista:</strong> ' + day.entered.map(esc).join(', ') + '</p>' : '')
        + (day.left.length ? '<p><strong>Saíram da lista:</strong> ' + day.left.map(esc).join(', ') + ' (passaram do limite, foram excluídas ou ficaram inativas)</p>' : '')
        + '</details>').join('') || '<p class="empty">Nenhum dia verificado ainda.</p>';
  }
  async function load() {
    if (loading) return;
    loading = true; render();
    try { data = await api('pages/health'); fillForm(); }
    catch (error) { el('hl-error').hidden = false; el('hl-error').textContent = 'Não foi possível ler a Gestão de Páginas: ' + error.message; }
    finally { loading = false; render(); }
  }
  function schedule() {
    clearTimeout(timer);
    if (location.hash !== '#gestao') return;
    timer = setTimeout(async () => { await load(); schedule(); }, data?.running || data?.meta?.progress?.running ? 2500 : 60000);
  }
  function csv() {
    const cell = value => { const text = String(value ?? ''); return /[";\n\r]/.test(text) ? '"' + text.replaceAll('"', '""') + '"' : text; };
    const current = data.current;
    const head = ['Página', 'Produto', 'ID no Miwra', 'ID no Facebook', 'Nome no Facebook', 'Plays em ' + days(current.days), 'Plays em 24h', 'Reels', 'Plays no total', 'Idade em dias', 'Dias seguidos na lista', 'Na lista desde', 'Situação', 'Observação', 'Status na Meta', 'Detalhe da Meta'];
    const lines = shown.map(row => [row.name, row.product.toUpperCase(), row.id, row.fbPageId, row.facebookName, row.plays, row.plays24, row.videos, row.playsTotal, row.ageDays ?? '', row.streak?.count ?? '', row.streak ? dateText(row.streak.since) : '', LABEL[row.status] || row.status, row.note, row.meta ? META[row.meta.status] || row.meta.status : 'Não conferido', row.meta?.detail || '']);
    const blob = new Blob(['﻿' + [head, ...lines].map(line => line.map(cell).join(';')).join('\r\n') + '\r\n'], { type: 'text/csv;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob); link.download = 'paginas-abaixo-do-limite-' + current.date + '.csv';
    document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(link.href), 5000);
  }
  for (const id of ['hl-limit', 'hl-days', 'hl-hour', 'hl-enabled']) el(id).addEventListener(id === 'hl-enabled' ? 'change' : 'input', () => { dirty = true; render(); });
  for (const id of ['hl-show', 'hl-product']) el(id).addEventListener('change', render);
  el('hl-search').addEventListener('input', render);
  el('hl-save').onclick = guarded(async () => { data = await api('pages/health/settings', form()); dirty = false; fillForm(); render(); });
  el('hl-check').onclick = guarded(async () => {
    if (dirty) { data = await api('pages/health/settings', form()); dirty = false; fillForm(); }
    data = await api('pages/health/check', {}); render(); schedule();
  });
  el('hl-meta-check').onclick = guarded(async () => { data = await api('pages/meta-status/check', {}); render(); schedule(); });
  el('hl-csv').onclick = guarded(async () => { if (!shown.length) throw new Error('Não há Páginas neste filtro para baixar.'); csv(); });
  function enter() { if (location.hash === '#gestao') { void load().then(schedule); } }
  window.addEventListener('hashchange', enter);
  enter();
})();
