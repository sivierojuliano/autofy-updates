// Tela "Postar por API": publica a mesma rodada da tela Publicações pela Graph API da Meta.
// Reaproveita o estado de app.js (rows, settings, runContext, progress…), carregado antes deste arquivo.
(() => {
  const el = id => document.getElementById(id);
  let status = null, checking = false, lastCheck = 0, drawn = '', checkedAccount = null;
  const CHECK_EVERY = 2 * 60000;
  function error(message) { el('api-error').hidden = !message; el('api-error').textContent = message || ''; }
  const readyRows = () => loaded ? rows.filter(page => !slotChanged(page) && page.code === 'ready') : [];
  const hasAccess = page => Boolean(status?.ok && status.pageIds.includes(page.facebookPageId));
  function problem() {
    if (!status) return 'Conferindo a conexão com a Meta…';
    if (!status.tokenConfigured) return currentAccount !== 'main' ? 'Cadastre o token da Meta da conta ' + accountName() + ' em Configurações → Contas do Facebook para publicar as Páginas dela pela API.' : 'Cadastre o token de usuário da Meta em Configurações → Conexão com a Meta para publicar pela API.';
    if (!status.ok) return status.error || 'Não foi possível conferir a conexão com a Meta.';
    if (status.missing.length) return 'O token não tem as permissões necessárias para publicar: ' + status.missing.join(', ') + '. Gere um novo token com elas e salve em Configurações.';
    if (!status.pageCount) return 'O token não retornou nenhuma Página em que o usuário possa criar conteúdo.';
    return '';
  }
  function render() {
    const ready = readyRows(), withAccess = ready.filter(hasAccess), pending = dirty || slotUnsaved;
    const busy = !compatible || running || syncing || importing || slotSaving || dateLoading || checking;
    const blocked = problem();
    el('api-stat-token').textContent = !status ? '—' : !status.tokenConfigured ? 'Sem token' : !status.ok ? 'Com erro' : status.missing.length ? 'Falta permissão' : 'Conectada';
    el('api-stat-pages').textContent = status?.ok ? status.pageCount : '—';
    el('api-stat-ready').textContent = loaded && status?.ok ? withAccess.length : '—';
    el('api-stat-missing').textContent = loaded && status?.ok ? ready.length - withAccess.length : '—';
    const context = runContext();
    el('api-context').textContent = !loaded ? 'Clique em Sincronizar Páginas para carregar a rodada.'
      : pending ? 'Há alterações não salvas em Publicações. Salve antes de publicar pela API.'
      : textsDirty ? 'Há alterações não salvas nos textos da API. Clique em Salvar textos da API antes de publicar.'
      : !contextMatches() ? 'A data ou o slot mudou. Clique em Sincronizar Páginas antes de publicar.'
      : 'Vídeos de ' + context.sourceDate + ' · ' + ({ all: 'Todos (ED + WL)', ed: 'Somente ED', wl: 'Somente WL' })[el('product').value] + ' · Slot ' + chosenSlot() + (context.repost ? ' · republicação' : '') + ' · ' + withAccess.length + ' Página(s) prontas para a API' + (status?.checkedAt ? ' · conexão conferida às ' + new Date(status.checkedAt).toLocaleTimeString('pt-BR') : '');
    error(blocked && status ? blocked : status?.warning ? 'Usando a última lista de Páginas conferida. ' + status.warning : '');
    const can = !busy && !pending && !textsDirty && !textsSaving && loaded && contextMatches() && !blocked && withAccess.length > 0;
    el('api-test').disabled = !can; el('api-publish').disabled = !can;
    el('api-publish').textContent = withAccess.length && !blocked ? 'Publicar rodada pela API (' + withAccess.length + ')' : 'Publicar rodada pela API';
    el('api-stop').disabled = !running;
    el('api-check').disabled = checking || running;
    el('api-pages-info').textContent = loaded ? ready.length + ' Página(s) prontas no Slot ' + chosenSlot() + ' · ' + withAccess.length + ' com acesso pela API' : 'Clique em Sincronizar Páginas para carregar as Páginas.';
    const html = ready.map(page => '<tr><td><span class="product-tag product-' + esc(page.product || 'ed') + '">' + esc((page.product || 'ed').toUpperCase()) + '</span> ' + esc(page.name) + '</td><td>' + esc(page.facebookPageId) + '</td><td>' + (!status?.ok ? '—' : hasAccess(page) ? 'Sim' : '<span class="views-warning">Não — o token não cria conteúdo nesta Página</span>') + '</td></tr>').join('') || '<tr><td colspan="3">' + (loaded ? 'Nenhuma Página pronta neste slot. Veja o diagnóstico em Publicações.' : 'Nenhuma Página carregada.') + '</td></tr>';
    if (html !== drawn) { drawn = html; el('api-rows').innerHTML = html; }
    // O registro é o mesmo da rodada de Publicações (uma operação por vez).
    const logs = el('logs').textContent, box = el('api-logs');
    if (box.textContent !== logs) { box.textContent = logs; box.scrollTop = box.scrollHeight; }
    el('api-run-state').textContent = el('run-state').textContent;
  }
  async function check(refresh = false) {
    if (checking) return;
    checking = true; render();
    // Primeira conferência ou troca de conta (ainda sem status): mostra o aviso de carregando.
    if (!status && location.hash === '#api') window.busyOverlay?.('api', 'Conferindo a conexão com a Meta…');
    const account = currentAccount;
    try { status = await api('api-post/status?' + accountParam() + (refresh ? '&refresh=1' : '')); lastCheck = Date.now(); checkedAccount = account; }
    catch (cause) { status = { tokenConfigured: true, ok: false, canPublish: false, error: cause.message, missing: [], pageCount: 0, pageIds: [], checkedAt: null }; lastCheck = Date.now(); }
    finally { checking = false; window.busyOverlay?.('api', ''); render(); }
  }
  function tick() {
    render(); tabsRender(); textsFill(); permissionRender(); pickRender();
    // Só consulta a Meta com a tela aberta e sem rodada em andamento.
    // Outra conta de Facebook escolhida em Publicações: confere o token dela.
    if (location.hash === '#api' && checkedAccount !== null && checkedAccount !== currentAccount && !checking) { status = null; void check(); return; }
    if (location.hash === '#api' && !running && !checking && Date.now() - lastCheck > CHECK_EVERY) void check();
  }
  for (const [id, mode] of [['api-test', 'test'], ['api-publish', 'publish']]) {
    el(id).onclick = guarded(async () => {
      if (!compatible || slotSaving || syncing || importing || running || dateLoading) throw new Error('Aguarde a operação atual terminar.');
      if (dirty || slotUnsaved) throw new Error('Salve as alterações em Publicações primeiro.');
      if (textsDirty || textsSaving) throw new Error('Salve os textos da API primeiro.');
      if (!loaded || rows.some(slotChanged) || !contextMatches()) throw new Error('Sincronize as Páginas em Publicações antes de iniciar.');
      const count = readyRows().filter(hasAccess).length;
      if (mode === 'publish' && !confirm('Publicar ' + count + ' Reel(s) pela API da Meta agora?\n\nIsso publica de verdade, um vídeo por Página, sem outra confirmação.')) return;
      running = true; render();
      try { await api('start', { mode, method: 'api', ...runContext(), postingSlot: chosenSlot(), product: el('product').value, account: currentAccount }); } catch (cause) { running = false; render(); throw cause; }
      wasRunning = true;
      await progress(); render();
    });
  }
  el('api-stop').onclick = guarded(async () => { await api('stop', { account: currentAccount }); await progress(); render(); });
  el('api-check').onclick = () => { void check(true); };
  // Slot e produto para postar agora: os mesmos controles de Publicações (trocar aqui troca lá, salva e
  // recalcula as Páginas pelo próprio fluxo de lá).
  function pickRender() {
    const busy = !compatible || running || syncing || importing || slotSaving || dateLoading;
    for (const [id, source] of [['api-slot', 'posting-slot'], ['api-product', 'product']]) {
      const mine = el(id), theirs = document.getElementById(source);
      if (document.activeElement !== mine && mine.value !== theirs.value) mine.value = theirs.value;
      mine.disabled = busy;
    }
    el('api-sync').disabled = busy;
    el('api-sync').textContent = syncing ? 'Sincronizando…' : 'Sincronizar Páginas';
  }
  for (const [id, source] of [['api-slot', 'posting-slot'], ['api-product', 'product']]) {
    el(id).addEventListener('change', () => {
      const theirs = document.getElementById(source);
      if (theirs.value === el(id).value) return;
      theirs.value = el(id).value; theirs.dispatchEvent(new Event('change'));
      el(id).blur(); render();
    });
  }
  el('api-sync').onclick = () => { document.getElementById('refresh').click(); };
  // Abas das contas do Facebook no topo da tela: as mesmas de Publicações. Clicar aqui troca a conta
  // lá também (a rodada pela API usa as Páginas carregadas em Publicações).
  let tabsDrawn = '';
  function tabsRender() {
    const extras = (settings.accounts || []).length > 0;
    el('api-acct-bar').hidden = !extras;
    if (!extras) return;
    const html = document.getElementById('acct-tabs').innerHTML;
    if (html !== tabsDrawn) { tabsDrawn = html; el('api-acct-tabs').innerHTML = html; }
    const info = (typeof accountsInfo !== 'undefined' && Array.isArray(accountsInfo) ? accountsInfo : []).find(item => item.id === currentAccount);
    el('api-acct-hint').textContent = 'Postando pela API as Páginas de ' + accountName() + (currentAccount === 'main' ? ', com o token de Configurações → Conexão com a Meta.' : ', com o token desta conta em Configurações → Contas do Facebook.') + (info && info.token && !info.token.tokenConfigured ? ' Esta conta ainda não tem token da Meta.' : '');
  }
  el('api-acct-tabs').addEventListener('click', event => {
    const button = event.target.closest('button[data-account]'); if (!button) return;
    document.querySelector('#acct-tabs button[data-account="' + CSS.escape(button.dataset.account) + '"]')?.click();
  });
  // Descrição e comentário pela API: textos próprios desta tela (começam iguais aos de Publicações).
  const TEXT_FIELDS = [['api-caption-ed', 'apiCaption', 'caption'], ['api-caption-wl', 'apiCaptionWl', 'captionWl'], ['api-comment-ed', 'apiComment', 'comment'], ['api-comment-wl', 'apiCommentWl', 'commentWl']];
  let textsDirty = false, textsSaving = false, textsSig = '';
  const savedTexts = () => ({ ...Object.fromEntries(TEXT_FIELDS.map(([, key, fallback]) => [key, String(settings[key] ?? settings[fallback] ?? '')])),
    apiCommentOn: settings.apiCommentOn === true, apiCommentScope: settings.apiCommentScope ?? settings.commentScope ?? 'new', apiCommentMaxDays: Number(settings.apiCommentMaxDays ?? settings.commentMaxDays ?? 7) });
  const daysView = () => { const all = el('api-comment-scope').value === 'all'; el('api-comment-days-box').hidden = all; el('api-comment-scope-help').hidden = all; };
  function textsFill() {
    if (textsDirty || textsSaving || !settings || !('appVersion' in settings)) return;
    const saved = savedTexts(), sig = JSON.stringify(saved);
    if (sig === textsSig) return;
    textsSig = sig;
    for (const [id, key] of TEXT_FIELDS) el(id).value = saved[key];
    el('api-comment-on').checked = saved.apiCommentOn; el('api-comment-scope').value = saved.apiCommentScope === 'all' ? 'all' : 'new'; el('api-comment-days').value = String(saved.apiCommentMaxDays || 7);
    daysView();
  }
  function textsState(text) { el('api-texts-state').textContent = text; }
  for (const id of ['api-caption-ed', 'api-caption-wl', 'api-comment-ed', 'api-comment-wl', 'api-comment-on', 'api-comment-scope', 'api-comment-days']) {
    el(id).addEventListener(el(id).tagName === 'TEXTAREA' || el(id).type === 'number' ? 'input' : 'change', () => { textsDirty = true; textsState('Alterações não salvas.'); daysView(); render(); });
  }
  el('api-texts-save').onclick = guarded(async () => {
    const days = Number(el('api-comment-days').value);
    if (!Number.isInteger(days) || days < 1 || days > 365) throw new Error('O limite de dias para comentar deve ficar entre 1 e 365.');
    const body = { ...Object.fromEntries(TEXT_FIELDS.map(([id, key]) => [key, el(id).value])), apiCommentOn: el('api-comment-on').checked, apiCommentScope: el('api-comment-scope').value, apiCommentMaxDays: days };
    textsSaving = true; el('api-texts-save').disabled = true; textsState('Salvando…');
    try {
      const saved = await api('api-post/texts', body);
      for (const key of Object.keys(body)) settings[key] = saved[key];   // a tela Publicações salva por cima com os textos novos
      textsDirty = false; textsSig = ''; textsState('Textos da API salvos.');
    } catch (cause) { textsState('Não salvou: ' + cause.message); throw cause; }
    finally { textsSaving = false; el('api-texts-save').disabled = false; textsFill(); render(); }
  });
  // Aviso de permissão: comentário ligado e o token sem pages_manage_engagement.
  function permissionRender() {
    const box = el('api-comment-perm');
    const missing = el('api-comment-on').checked && status?.ok && status.canComment === false;
    box.hidden = !missing;
    if (missing) box.textContent = 'O token ' + (currentAccount === 'main' ? 'da Conexão com a Meta' : 'de ' + accountName()) + ' não tem a permissão pages_manage_engagement: os Reels saem, mas sem comentário. Gere um novo token marcando essa permissão e salve em Configurações.';
  }
  // Programação pela API: até três linhas por conta do Facebook (horário, slot e produto). O servidor
  // guarda à parte das programações de Publicações e, na hora, inicia a mesma rodada do botão
  // "Publicar rodada pela API", na mesma fila das rodadas pelo navegador (uma por conta de cada vez).
  const API_TIMES = ['08:00', '13:00', '18:00'], PRODUCTS = { all: 'Todos (ED + WL)', ed: 'Somente ED', wl: 'Somente WL' };
  const NOTE = el('api-schedule-note').textContent, box = el('api-schedule-rows');
  box.innerHTML = API_TIMES.map((time, index) => {
    const row = index + 1;
    return '<div class="schedule-row" data-row="' + row + '"><b class="schedule-name">Programação ' + row + '</b>'
      + '<label>Horário<input class="schedule-time" type="time" value="' + time + '" aria-label="Horário da programação ' + row + ' pela API"></label>'
      + '<label>Slot<select class="schedule-slot" aria-label="Slot da programação ' + row + ' pela API">' + [1, 2, 3, 4, 5].map(n => '<option value="' + n + '"' + (n === row ? ' selected' : '') + '>Slot ' + n + '</option>').join('') + '</select></label>'
      + '<label>Produto<select class="schedule-product" aria-label="Produto da programação ' + row + ' pela API">' + Object.entries(PRODUCTS).map(([value, label]) => '<option value="' + value + '">' + label + '</option>').join('') + '</select></label>'
      + window.scheduleDays.html()
      + '<button class="schedule-set" type="button">Programar</button><button class="schedule-cancel danger" type="button" hidden>Cancelar</button>'
      + '<p class="hint schedule-state" role="status">Sem programação.</p></div>';
  }).join('');
  let sigs = {}, schedRows = [], schedAccount = null, serverOld = false;
  const several = () => (settings.accounts || []).length > 0;
  // Cada conta tem as suas três linhas: ao trocar de aba no topo, voltam ao padrão e recebem as da conta.
  function scheduleReset() {
    sigs = {}; schedRows = [];
    box.querySelectorAll('.schedule-row').forEach((line, index) => {
      line.querySelector('.schedule-time').value = API_TIMES[index]; line.querySelector('.schedule-slot').value = String(index + 1);
      line.querySelector('.schedule-product').value = PRODUCTS[el('product').value] ? el('product').value : 'all';
      line.querySelector('.schedule-cancel').hidden = true; line.querySelector('.schedule-set').textContent = 'Programar'; window.scheduleDays.set(line, []);
      const state = line.querySelector('.schedule-state'); state.textContent = 'Sem programação.'; state.classList.remove('schedule-on'); line.classList.remove('on');
    });
  }
  window.apiScheduleRender = info => {
    if (!info?.rows) {
      if (!serverOld) { serverOld = true; el('api-schedule-note').textContent = 'Para programar pela API, encerre o Autofy (botão Encerrar) e abra de novo pelo ícone: a atualização ainda não foi carregada.'; }
      return;
    }
    serverOld = false;
    if (info.account !== currentAccount) return;   // resposta de outra aba, chegou atrasada
    if (schedAccount !== info.account) { schedAccount = info.account; scheduleReset(); }
    el('api-schedule-account').textContent = several() ? ' · ' + accountName() : '';
    schedRows = info.rows;
    for (const item of info.rows) {
      // Só redesenha a linha que mudou, para não desfazer o que está sendo digitado nas outras.
      const sig = JSON.stringify(item); if (sigs[item.row] === sig) continue; sigs[item.row] = sig;
      const line = box.querySelector('.schedule-row[data-row="' + item.row + '"]'); if (!line) continue;
      const pending = item.pending, state = line.querySelector('.schedule-state');
      line.querySelector('.schedule-cancel').hidden = !pending; line.querySelector('.schedule-set').textContent = pending ? 'Trocar' : 'Programar';
      if (pending) { line.querySelector('.schedule-time').value = pending.time; line.querySelector('.schedule-slot').value = String(pending.postingSlot); line.querySelector('.schedule-product').value = pending.product; window.scheduleDays.set(line, pending.dates || []); }
      state.textContent = pending
        ? (pending.repeat ? 'Programada em ' + pending.repeat.count + ' dia(s), de ' + pending.repeat.first + ' a ' + pending.repeat.last + ' · próxima ' : 'Programada para ') + pending.label + ' · Slot ' + pending.postingSlot + ' · ' + pending.productLabel + ' · pela API da Meta' + (several() ? ' · ' + pending.accountName : '') + '.' + (pending.queued ? ' Esperando a rodada em andamento desta conta terminar para começar.' : '')
        : item.last ? item.last.message : 'Sem programação.';
      state.classList.toggle('schedule-on', Boolean(pending)); line.classList.toggle('on', Boolean(pending));
    }
    const waiting = info.rows.filter(item => item.pending), others = info.others || [];
    const othersText = others.length ? ' Outras contas: ' + others.map(item => item.name + ' (' + item.count + ' programada(s), a próxima ' + item.next + ')').join(', ') + '.' : '';
    el('api-schedule-note').textContent = waiting.length || others.length
      ? (waiting.length ? waiting.length + ' rodada(s) pela API programada(s)' + (several() ? ' de ' + accountName() : '') + '.' : 'Nenhuma rodada pela API programada de ' + accountName() + '.') + othersText + ' Deixe o computador ligado e na tomada, com o Autofy aberto. Se o computador estiver dormindo na hora, a rodada ainda começa até ' + info.graceMinutes + ' minutos depois. Se outra rodada da mesma conta estiver em andamento, a programada começa assim que ela terminar.'
      : NOTE;
    el('api-schedule-note').classList.toggle('schedule-on', waiting.length > 0 || others.length > 0);
  };
  const scheduleApply = (info, row) => { delete sigs[row]; window.apiScheduleRender(info); };
  box.addEventListener('click', guarded(async event => {
    const button = event.target.closest('button'), line = button?.closest('.schedule-row'); if (!line) return;
    const row = Number(line.dataset.row), account = currentAccount;   // as programações são da conta da aba escolhida no topo
    if (serverOld || !compatible) throw new Error('Encerre o Autofy (botão Encerrar) e abra de novo pelo ícone para usar a programação pela API.');
    if (button.classList.contains('schedule-cancel')) { scheduleApply(await api('schedule/cancel', { row, account, method: 'api' }), row); return; }
    if (button.classList.contains('schedule-days')) { await window.scheduleDays.pick(line, 'Programação ' + row + ' pela API · dias no calendário'); return; }
    if (!button.classList.contains('schedule-set')) return;
    if (dirty || slotUnsaved) throw new Error('Salve as alterações em Publicações antes de programar.');
    if (status && !status.tokenConfigured) throw new Error(problem());
    const time = line.querySelector('.schedule-time').value, slot = Number(line.querySelector('.schedule-slot').value), product = line.querySelector('.schedule-product').value;
    if (!/^\d\d:\d\d$/.test(time)) throw new Error('Escolha o horário da Programação ' + row + '.');
    const same = schedRows.find(item => item.row !== row && item.pending && item.pending.postingSlot === slot);
    if (!confirm('Programar a rodada pela API da Meta do Slot ' + slot + (several() ? ' da conta ' + accountName(account) : '') + ' para começar' + window.scheduleDays.confirmText(window.scheduleDays.get(line), time) + '?\n\n' + PRODUCTS[product] + ', com os vídeos do dia em que a rodada começar. Entram as Páginas marcadas em Publicações que o token da Meta consegue publicar.' + (same ? '\n\nAtenção: a Programação ' + same.row + ' também está com o Slot ' + slot + '. Páginas que já tiverem postado esse slot serão puladas.' : '') + '\n\nNa hora ela publica de verdade, sem outra confirmação. Deixe o computador ligado e na tomada, com o Autofy aberto.')) return;
    scheduleApply(await api('schedule', { row, time, postingSlot: slot, product, account, method: 'api', dates: window.scheduleDays.get(line) }), row);
  }));
  window.addEventListener('hashchange', tick);
  setInterval(tick, 1000);
  tick();
})();
