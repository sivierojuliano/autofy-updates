// Tema claro/escuro do painel. Carregado no <head> para a página já abrir no tema certo (sem piscar).
(function () {
  var KEY = 'jsautopost-tema', root = document.documentElement, theme;
  try { theme = localStorage.getItem(KEY); } catch (e) { theme = null; }
  if (theme !== 'light' && theme !== 'dark') theme = 'light';
  root.setAttribute('data-theme', theme);
  function sync() {
    var light = root.getAttribute('data-theme') === 'light';
    var buttons = document.querySelectorAll('[data-theme-toggle]');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].setAttribute('aria-checked', light ? 'true' : 'false');
      buttons[i].title = light ? 'Tema claro ativo. Clique para o tema escuro.' : 'Tema escuro ativo. Clique para o tema claro.';
    }
  }
  document.addEventListener('click', function (event) {
    var button = event.target && event.target.closest ? event.target.closest('[data-theme-toggle]') : null;
    if (!button) return;
    theme = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
    root.setAttribute('data-theme', theme);
    try { localStorage.setItem(KEY, theme); } catch (e) {}
    sync();
  });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', sync); else sync();
})();
