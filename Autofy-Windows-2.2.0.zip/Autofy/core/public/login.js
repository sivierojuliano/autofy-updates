const form = document.querySelector('#access-form');
form.addEventListener('submit', async event => {
  event.preventDefault();
  const button = document.querySelector('#access-submit'), error = document.querySelector('#access-error'), field = document.querySelector('#access-password');
  button.disabled = true; error.hidden = true;
  try {
    const response = await fetch('/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ password: field.value }) });
    const data = await response.json();
    field.value = '';
    if (!response.ok) throw new Error(data.error || 'Não foi possível entrar.');
    location.replace('/');
  } catch (failure) { error.textContent = failure.message; error.hidden = false; }
  finally { button.disabled = false; }
});
