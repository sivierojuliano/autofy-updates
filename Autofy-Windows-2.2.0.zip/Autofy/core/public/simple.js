// Autofy Simples: uma tela só. Usa as mesmas rotas e travas do painel completo
// (histórico contra reenvio, conferência do slot no Miwra, uma operação por vez).
(() => {
  const $ = id => document.getElementById(id);
  const key = document.querySelector('meta[name=publisher-key]').content;
  let settings = {}, token = null, data = null, running = false, preparing = false, importTried = false, lastRun = null, edited = new Set();

  async function api(path, body) {
    const response = await fetch('/api/' + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'x-publisher-key': key, 'content-type': 'application/json' }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) { const error = new Error(result.error || 'Não deu certo (erro ' + response.status + ').'); error.status = response.status; error.data = result; throw error; }
    return result;
  }
  function notice(text) { $('notice').hidden = !text; $('notice').textContent = text || ''; if (text) $('notice').scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  const guarded = action => async () => { try { notice(''); await action(); } catch (error) { notice(error.message); } finally { render(); } };
  const miwraOk = () => Boolean(settings.cookieConfigured && settings.baseUrl && settings.profile);
  const tokenOk = () => Boolean(token?.tokenConfigured && token?.ok);
  for (const id of ['base-url', 'profile', 'cookie', 'token', 'caption-ed', 'caption-wl']) $(id).addEventListener('input', () => edited.add(id));

  function setChip(step, done, text) { $(step).classList.toggle('ok', done); $(step + '-chip').textContent = text; }
  function fill() {
    if (!edited.has('base-url')) $('base-url').value = settings.baseUrl || '';
    if (!edited.has('profile')) $('profile').value = settings.profile || '';
    if (!edited.has('caption-ed')) $('caption-ed').value = settings.apiCaption ?? settings.caption ?? '';
    if (!edited.has('caption-wl')) $('caption-wl').value = settings.apiCaptionWl ?? settings.captionWl ?? '';
    $('cookie').placeholder = settings.cookieConfigured ? 'Cookie salvo. Cole um novo só se o Miwra pedir.' : 'Cole aqui o cookie (fica salvo só neste computador)';
    $('token').placeholder = token?.tokenConfigured ? 'Token salvo. Cole um novo só quando vencer.' : 'Cole aqui o token (fica salvo só neste computador)';
  }
  function render() {
    setChip('s1', miwraOk(), miwraOk() ? 'Pronto' : 'Pendente');
    setChip('s2', tokenOk(), tokenOk() ? 'Pronto' : token?.tokenConfigured ? 'Com problema' : 'Pendente');
    $('token-state').textContent = !token ? '' : !token.tokenConfigured ? 'Nenhum token salvo.' : token.ok ? 'Conectado: o token alcança ' + token.pageCount + ' Página(s).' + (token.missing?.length ? ' Falta a permissão ' + token.missing.join(', ') + '.' : '') : 'O token não funcionou: ' + (token.error || 'confira e cole de novo.');
    const textsOk = Boolean((settings.apiCaption ?? settings.caption) || (settings.apiCaptionWl ?? settings.captionWl));
    setChip('s4', textsOk, textsOk ? 'Pronto' : 'Pendente');
    const allOk = miwraOk() && textsOk;
    $('setup-chip').textContent = allOk ? 'Tudo certo' : 'Faça uma vez';
    $('setup').classList.toggle('ok', allOk);
    const ready = data ? data.pages.filter(page => page.code === 'ready').length : 0;
    const busy = running || preparing;
    $('post-api').disabled = busy || !ready || !tokenOk();
    $('post-chrome').disabled = busy || !ready;
    $('test').disabled = busy || !ready;
    $('stop').disabled = !running;
    $('refresh').disabled = busy || !miwraOk();
    $('slot').disabled = busy || !miwraOk();
    for (const id of ['save-miwra', 'save-token', 'save-texts', 'login']) $(id).disabled = running;
  }
  function countText() {
    if (!miwraOk()) return 'Faça o passo 1 da Configuração (Miwra) para ver as Páginas.';
    if (!data) return preparing ? 'Conferindo as Páginas e os vídeos no Miwra…' : '';
    const pages = data.pages, by = code => pages.filter(page => page.code === code).length;
    const ready = by('ready'), unmapped = by('unmapped'), blocked = by('blocked');
    const posted = pages.filter(page => page.slots?.[data.postingSlot - 1]?.code === 'posted').length;
    const other = pages.length - ready - unmapped - blocked - posted;
    const parts = [posted && posted + ' já postada(s) neste slot', other > 0 && other + ' sem vídeo pronto neste slot', unmapped && unmapped + ' sem o ID do Facebook' + (tokenOk() ? '' : ' (salve o token no passo 2 para buscar)'), blocked && blocked + ' bloqueada(s) por envio anterior'].filter(Boolean);
    return '<b>' + ready + '</b> Página(s) prontas para postar no Slot ' + data.postingSlot + ' (de ' + pages.length + ' Páginas ativas).' + (parts.length ? '<br><span class="help">Fora: ' + parts.join(' · ') + '.</span>' : '');
  }
  function showCount() { $('count').innerHTML = countText(); }

  async function loadSettings() { settings = await api('settings'); $('slot').value = String(settings.postingSlot || 1); fill(); }
  async function loadToken() { try { token = await api('api-post/status?account=main'); } catch (error) { token = { tokenConfigured: true, ok: false, error: error.message }; } fill(); }

  // Confere slot, marca todas as Páginas ativas e busca os IDs do Facebook que faltam (uma vez).
  async function prepare(force = false) {
    if (!miwraOk() || running || preparing) { showCount(); render(); return; }
    preparing = true; data = null; showCount(); render();
    try {
      const slot = Number($('slot').value);
      if (settings.postingSlot !== slot) settings = await api('settings', { postingSlot: slot });
      const read = () => api('preview?account=main' + (force ? '&refresh=1' : ''));
      let preview = await read();
      const ids = preview.pages.map(page => page.id);
      if (preview.pages.some(page => !page.selected)) { settings = await api('settings', { selected: ids }); preview = await read(); }
      if (!importTried && tokenOk() && preview.pages.some(page => page.code === 'unmapped')) {
        importTried = true;
        showCount(); $('count').textContent = 'Buscando os IDs das Páginas na Meta…';
        await api('pages/import-ids', {}).catch(() => {});
        await loadSettings(); preview = await read();
      }
      data = preview;
    } finally { preparing = false; showCount(); render(); }
  }

  async function start(method, mode) {
    const ready = data.pages.filter(page => page.code === 'ready').length;
    const how = method === 'api' ? 'pela API (sem Chrome)' : 'pelo Chrome';
    if (!confirm(mode === 'test' ? 'Postar 1 vídeo de teste ' + how + ' agora?\n\nÉ uma postagem de verdade.' : 'Postar ' + ready + ' vídeo(s) do Slot ' + data.postingSlot + ' ' + how + ' agora?\n\nIsso publica de verdade, um vídeo por Página, sem outra confirmação.')) return;
    await api('start', { mode, method, sourceDate: data.sourceDate, publicationDate: data.publicationDate, repost: false, postingSlot: data.postingSlot, product: data.product || 'all', account: 'main' });
    running = true; lastRun = { method, mode }; $('result').hidden = true; $('progress').hidden = false;
    render(); poll();
  }
  const OK = ['posted', 'sent_synced', 'pending_sync', 'sent_pending_sync'];
  async function poll() {
    let progress;
    try { progress = await api('progress?account=main'); } catch { setTimeout(poll, 4000); return; }
    const results = progress.results || [], total = progress.total || 0;
    const wasRunning = running;
    running = Boolean(progress.running);
    if (running || wasRunning) {
      $('progress').hidden = false;
      $('progress-text').textContent = running ? (total ? 'Postando ' + Math.min(results.length + 1, total) + ' de ' + total + (progress.current?.pageName ? ' · ' + progress.current.pageName : '') : 'Preparando a rodada…') : 'Rodada terminada.';
      $('progress-bar').style.width = total ? Math.round(results.length / total * 100) + '%' : '0%';
      const lines = (progress.logs || []).slice(-60).map(line => line.at + '  ' + line.message).join('\n');
      if ($('log').textContent !== lines) { $('log').textContent = lines; $('log').scrollTop = $('log').scrollHeight; }
    }
    if (wasRunning && !running) {
      const good = results.filter(item => OK.includes(item.status)).length, failed = results.filter(item => item.status === 'failed').length, unsure = results.filter(item => item.status === 'uncertain').length;
      const box = $('result');
      box.hidden = false;
      box.className = 'msg ' + (progress.error ? 'bad' : failed || unsure ? 'warn' : 'good');
      box.textContent = progress.error ? 'A rodada parou: ' + progress.error : 'Pronto! ' + good + ' vídeo(s) postado(s).' + (failed ? ' ' + failed + ' falharam (veja o registro acima).' : '') + (unsure ? ' ' + unsure + ' ficaram incertos: confira essas Páginas no Facebook antes de postar de novo.' : '');
      render(); await prepare().catch(error => notice(error.message));
    }
    render();
    setTimeout(poll, running ? 2000 : 10000);
  }

  $('save-miwra').onclick = guarded(async () => {
    const body = { baseUrl: $('base-url').value.trim(), profile: $('profile').value.trim() };
    if ($('cookie').value.trim()) body.cookie = $('cookie').value.trim();
    if (!body.baseUrl || !body.profile) throw new Error('Preencha o endereço do Miwra e o seu perfil.');
    if (!body.cookie && !settings.cookieConfigured) throw new Error('Cole o cookie do Miwra.');
    settings = await api('settings', body);
    $('cookie').value = ''; edited.delete('base-url'); edited.delete('profile'); edited.delete('cookie'); fill();
    await prepare(true);
  });
  $('save-token').onclick = guarded(async () => {
    const value = $('token').value.trim();
    if (!value) throw new Error('Cole o token da Meta.');
    $('token-state').textContent = 'Conferindo o token na Meta…';
    await api('views/settings', { token: value, enabled: false });
    $('token').value = ''; edited.delete('token'); importTried = false;
    await loadToken(); render(); await prepare();
  });
  $('login').onclick = guarded(async () => {
    await api('login', { browser: 'chrome' });
    setChip('s3', true, 'Janela aberta');
    notice('');
    alert('Uma janela do Chrome abriu. Entre com o seu Facebook nela e depois pode fechá-la.');
  });
  $('save-texts').onclick = guarded(async () => {
    const ed = $('caption-ed').value, wl = $('caption-wl').value;
    settings = await api('settings', { caption: ed, captionWl: wl, apiCaption: ed, apiCaptionWl: wl });
    edited.delete('caption-ed'); edited.delete('caption-wl'); fill();
    $('texts-state').textContent = 'Textos salvos.';
  });
  $('slot').onchange = guarded(() => prepare());
  $('refresh').onclick = guarded(() => prepare(true));
  $('post-api').onclick = guarded(() => start('api', 'publish'));
  $('post-chrome').onclick = guarded(() => start('chrome', 'publish'));
  $('test').onclick = guarded(() => start(tokenOk() ? 'api' : 'chrome', 'test'));
  $('stop').onclick = guarded(async () => { await api('stop', { account: 'main' }); $('progress-text').textContent = 'Parando… a Página que está no meio termina e nenhuma nova começa.'; });
  $('close').onclick = guarded(async () => {
    if (running) throw new Error('Há uma postagem em andamento. Clique em Parar e espere terminar antes de fechar.');
    if (!confirm('Fechar o Autofy Simples?')) return;
    await api('shutdown', { force: false });
    document.body.innerHTML = '<main><div class="card"><h2>Programa fechado</h2><p>Pode fechar esta aba. Para abrir de novo, use o atalho do modo Simples na Área de Trabalho.</p></div></main>';
  });

  (async () => {
    try { await loadSettings(); await loadToken(); render(); $('setup').open = !$('setup').classList.contains('ok'); } catch (error) { notice(error.message); }
    poll();
    await prepare().catch(error => notice(error.message));
  })();
})();
