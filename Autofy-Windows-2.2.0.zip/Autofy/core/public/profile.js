// Tela "Dados das Páginas": banco de descrições e cidades sorteadas para cada Página, gravadas pela
// API da Meta numa fila com limite por dia (lib/page-profile.mjs). Usa api(), esc(), guarded() e
// notice() de app.js. Nenhum token passa por aqui.
(() => {
  const el = id => document.getElementById(id);
  const stamp = new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const when = time => time ? stamp.format(new Date(time)).replace(', ', ' às ') : '';
  const PRODUCT = { all: 'ED + WL', ed: 'ED', wl: 'WL' };
  const FIELD = { about: 'Descrição', location: 'Localização', website: 'Link' };
  const FIELDS = ['about', 'location', 'website'];
  const ACTION = { apply: 'Gravando a fila', test: 'Testando 1 Página', check: 'Conferindo na Meta' };
  let report = null, list = null, loading = false, timer = null, entered = false, settingsReady = false, ticket = 0;
  // Aba escolhida (conta do Facebook): fica lembrada neste navegador.
  let current = (() => { try { return localStorage.getItem('jsautopost-dados-conta') || ''; } catch { return ''; } })();
  const selected = new Set();
  let shown = [];

  const running = () => Boolean(report?.progress?.running);
  const fields = () => FIELDS.filter(field => el('pp-field-' + field).checked);
  const record = row => report?.records?.[row.id] || row.record || null;
  const preview = row => report?.previews?.[row.id] || row.preview || {};
  const queued = row => (report?.queue?.ids || []).includes(row.id);
  const profiles = () => report?.profiles || (report?.accounts || []).map((item, index) => ({ ...item, main: index === 0, token: true }));
  const profile = () => { const all = profiles(); return all.find(item => item.account === current) || all[0] || null; };
  const account = () => profile()?.account || '';
  const accountName = id => profiles().find(item => item.account === id)?.name || '';
  const accountInfo = () => (report?.accounts || []).find(item => item.account === account()) || null;
  function state(row) {
    const r = record(row);
    if (!r) return 'pending';
    const values = FIELDS.map(field => r[field]?.state).filter(Boolean);
    if (values.includes('failed')) return 'failed';
    return values.includes('ok') ? 'done' : 'pending';
  }

  // --- banco
  function renderBank() {
    if (!report) return;
    const used = report.usage || { descriptions: {}, cities: {} };
    el('pp-desc-count').textContent = report.descriptions.length;
    const links = report.links || [];
    el('pp-link-count').textContent = links.length;
    const linkRows = links.map(item => '<tr>'
      + '<td class="pp-wide"><a href="' + esc(item.url) + '" target="_blank" rel="noopener noreferrer">' + esc(item.url) + '</a></td>'
      + '<td>' + esc(PRODUCT[item.product] || item.product) + '</td>'
      + '<td>' + ((used.links || {})[item.id] || 0) + '</td>'
      + '<td class="pp-remove"><button type="button" class="link-button" data-remove-link="' + esc(item.id) + '" aria-label="Remover o link">Remover</button></td></tr>').join('')
      || '<tr><td colspan="4" class="empty">Nenhum link ainda. Cole um por linha acima e clique em Adicionar ao banco.</td></tr>';
    if (el('pp-link-rows').dataset.sig !== linkRows) { el('pp-link-rows').innerHTML = linkRows; el('pp-link-rows').dataset.sig = linkRows; }
    el('pp-city-count').textContent = report.cities.filter(city => city.enabled).length + ' de ' + report.cities.length;
    el('pp-desc-rows').innerHTML = report.descriptions.map(item => '<tr>'
      + '<td class="pp-wide">' + esc(item.text) + '<small>' + item.text.length + ' caractere(s)' + (item.text.includes('{') ? ' antes de trocar {nome}/{cidade}' : '') + '</small></td>'
      + '<td>' + esc(PRODUCT[item.product] || item.product) + '</td>'
      + '<td>' + (used.descriptions[item.id] || 0) + '</td>'
      + '<td class="pp-remove"><button type="button" class="link-button" data-remove-desc="' + esc(item.id) + '" aria-label="Remover a descrição">Remover</button></td></tr>').join('')
      || '<tr><td colspan="4" class="empty">Nenhuma descrição ainda. Escreva uma por linha acima e clique em Adicionar ao banco.</td></tr>';
    const name = code => (report.countries.find(([c]) => c === code) || [code, code])[1];
    el('pp-city-rows').innerHTML = report.cities.map(city => '<tr' + (city.enabled ? '' : ' class="pp-off"') + '>'
      + '<td class="cr-pick"><input type="checkbox" data-city-toggle="' + esc(city.id) + '"' + (city.enabled ? ' checked' : '') + ' aria-label="Usar ' + esc(city.city) + ' no sorteio"></td>'
      + '<td class="pp-wide">' + esc(city.city) + (city.state ? ', ' + esc(city.state) : '') + '<small>' + esc(name(city.country)) + (city.lat !== null && city.lng !== null ? ' · ' + city.lat + ', ' + city.lng : ' · sem coordenadas') + '</small></td>'
      + '<td>' + (used.cities[city.id] || 0) + '</td>'
      + '<td class="pp-remove"><button type="button" class="link-button" data-remove-city="' + esc(city.id) + '" aria-label="Remover ' + esc(city.city) + '">Remover</button></td></tr>').join('')
      || '<tr><td colspan="4" class="empty">Nenhuma cidade. Clique em Repor cidades padrão.</td></tr>';
    if (!el('pp-city-country').options.length) el('pp-city-country').innerHTML = report.countries.map(([code, label]) => '<option value="' + esc(code) + '">' + esc(label) + '</option>').join('');
    const boxes = report.countries.map(([code, label]) => '<label><input type="checkbox" value="' + esc(code) + '"' + (report.settings.cityCountries.includes(code) ? ' checked' : '') + '> ' + esc(label) + '</label>').join('');
    if (el('pp-city-countries').dataset.sig !== boxes) { el('pp-city-countries').innerHTML = boxes; el('pp-city-countries').dataset.sig = boxes; }
  }
  function renderSettings(force = false) {
    if (!report || (settingsReady && !force)) return;
    const s = report.settings;
    el('pp-limit').value = s.dailyLimit; el('pp-pause-min').value = s.pauseMin; el('pp-pause-max').value = s.pauseMax;
    for (const field of FIELDS) el('pp-field-' + field).checked = s.fields.includes(field);
    settingsReady = true;
  }
  // Abas: todas as contas do Facebook do Autofy (com ou sem token da Meta).
  function renderTabs() {
    const all = profiles(), chosen = profile(), progress = report?.progress;
    if (chosen) current = chosen.account;
    el('pp-acct-bar').hidden = all.length < 2;
    const tabs = all.map(item => {
      const busy = progress?.running && progress.account === item.account, info = (report?.accounts || []).find(entry => entry.account === item.account);
      const note = busy ? ACTION[progress.action] + ' · ' + progress.done + '/' + progress.total : !item.token ? 'Sem token da Meta' : info?.queued ? info.queued + ' na fila · hoje ' + info.today : info?.today ? 'Hoje ' + info.today + ' gravada(s)' : 'Token salvo';
      return '<button type="button" role="tab" data-account="' + esc(item.account) + '" aria-selected="' + (item.account === current) + '" class="acct-tab' + (busy ? ' running' : '') + (item.token ? '' : ' no-token') + '"><b>' + esc(item.name) + '</b><small>' + esc(note + (item.main ? ' · principal' : '')) + '</small></button>';
    }).join('');
    if (el('pp-tabs').dataset.sig !== tabs) { el('pp-tabs').innerHTML = tabs; el('pp-tabs').dataset.sig = tabs; }
    const missing = Boolean(chosen && !chosen.token);
    el('pp-notoken').hidden = !missing;
    if (missing) el('pp-notoken-name').textContent = chosen.name;
    el('pp-notoken-login').hidden = !missing || chosen.main;
    el('pp-stats').hidden = missing; el('pp-list-card').hidden = missing;
  }
  function stateText() {
    const p = report?.progress, q = report?.queue;
    if (!p) return 'Aguardando';
    if (p.running) {
      const next = p.nextAt ? Math.max(0, Math.round((Date.parse(p.nextAt) - Date.now()) / 1000)) : null;
      return ACTION[p.action] + ' · ' + p.done + '/' + p.total + (p.account && p.account !== current && accountName(p.account) ? ' · ' + accountName(p.account) : '') + (next !== null ? ' · próxima em ' + next + ' s' : '');
    }
    if (q?.total && q.paused) return 'Fila parada · ' + q.total + ' na fila';
    if (q?.total && q.resumeAt) return 'Fila esperando a Meta · ' + q.total + ' na fila';
    if (q?.total) return 'Fila aguardando · ' + q.total + ' na fila';
    return { done: 'Concluído', stopped: 'Parado', error: 'Parou com erro', waiting: 'Fila aguardando' }[p.phase] || 'Aguardando';
  }
  function fieldNote(r, field) {
    const item = r?.[field];
    if (!item) return '';
    if (item.state === 'ok') return '<span class="cr-badge cr-applied">' + FIELD[field] + (field === 'website' ? ' gravado' : ' gravada') + '</span><small>' + esc(when(item.at)) + (item.confirmed ? ' · conferido na Meta' : item.confirmed === false ? ' · a Meta devolveu outro valor ao conferir' : '') + (field === 'location' && item.label ? ' · ' + esc(item.label) : '') + (field === 'website' && item.url ? ' · ' + esc(item.url) : '') + '</small>';
    return '<span class="cr-badge cr-failed">' + FIELD[field] + ': falhou</span><small>' + esc(item.error || '') + '</small>';
  }
  function situation(row) {
    const r = record(row), notes = [];
    if (queued(row)) notes.push('<span class="cr-badge cr-other">Na fila</span>');
    const parts = FIELDS.map(field => fieldNote(r, field)).filter(Boolean);
    if (!parts.length && !queued(row)) notes.push('<span class="cr-badge">Ainda não gravada</span>');
    notes.push(...parts);
    if (r?.current && r.checkedAt) {
      const loc = r.current.location;
      notes.push('<small>Na Meta (' + esc(when(r.checkedAt)) + '): ' + (r.current.about ? '“' + esc(r.current.about) + '”' : 'sem descrição') + ' · ' + (loc?.city ? esc(loc.city + (loc.state ? ', ' + loc.state : '')) : 'sem localização') + ' · ' + (r.current.website ? esc(r.current.website) : 'sem link') + '</small>');
    }
    if (r?.checkError) notes.push('<small>Conferência: ' + esc(r.checkError) + '</small>');
    if (row.manage === false) notes.push('<small>O token pode não ter acesso total a esta Página.</small>');
    return notes.join('');
  }
  function render() {
    renderTabs(); renderBank(); renderSettings();
    const busy = loading || running(), progress = report?.progress, q = report?.queue || { total: 0 };
    el('pp-load').disabled = loading || !profile()?.token;
    el('pp-stop').hidden = !running();
    el('pp-resume').hidden = running() || !q.total;
    el('pp-cancel').hidden = !q.total;
    el('pp-state').textContent = stateText();
    const logs = progress?.logs?.length ? progress.logs.map(line => line.at + '  ' + line.message).join('\n') : 'Sem atividade.';
    if (el('pp-log').textContent !== logs) { el('pp-log').textContent = logs; el('pp-log').scrollTop = el('pp-log').scrollHeight; }
    if (report && profile() && !profile().token) el('pp-status').textContent = 'A conta ' + profile().name + ' ainda não tem token da Meta: veja abaixo como cadastrar.';
    const rows = list?.rows || [], marked = rows.filter(row => selected.has(row.id)), none = !fields().length;
    el('pp-draw').disabled = loading || !marked.length;
    el('pp-redraw').disabled = loading || !marked.length;
    el('pp-test').disabled = busy || !marked.length || none;
    el('pp-apply').disabled = loading || !marked.length || none;
    el('pp-check').disabled = busy || !marked.length;
    el('pp-apply').textContent = 'Aplicar nas marcadas' + (marked.length ? ' (' + marked.length + ')' : '');
    const faltam = list ? missing().length : 0;
    el('pp-apply-missing').disabled = loading || !list || !faltam || none;
    el('pp-apply-missing').textContent = 'Aplicar nas que não têm' + (list ? ' (' + faltam + ')' : '');
    const info = accountInfo();
    el('pp-stat-queue').textContent = q.total + ' · ' + (info ? info.today : 0) + '/' + (report?.settings?.dailyLimit || 0);
    if (!list) return;
    el('pp-stat-total').textContent = rows.length;
    el('pp-stat-drawn').textContent = rows.filter(row => preview(row).drawn).length;
    el('pp-stat-done').textContent = rows.filter(row => state(row) === 'done').length;
    const show = el('pp-show').value, product = el('pp-product').value, search = el('pp-search').value.trim().toLocaleLowerCase('pt-BR');
    const wanted = { active: row => row.miwra?.active, all: () => true, nodraw: row => !preview(row).drawn, pending: row => state(row) === 'pending', done: row => state(row) === 'done', failed: row => state(row) === 'failed', queued }[show];
    shown = rows.filter(row => wanted(row) && (product === 'all' || row.miwra?.product === product) && (!search || row.name.toLocaleLowerCase('pt-BR').includes(search) || (row.miwra?.name || '').toLocaleLowerCase('pt-BR').includes(search) || row.id.includes(search)));
    el('pp-summary').textContent = 'Exibindo ' + shown.length + ' de ' + rows.length + ' Página(s) do token de ' + list.accountName + ' · ' + marked.length + ' marcada(s).';
    el('pp-select-all').checked = shown.length > 0 && shown.every(row => selected.has(row.id));
    el('pp-rows').innerHTML = shown.map(row => {
      const p = preview(row);
      const about = !p.drawn ? '<span class="muted">Ainda não sorteada</span>' : p.about ? esc(p.about) + '<small' + (p.tooLong ? ' class="pp-too-long"' : '') + '>' + p.length + '/' + report.aboutLimit + ' caracteres' + (p.tooLong ? ' · longa demais: encurte no banco ou sorteie outra' : '') + '</small>' : '<span class="muted">Sem descrição para o produto desta Página</span>';
      const link = p.drawn && fields().includes('website') ? (p.link ? '<small>Link: ' + esc(p.link) + '</small>' : '<small class="muted">Sem link para o produto desta Página</small>') : '';
      const city = !p.drawn ? '<span class="muted">—</span>' : p.city ? esc(p.city) : '<span class="muted">Sem cidade nos países escolhidos</span>';
      return '<tr>'
        + '<td class="cr-pick"><input type="checkbox" data-id="' + esc(row.id) + '"' + (selected.has(row.id) ? ' checked' : '') + (loading ? ' disabled' : '') + ' aria-label="Marcar ' + esc(row.name) + '"></td>'
        + '<td>' + (row.miwra ? '<span class="product-tag product-' + esc(row.miwra.product) + '">' + esc(row.miwra.product.toUpperCase()) + '</span> ' : '') + esc(row.name)
          + '<small>Facebook ' + esc(row.id) + (row.miwra ? ' · ' + (row.miwra.active ? 'ativa' : 'inativa') + ' no Miwra' : ' · fora do Miwra') + '</small>'
          + '<small><a href="https://www.facebook.com/' + esc(row.id) + '" target="_blank" rel="noopener noreferrer">Abrir Página</a></small></td>'
        + '<td class="pp-about">' + about + link + '</td><td>' + city + '</td><td>' + situation(row) + '</td></tr>';
    }).join('') || '<tr><td colspan="5" class="empty">Nenhuma Página neste filtro.</td></tr>';
  }
  function poll() {
    clearTimeout(timer);
    if (location.hash !== '#dados') return;
    // Rodando: a cada 2 s. Com fila esperando (limite do dia, espera da Meta): a cada 30 s.
    const ms = running() ? 2000 : report?.queue?.total ? 30000 : 0;
    if (ms) timer = setTimeout(() => refresh().catch(() => {}), ms);
  }
  async function refresh() { report = await api('profile'); render(); poll(); }
  async function load() {
    if (!profile()?.token) { list = null; render(); return; }
    const mine = ++ticket, asked = current;
    loading = true; render();
    el('pp-status').textContent = 'Lendo as Páginas no token da Meta e a situação delas no Miwra (pode levar até 1 minuto)…'; el('pp-warning').hidden = true;
    try {
      const fresh = await api('profile/pages', { account: asked || undefined });
      if (asked !== current) return;   // trocou de aba enquanto carregava
      list = fresh;
      report = { ...report, ...list };
      if (!selected.size && !list.miwraMissing) for (const row of list.rows) if (row.miwra?.active) selected.add(row.id);
      if (list.miwraMissing && el('pp-show').value === 'active') el('pp-show').value = 'all';
      for (const id of [...selected]) if (!list.rows.some(row => row.id === id)) selected.delete(id);
      el('pp-status').textContent = list.rows.length + ' Página(s) no token de ' + list.accountName + ', ' + list.rows.filter(row => row.miwra?.active).length + ' ativa(s) no Miwra.';
      const warnings = [];
      if (list.miwraMissing) warnings.push('O Miwra não respondeu a tempo: a lista mostra todas as Páginas do token, sem a situação no Miwra e sem marcar nenhuma. Clique em Carregar Páginas de novo daqui a pouco.');
      if (list.permission === false) warnings.push('O token desta conta não tem a permissão pages_manage_metadata, que a Meta exige para mudar os dados da Página. Gere o token de novo marcando também pages_manage_metadata (Parte 4 do tutorial) e salve em Configurações.');
      el('pp-warning').hidden = !warnings.length; el('pp-warning').textContent = warnings.join(' ');
    } finally { if (mine === ticket) loading = false; render(); poll(); }
  }
  const marked = () => (list?.rows || []).filter(row => selected.has(row.id));
  // Faltam: ativas no Miwra (todas do token se o Miwra não respondeu), do produto do filtro, que ainda não têm
  // gravado na Meta algum dos campos marcados em "Gravar" e que não estão na fila.
  function missing() {
    const product = el('pp-product').value, chosen = fields();
    return (list?.rows || []).filter(row => (list.miwraMissing || row.miwra?.active) && (product === 'all' || row.miwra?.product === product) && !queued(row) && chosen.some(field => record(row)?.[field]?.state !== 'ok'));
  }
  async function saveBank(change) { report = { ...report, ...(await api('profile/bank', change)) }; render(); }
  async function saveSettings(change) { report = { ...report, ...(await api('profile/settings', change)) }; renderSettings(true); render(); }
  async function start(action, ids) {
    report = { ...report, ...(await api('profile/start', { account: account(), ids, fields: fields(), action })) };
    render(); clearTimeout(timer); timer = setTimeout(() => refresh().catch(() => {}), 1500);
  }

  el('pp-desc-add').onclick = guarded(async () => {
    const lines = el('pp-desc-new').value.split('\n').map(line => line.trim()).filter(Boolean);
    if (!lines.length) throw new Error('Escreva pelo menos uma descrição (uma por linha).');
    const long = lines.find(line => line.length > report.aboutLimit);
    if (long) throw new Error('Esta descrição tem ' + long.length + ' caracteres (a Meta aceita até ' + report.aboutLimit + '): ' + long.slice(0, 60) + '…');
    const before = report.descriptions.length;
    await saveBank({ descriptions: [...report.descriptions, ...lines.map(text => ({ text, product: el('pp-desc-product').value }))] });
    const added = report.descriptions.length - before;
    el('pp-desc-new').value = '';
    el('pp-desc-hint').textContent = added + ' descrição(ões) adicionada(s)' + (added < lines.length ? '; ' + (lines.length - added) + ' já estava(m) no banco.' : '.');
  });
  el('pp-link-add').onclick = guarded(async () => {
    const lines = el('pp-link-new').value.split('\n').map(line => line.trim()).filter(Boolean);
    if (!lines.length) throw new Error('Cole pelo menos um link (um por linha).');
    const before = (report.links || []).length;
    await saveBank({ links: [...(report.links || []), ...lines.map(url => ({ url, product: el('pp-link-product').value }))] });
    const added = report.links.length - before;
    el('pp-link-new').value = '';
    el('pp-link-hint').textContent = added + ' link(s) adicionado(s)' + (added < lines.length ? '; ' + (lines.length - added) + ' já estava(m) no banco.' : '.');
  });
  el('pp-link-rows').addEventListener('click', guarded(async event => {
    const button = event.target.closest('[data-remove-link]'); if (!button) return;
    const id = button.dataset.removeLink, used = (report.usage.links || {})[id] || 0;
    if (used && !confirm('Remover este link do banco?\n\n' + used + ' Página(s) estão com ele sorteado. Na próxima vez que aplicar, elas recebem outro (o que já foi gravado na Meta não muda sozinho).')) return;
    await saveBank({ links: report.links.filter(item => item.id !== id) });
  }));
  el('pp-desc-rows').addEventListener('click', guarded(async event => {
    const button = event.target.closest('[data-remove-desc]'); if (!button) return;
    const id = button.dataset.removeDesc, used = report.usage.descriptions[id] || 0;
    if (used && !confirm('Remover esta descrição do banco?\n\n' + used + ' Página(s) estão com ela sorteada. Na próxima vez que aplicar, elas recebem outra (o que já foi gravado na Meta não muda sozinho).')) return;
    await saveBank({ descriptions: report.descriptions.filter(item => item.id !== id) });
  }));
  el('pp-city-add').onclick = guarded(async () => {
    const city = el('pp-city-name').value.trim();
    if (!city) throw new Error('Escreva o nome da cidade.');
    await saveBank({ cities: [...report.cities, { city, state: el('pp-city-state').value.trim(), country: el('pp-city-country').value, lat: el('pp-city-lat').value.trim().replace(',', '.'), lng: el('pp-city-lng').value.trim().replace(',', '.') }] });
    for (const id of ['pp-city-name', 'pp-city-state', 'pp-city-lat', 'pp-city-lng']) el(id).value = '';
  });
  el('pp-city-rows').addEventListener('change', guarded(async event => {
    const box = event.target.closest('[data-city-toggle]'); if (!box) return;
    await saveBank({ cities: report.cities.map(city => city.id === box.dataset.cityToggle ? { ...city, enabled: box.checked } : city) });
  }));
  el('pp-city-rows').addEventListener('click', guarded(async event => {
    const button = event.target.closest('[data-remove-city]'); if (!button) return;
    const id = button.dataset.removeCity, used = report.usage.cities[id] || 0;
    if (used && !confirm('Remover esta cidade do banco?\n\n' + used + ' Página(s) estão com ela sorteada. Na próxima vez que aplicar, elas recebem outra.')) return;
    await saveBank({ cities: report.cities.filter(city => city.id !== id) });
  }));
  el('pp-city-restore').onclick = guarded(async () => { await saveBank({ restoreCities: true }); });
  el('pp-city-countries').addEventListener('change', guarded(async () => {
    const codes = [...el('pp-city-countries').querySelectorAll('input:checked')].map(input => input.value);
    if (!codes.length) { render(); throw new Error('Marque pelo menos um país para sortear as cidades.'); }
    await saveSettings({ cityCountries: codes });
  }));
  for (const id of ['pp-limit', 'pp-pause-min', 'pp-pause-max']) el(id).addEventListener('change', guarded(async () => {
    await saveSettings({ dailyLimit: el('pp-limit').value, pauseMin: el('pp-pause-min').value, pauseMax: el('pp-pause-max').value });
  }));
  for (const field of FIELDS) el('pp-field-' + field).addEventListener('change', guarded(async () => {
    render();
    if (fields().length) await saveSettings({ fields: fields() });
  }));

  el('pp-load').onclick = guarded(load);
  el('pp-tabs').addEventListener('click', guarded(async event => {
    const button = event.target.closest('button[data-account]');
    if (!button || button.dataset.account === current) return;
    current = button.dataset.account; try { localStorage.setItem('jsautopost-dados-conta', current); } catch {}
    list = null; selected.clear(); el('pp-warning').hidden = true;
    el('pp-status').textContent = 'Clique em Carregar Páginas para ver as Páginas do token da Meta.';
    el('pp-rows').innerHTML = '<tr><td colspan="5" class="empty">Nada carregado ainda.</td></tr>';
    render();
    if (profile()?.token) await load();
  }));
  el('pp-notoken-login').onclick = guarded(async () => {
    notice('Abrindo o Chrome da conta ' + profile().name + '. Nele, entre em developers.facebook.com/tools/explorer para gerar o token.');
    await api('login', { account: current });
  });
  for (const id of ['pp-show', 'pp-product']) el(id).addEventListener('change', render);
  el('pp-search').addEventListener('input', render);
  el('pp-rows').addEventListener('change', event => { const box = event.target.closest('input[data-id]'); if (!box) return; box.checked ? selected.add(box.dataset.id) : selected.delete(box.dataset.id); render(); });
  el('pp-select-all').addEventListener('change', event => { for (const row of shown) event.target.checked ? selected.add(row.id) : selected.delete(row.id); render(); });
  el('pp-draw').onclick = guarded(async () => {
    const result = await api('profile/assign', { ids: marked().map(row => row.id) });
    report = { ...report, ...result }; render();
    notice(result.drawn ? result.drawn + ' Página(s) receberam os dados sorteados.' : 'As Páginas marcadas já tinham dados sorteados. Use "Sortear de novo" para trocar.');
  });
  el('pp-redraw').onclick = guarded(async () => {
    const pages = marked();
    if (!confirm('Sortear de novo a descrição e a cidade de ' + pages.length + ' Página(s)?\n\nO que já está gravado na Meta só muda quando você aplicar de novo.')) return;
    report = { ...report, ...(await api('profile/assign', { ids: pages.map(row => row.id), redraw: true })) }; render();
  });
  el('pp-test').onclick = guarded(async () => {
    const page = shown.find(row => selected.has(row.id)) || marked()[0];
    if (!page) throw new Error('Marque uma Página para o teste.');
    const p = preview(page), chosen = fields();
    const lines = chosen.map(field => field === 'about' ? 'Descrição: ' + (p.about || '(sorteada agora)') : field === 'website' ? 'Link: ' + (p.link || '(sorteado agora)') : 'Localização: ' + (p.city || '(sorteada agora)'));
    if (!confirm('Testar em 1 Página: ' + page.name + '\n\n' + lines.join('\n') + '\n\nDepois confira no Facebook: abra a Página e veja a apresentação (bio) e a localização.')) return;
    await start('test', [page.id]);
  });
  el('pp-apply').onclick = guarded(async () => {
    const pages = marked(), s = report.settings, info = accountInfo(), left = Math.max(0, s.dailyLimit - (info?.today || 0));
    const days = Math.max(1, Math.ceil(Math.max(0, pages.length - left) / s.dailyLimit) + (left ? 1 : 0));
    if (!confirm('Gravar ' + fields().map(field => FIELD[field].toLowerCase()).join(', ') + ' em ' + pages.length + ' Página(s)?\n\nElas entram na fila: até ' + s.dailyLimit + ' por dia nesta conta (hoje ainda cabem ' + left + '), com uma pausa de ' + s.pauseMin + ' a ' + s.pauseMax + ' s entre uma e outra. O resto continua sozinho nos próximos dias, com o Autofy aberto' + (days > 1 ? ' (uns ' + days + ' dias no total)' : '') + '.\nPáginas que já estão com os mesmos dados são puladas.')) return;
    await start('apply', pages.map(row => row.id));
  });
  el('pp-apply-missing').onclick = guarded(async () => {
    const pages = missing(), s = report.settings, info = accountInfo(), left = Math.max(0, s.dailyLimit - (info?.today || 0));
    if (!pages.length) throw new Error('Todas as Páginas ativas já têm ' + fields().map(field => FIELD[field].toLowerCase()).join(', ') + ' gravados.');
    if (!confirm('Gravar ' + fields().map(field => FIELD[field].toLowerCase()).join(', ') + ' nas ' + pages.length + ' Página(s) ativas que ainda não têm?\n\n' + pages.slice(0, 12).map(row => row.name).join(', ') + (pages.length > 12 ? '…' : '') + '\n\nElas entram na fila: até ' + s.dailyLimit + ' por dia nesta conta (hoje ainda cabem ' + left + '), com pausa de ' + s.pauseMin + ' a ' + s.pauseMax + ' s entre uma e outra. O resto segue sozinho nos próximos dias, com o Autofy aberto.')) return;
    await start('apply', pages.map(row => row.id));
  });
  el('pp-check').onclick = guarded(async () => { await start('check', marked().map(row => row.id)); });
  el('pp-resume').onclick = guarded(async () => { await start('resume', []); });
  el('pp-stop').onclick = guarded(async () => { report = { ...report, ...(await api('profile/stop', {})) }; render(); });
  el('pp-cancel').onclick = guarded(async () => {
    if (!confirm('Cancelar a fila? ' + report.queue.total + ' Página(s) saem da fila (o que já foi gravado continua gravado).')) return;
    report = { ...report, ...(await api('profile/cancel', {})) }; render();
  });
  async function enter() {
    if (location.hash !== '#dados') { clearTimeout(timer); return; }
    await refresh();
    if (!entered && profile()?.token) { entered = true; await load(); }
  }
  window.addEventListener('hashchange', () => enter().catch(error => notice(error.message)));
  enter().catch(error => notice(error.message));
})();
