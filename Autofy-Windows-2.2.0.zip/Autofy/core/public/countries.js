// Tela "Países das Páginas": restrição de país das Páginas pela API da Meta (lib/country-restrict.mjs).
// Usa api(), esc() e guarded() de app.js. Nenhum token passa por aqui.
(() => {
  const el = id => document.getElementById(id);
  const stamp = new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const when = time => stamp.format(new Date(time)).replace(', ', ' às ');
  const ACTION = { apply: 'Aplicando a restrição', remove: 'Removendo a restrição', check: 'Conferindo na Meta' };
  let report = null, list = null, loading = false, timer = null, entered = false, ticket = 0;
  // Aba escolhida (conta do Facebook): fica lembrada neste navegador.
  let current = (() => { try { return localStorage.getItem('jsautopost-paises-conta') || ''; } catch { return ''; } })();
  const selected = new Set();
  let shown = [];

  const countries = () => [...document.querySelectorAll('#cr-country-list input:checked')].map(input => input.value);
  const names = codes => codes.map(code => (report?.choices || []).find(([c]) => c === code)?.[1] || code).join(', ');
  const running = () => Boolean(report?.progress?.running);
  const record = row => report?.records?.[row.id] || row.record || null;
  function state(row) {
    const r = record(row);
    if (!r) return 'none';
    if (r.state === 'failed') return 'failed';
    if (r.state === 'applied' || (r.state === 'checked' && r.current?.type === 'whitelist')) return 'applied';
    if (r.state === 'checked') return 'other';
    return r.state === 'unknown' ? 'unknown' : 'none';
  }
  function situation(row) {
    const r = record(row), s = state(row), notes = [];
    let badge;
    if (!r) badge = '<span class="cr-badge">Sem restrição aplicada</span>';
    else if (s === 'failed') { badge = '<span class="cr-badge cr-failed">Falhou</span>'; notes.push(r.error); if (r.countries?.length) notes.push('Antes: só ' + r.countries.join(', ')); }
    else if (r.state === 'applied') { badge = '<span class="cr-badge cr-applied">Só ' + esc(r.countries.join(', ')) + '</span>'; notes.push('Aplicada em ' + when(r.at) + (r.confirmed ? ' · conferida na Meta' : ' · a Meta confirmou a gravação')); }
    else if (r.state === 'removed') { badge = '<span class="cr-badge">Sem restrição</span>'; notes.push('Removida em ' + when(r.at)); }
    else if (r.state === 'checked') { badge = r.current.type === 'whitelist' ? '<span class="cr-badge cr-applied">Só ' + esc(r.current.countries.join(', ')) + '</span>' : '<span class="cr-badge cr-other">Escondida de ' + esc(r.current.countries.join(', ')) + '</span>'; notes.push('Conferida na Meta em ' + when(r.checkedAt)); }
    else if (r.state === 'none') { badge = '<span class="cr-badge">Sem restrição</span>'; notes.push('Conferida na Meta em ' + when(r.checkedAt)); }
    else { badge = '<span class="cr-badge cr-other">A Meta não informou</span>'; notes.push('Conferida em ' + when(r.checkedAt || r.at) + '. A Meta não listou a restrição: pode estar sem restrição. Para ter certeza, veja na Página, em Configurações → Restrições de país.'); }
    if (row.manage === false) notes.push('O token pode não ter acesso total a esta Página.');
    return badge + notes.filter(Boolean).map(text => '<small>' + esc(text) + '</small>').join('');
  }
  function renderCountries() {
    if (!report || el('cr-country-list').dataset.ready) return;
    el('cr-country-list').innerHTML = report.choices.map(([code, name]) => '<label><input type="checkbox" value="' + esc(code) + '"' + (report.countries.includes(code) ? ' checked' : '') + '> ' + esc(name) + ' (' + esc(code) + ')</label>').join('');
    el('cr-country-list').dataset.ready = '1';
    el('cr-country-list').addEventListener('change', render);
  }
  // Já recebeu = restrita exatamente aos países marcados agora (aplicada pelo Autofy ou conferida na Meta).
  const sameCountries = (a, b) => JSON.stringify([...(a || [])].sort()) === JSON.stringify([...(b || [])].sort());
  function received(row) {
    const r = record(row);
    if (!r || state(row) !== 'applied') return false;
    return sameCountries(r.state === 'checked' ? r.current?.countries : r.countries, countries());
  }
  // Faltam: ativas no Miwra (todas do token se o Miwra não respondeu), do produto do filtro, sem a restrição dos países marcados.
  function missing() {
    const product = el('cr-product').value;
    return (list?.rows || []).filter(row => (list.miwraMissing || row.miwra?.active) && (product === 'all' || row.miwra?.product === product) && !received(row));
  }
  const profiles = () => report?.profiles || (report?.accounts || []).map((item, index) => ({ ...item, main: index === 0, token: true }));
  const profile = () => { const all = profiles(); return all.find(item => item.account === current) || all[0] || null; };
  const accountName = id => profiles().find(item => item.account === id)?.name || '';
  // Abas no topo: todas as contas do Facebook do Autofy (com ou sem token da Meta).
  function renderTabs() {
    const all = profiles(), chosen = profile(), progress = report?.progress;
    if (chosen) current = chosen.account;
    el('cr-acct-bar').hidden = all.length < 2;
    const restricted = id => Object.values(report?.records || {}).filter(item => item.account === id && (item.state === 'applied' || (item.state === 'checked' && item.current?.type === 'whitelist'))).length;
    const tabs = all.map(item => {
      const busy = progress?.running && progress.account === item.account, count = restricted(item.account);
      const note = busy ? ACTION[progress.action] + ' · ' + progress.done + '/' + progress.total : !item.token ? 'Sem token da Meta' : count ? count + ' restrita(s)' : 'Token salvo';
      return '<button type="button" role="tab" data-account="' + esc(item.account) + '" aria-selected="' + (item.account === current) + '" class="acct-tab' + (busy ? ' running' : '') + (item.token ? '' : ' no-token') + '"><b>' + esc(item.name) + '</b><small>' + esc(note + (item.main ? ' · principal' : '')) + '</small></button>';
    }).join('');
    if (el('cr-tabs').dataset.sig !== tabs) { el('cr-tabs').innerHTML = tabs; el('cr-tabs').dataset.sig = tabs; }
    const missing = Boolean(chosen && !chosen.token);
    el('cr-notoken').hidden = !missing;
    if (missing) el('cr-notoken-name').textContent = chosen.name;
    el('cr-notoken-login').hidden = !missing || chosen.main;
    el('cr-stats').hidden = missing; el('cr-list-card').hidden = missing;
  }
  function render() {
    renderTabs();
    const busy = loading || running(), progress = report?.progress;
    el('cr-load').disabled = busy || !profile()?.token;
    el('cr-stop').hidden = !running();
    el('cr-state').textContent = running() ? ACTION[progress.action] + ' · ' + progress.done + '/' + progress.total + (progress.account !== current && accountName(progress.account) ? ' · ' + accountName(progress.account) : '') : progress?.phase === 'done' ? 'Concluído' : progress?.phase === 'stopped' ? 'Parado' : progress?.phase === 'error' ? 'Parou com erro' : 'Aguardando';
    const logs = progress?.logs?.length ? progress.logs.map(line => line.at + '  ' + line.message).join('\n') : 'Sem atividade.';
    if (el('cr-log').textContent !== logs) { el('cr-log').textContent = logs; el('cr-log').scrollTop = el('cr-log').scrollHeight; }
    if (report && profile() && !profile().token) el('cr-status').textContent = 'A conta ' + profile().name + ' ainda não tem token da Meta: veja abaixo como cadastrar.';
    const rows = list?.rows || [];
    const marked = rows.filter(row => selected.has(row.id));
    const none = !countries().length;
    el('cr-test').disabled = busy || !marked.length || none;
    el('cr-apply').disabled = busy || !marked.length || none;
    el('cr-check').disabled = busy || !marked.length;
    el('cr-remove').disabled = busy || !marked.length;
    el('cr-apply').textContent = 'Aplicar nas marcadas' + (marked.length ? ' (' + marked.length + ')' : '');
    const faltam = list ? missing().length : 0;
    el('cr-apply-missing').disabled = busy || !list || !faltam || none;
    el('cr-apply-missing').textContent = 'Aplicar só nas que faltam' + (list ? ' (' + faltam + ')' : '');
    if (!list) return;
    el('cr-stat-total').textContent = rows.length;
    el('cr-stat-applied').textContent = rows.filter(row => state(row) === 'applied').length;
    el('cr-stat-none').textContent = rows.filter(row => state(row) === 'none').length;
    el('cr-stat-failed').textContent = rows.filter(row => state(row) === 'failed').length;
    const show = el('cr-show').value, product = el('cr-product').value, search = el('cr-search').value.trim().toLocaleLowerCase('pt-BR');
    const wanted = { active: row => row.miwra?.active, all: () => true, missing: row => missing().includes(row), none: row => state(row) === 'none', applied: row => state(row) === 'applied', failed: row => state(row) === 'failed' }[show];
    shown = rows.filter(row => wanted(row) && (product === 'all' || row.miwra?.product === product) && (!search || row.name.toLocaleLowerCase('pt-BR').includes(search) || (row.miwra?.name || '').toLocaleLowerCase('pt-BR').includes(search) || row.id.includes(search)));
    el('cr-summary').textContent = 'Exibindo ' + shown.length + ' de ' + rows.length + ' Página(s) do token de ' + list.accountName + ' · ' + marked.length + ' marcada(s).';
    el('cr-select-all').checked = shown.length > 0 && shown.every(row => selected.has(row.id));
    el('cr-rows').innerHTML = shown.map(row => '<tr>'
      + '<td class="cr-pick"><input type="checkbox" data-id="' + esc(row.id) + '"' + (selected.has(row.id) ? ' checked' : '') + (busy ? ' disabled' : '') + ' aria-label="Marcar ' + esc(row.name) + '"></td>'
      + '<td>' + (row.miwra ? '<span class="product-tag product-' + esc(row.miwra.product) + '">' + esc(row.miwra.product.toUpperCase()) + '</span> ' : '') + esc(row.name)
        + '<small>Facebook ' + esc(row.id) + (row.miwra && row.miwra.name !== row.name ? ' · no Miwra: ' + esc(row.miwra.name) : '') + '</small>'
        + '<small><a href="https://www.facebook.com/' + esc(row.id) + '" target="_blank" rel="noopener noreferrer">Abrir Página</a></small></td>'
      + '<td>' + (row.miwra ? (row.miwra.active ? 'Ativa' : 'Inativa') : 'Fora do Miwra') + '</td>'
      + '<td>' + situation(row) + '</td></tr>').join('') || '<tr><td colspan="4" class="empty">Nenhuma Página neste filtro.</td></tr>';
  }
  async function refresh() {
    report = await api('countries'); renderCountries(); render();
    clearTimeout(timer); if (running()) timer = setTimeout(() => refresh().catch(() => {}), 2000);
  }
  async function load() {
    if (!profile()?.token) { list = null; render(); return; }
    const mine = ++ticket;
    loading = true; render();
    el('cr-status').textContent = 'Lendo as Páginas no token da Meta e a situação delas no Miwra (pode levar até 1 minuto)…'; el('cr-warning').hidden = true;
    try {
      const asked = current;
      const fresh = await api('countries/pages', { account: asked || undefined });
      if (asked !== current) return;   // trocou de aba enquanto carregava
      list = fresh;
      report = { ...report, ...list };
      // Marca as ativas no Miwra na primeira lista que vier com o Miwra (sem mexer numa seleção já feita).
      if (!selected.size && !list.miwraMissing) for (const row of list.rows) if (row.miwra?.active) selected.add(row.id);
      if (list.miwraMissing && el('cr-show').value === 'active') el('cr-show').value = 'all';
      for (const id of [...selected]) if (!list.rows.some(row => row.id === id)) selected.delete(id);
      const outside = list.miwraMissing ? 0 : list.rows.filter(row => !row.miwra).length;
      el('cr-status').textContent = list.rows.length + ' Página(s) no token de ' + list.accountName + ', ' + list.rows.filter(row => row.miwra?.active).length + ' ativa(s) no Miwra.' + (outside ? ' ' + outside + ' Página(s) aparecem como "Fora do Miwra" porque ainda não têm o ID ligado: em Publicações, na aba desta conta, clique em "Buscar IDs no Miwra" e volte aqui (o "Aplicar só nas que faltam" conta só as ativas no Miwra).' : '');
      const warnings = [];
      if (list.miwraMissing) warnings.push('O Miwra não respondeu a tempo: a lista mostra todas as Páginas do token, sem a situação no Miwra e sem marcar nenhuma. Clique em Carregar Páginas de novo daqui a pouco para ver quais estão ativas.');
      el('cr-warning').hidden = list.permission !== false && !list.miwraMissing;
      el('cr-warning').textContent = warnings.join(' ') + (warnings.length && list.permission === false ? ' ' : '') + (list.permission === false ? 'O token desta conta não tem a permissão pages_manage_metadata, que a Meta costuma exigir para mudar configurações da Página. Faça o "Testar em 1 Página": se a Meta recusar por permissão, gere o token de novo marcando também pages_manage_metadata (Parte 4 do tutorial) e salve em Configurações.' : '');
    } finally { if (mine === ticket) loading = false; render(); }
  }
  async function start(action, ids) {
    report = await api('countries/start', { account: list.account, ids, countries: countries(), action });
    render(); clearTimeout(timer); timer = setTimeout(() => refresh().catch(() => {}), 1500);
  }
  const marked = () => (list?.rows || []).filter(row => selected.has(row.id));
  el('cr-load').onclick = guarded(load);
  el('cr-tabs').addEventListener('click', guarded(async event => {
    const button = event.target.closest('button[data-account]');
    if (!button || button.dataset.account === current) return;
    current = button.dataset.account; try { localStorage.setItem('jsautopost-paises-conta', current); } catch {}
    list = null; selected.clear(); el('cr-warning').hidden = true;
    el('cr-status').textContent = 'Clique em Carregar Páginas para ver as Páginas do token da Meta.';
    el('cr-rows').innerHTML = '<tr><td colspan="4" class="empty">Nada carregado ainda.</td></tr>';
    render();
    if (profile()?.token) await load();
  }));
  el('cr-notoken-login').onclick = guarded(async () => {
    notice('Abrindo o Chrome da conta ' + profile().name + '. Nele, entre em developers.facebook.com/tools/explorer para gerar o token.');
    await api('login', { account: current });
  });
  for (const id of ['cr-show', 'cr-product']) el(id).addEventListener('change', render);
  el('cr-search').addEventListener('input', render);
  el('cr-rows').addEventListener('change', event => { const box = event.target.closest('input[data-id]'); if (!box) return; box.checked ? selected.add(box.dataset.id) : selected.delete(box.dataset.id); render(); });
  el('cr-select-all').addEventListener('change', event => { for (const row of shown) event.target.checked ? selected.add(row.id) : selected.delete(row.id); render(); });
  el('cr-test').onclick = guarded(async () => {
    const page = shown.find(row => selected.has(row.id)) || marked()[0];
    if (!page) throw new Error('Marque uma Página para o teste.');
    if (!confirm('Testar em 1 Página: ' + page.name + '\n\nA Página passa a aparecer só para: ' + names(countries()) + '.\n\nDepois confira no Facebook: entre como a Página → Configurações → Seguidores e conteúdo público → Restrições de país.')) return;
    await start('apply', [page.id]);
  });
  el('cr-apply').onclick = guarded(async () => {
    const pages = marked();
    if (!confirm('Aplicar a restrição de país em ' + pages.length + ' Página(s)?\n\nElas passam a aparecer só para: ' + names(countries()) + '.\nQuem estiver em qualquer outro país (inclusive o Brasil) deixa de ver essas Páginas e os Reels delas. Você, logado como administrador, continua vendo e postando.\n\nLeva uns ' + Math.max(1, Math.round(pages.length * 2.5 / 60)) + ' minuto(s).')) return;
    await start('apply', pages.map(row => row.id));
  });
  el('cr-apply-missing').onclick = guarded(async () => {
    const pages = missing();
    if (!pages.length) throw new Error('Todas as Páginas ativas já estão restritas a ' + names(countries()) + '.');
    if (!confirm('Aplicar a restrição só nas ' + pages.length + ' Página(s) que ainda não receberam?\n\n' + pages.slice(0, 12).map(row => row.name).join(', ') + (pages.length > 12 ? '…' : '') + '\n\nElas passam a aparecer só para: ' + names(countries()) + '. As que já estão restritas a esses países ficam como estão.\n\nLeva uns ' + Math.max(1, Math.round(pages.length * 2.5 / 60)) + ' minuto(s).')) return;
    await start('apply', pages.map(row => row.id));
  });
  el('cr-check').onclick = guarded(async () => { await start('check', marked().map(row => row.id)); });
  el('cr-remove').onclick = guarded(async () => {
    const pages = marked();
    if (!confirm('Remover a restrição de país de ' + pages.length + ' Página(s)?\n\nElas voltam a aparecer para todos os países.')) return;
    await start('remove', pages.map(row => row.id));
  });
  el('cr-stop').onclick = guarded(async () => { report = await api('countries/stop', {}); render(); });
  async function enter() {
    if (location.hash !== '#paises') return;
    await refresh();
    if (!entered && profile()?.token) { entered = true; await load(); }
    else render();
  }
  window.addEventListener('hashchange', () => enter().catch(error => notice(error.message)));
  enter().catch(error => notice(error.message));
})();
