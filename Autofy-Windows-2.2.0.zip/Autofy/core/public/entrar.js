// Tela de entrar do Autofy: login, esqueci a senha, senha nova (link do email), conta sem acesso
// e atualização obrigatória. Com a conta liberada, segue para o painel.
(() => {
  const $ = selector => document.querySelector(selector);
  const views = ['loading', 'login', 'signup', 'forgot', 'reset', 'blocked', 'update'];
  const show = name => { for (const view of views) $('#view-' + view).hidden = view !== name; const field = $('#view-' + name + ' input'); if (field) field.focus(); };
  const say = (id, text, kind = 'bad') => { const box = $(id); box.textContent = text; box.className = 'msg ' + kind; box.hidden = !text; };
  const call = async (path, body) => {
    const response = await fetch('/conta/' + path, body === undefined ? { cache: 'no-store' } : { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Falha na comunicação com o Autofy.');
    return data;
  };
  const busy = (button, on, text) => { button.disabled = on; if (text) { button.dataset.label ||= button.textContent; button.textContent = on ? text : button.dataset.label; } };
  let state = null, resetToken = '';

  const TITLES = { inativo: 'Conta inativa', suspenso: 'Conta suspensa', 'sem-licenca': 'Conta sem licença' };
  const render = (next, notice) => {
    state = next;
    $('#foot-version').textContent = 'Autofy v' + (next.versions?.local || '');
    if (next.allowed) { location.replace('/'); return; }
    if (next.reason === 'atualizar') {
      $('#update-local').textContent = next.versions.local;
      $('#update-minimum').textContent = next.versions.minimum;
      $('#update-now').hidden = !next.canUpdate;
      say('#update-msg', next.canUpdate ? '' : 'Baixe a versão nova pelo link do Discord e extraia por cima da pasta do Autofy.', 'warn');
      return show('update');
    }
    if (TITLES[next.reason]) {
      $('#blocked-title').textContent = TITLES[next.reason];
      $('#blocked-who').textContent = next.email;
      $('#blocked-msg').textContent = next.message;
      return show('blocked');
    }
    show('login');
    // "entrar" é o estado normal sem conta; os outros motivos (expirou, sessão encerrada) aparecem como aviso.
    say('#login-msg', notice || (next.reason !== 'entrar' ? next.message : ''), notice ? 'ok' : 'warn');
  };

  const load = async () => {
    show('loading');
    try { render(await call('estado')); }
    catch (error) { show('login'); say('#login-msg', error.message); }
  };

  $('#view-login').addEventListener('submit', async event => {
    event.preventDefault();
    const email = $('#login-email').value.trim(), password = $('#login-password').value;
    if (!email || !password) return say('#login-msg', 'Preencha o email e a senha.');
    const button = $('#login-submit');
    busy(button, true, 'Entrando…'); say('#login-msg', '');
    try {
      const next = await call('entrar', { email, senha: password });
      $('#login-password').value = '';
      render(next);
    } catch (error) { say('#login-msg', error.message); $('#login-password').select(); }
    finally { busy(button, false, 'Entrando…'); }
  });

  $('#go-signup').addEventListener('click', () => { $('#signup-email').value ||= $('#login-email').value.trim(); say('#signup-msg', ''); show('signup'); });
  $('#view-signup').addEventListener('submit', async event => {
    event.preventDefault();
    const field = id => $('#signup-' + id).value;
    const codigo = field('code').trim(), nome = field('name').trim(), email = field('email').trim(), senha = field('password');
    if (!codigo) return say('#signup-msg', 'Digite o código de acesso que você recebeu na compra.');
    if (nome.length < 2) return say('#signup-msg', 'Digite o seu nome.');
    if (!email) return say('#signup-msg', 'Digite o seu email.');
    if (senha.length < 8) return say('#signup-msg', 'A senha precisa ter pelo menos 8 caracteres.');
    if (senha !== field('confirm')) return say('#signup-msg', 'As duas senhas não são iguais.');
    const button = $('#signup-submit');
    busy(button, true, 'Criando sua conta…'); say('#signup-msg', '');
    try {
      const next = await call('cadastrar', { codigo, nome, email, senha });
      $('#signup-password').value = $('#signup-confirm').value = '';
      render(next);
    } catch (error) { say('#signup-msg', error.message); }
    finally { busy(button, false, 'Criando sua conta…'); }
  });

  $('#go-forgot').addEventListener('click', () => { $('#forgot-email').value = $('#login-email').value.trim(); say('#forgot-msg', ''); show('forgot'); });
  for (const button of document.querySelectorAll('.back')) button.addEventListener('click', () => { say('#login-msg', ''); show('login'); });

  $('#view-forgot').addEventListener('submit', async event => {
    event.preventDefault();
    const email = $('#forgot-email').value.trim();
    if (!email) return say('#forgot-msg', 'Digite o seu email.');
    const button = $('#forgot-submit');
    busy(button, true, 'Enviando…');
    try {
      await call('esqueci', { email });
      say('#forgot-msg', 'Se esse email tiver conta no Autofy, o link chega em alguns minutos. Confira também o spam.', 'ok');
    } catch (error) { say('#forgot-msg', error.message); }
    finally { busy(button, false, 'Enviando…'); }
  });

  $('#view-reset').addEventListener('submit', async event => {
    event.preventDefault();
    const password = $('#reset-password').value, confirm = $('#reset-confirm').value;
    if (password.length < 8) return say('#reset-msg', 'A senha nova precisa ter pelo menos 8 caracteres.');
    if (password !== confirm) return say('#reset-msg', 'As duas senhas não são iguais.');
    const button = $('#reset-submit');
    busy(button, true, 'Salvando…');
    try {
      const result = await call('nova-senha', { token: resetToken, senha: password });
      resetToken = '';
      $('#reset-password').value = $('#reset-confirm').value = '';
      if (result.email) $('#login-email').value = result.email;
      show('login');
      say('#login-msg', 'Senha trocada. Entre com a senha nova.', 'ok');
      $('#login-password').focus();
    } catch (error) { say('#reset-msg', error.message); }
    finally { busy(button, false, 'Salvando…'); }
  });

  const logout = async button => {
    busy(button, true);
    try { render(await call('sair', {})); } catch (error) { alert(error.message); }
    finally { busy(button, false); }
  };
  $('#blocked-logout').addEventListener('click', event => logout(event.currentTarget));
  $('#update-logout').addEventListener('click', event => logout(event.currentTarget));
  $('#blocked-retry').addEventListener('click', load);

  $('#update-now').addEventListener('click', async event => {
    const button = event.currentTarget;
    busy(button, true, 'Baixando a versão nova…'); say('#update-msg', '');
    try {
      const result = await call('atualizar', {});
      document.body.replaceChildren(Object.assign(document.createElement('main'), { className: 'closed' }));
      for (const [tag, text] of [['h1', 'Autofy atualizado para ' + result.version], ['p', 'O Autofy está reabrindo e o painel novo abre sozinho em uma nova aba em alguns segundos. Pode fechar esta.'], ['p', 'Se não abrir em 1 minuto, clique no ícone Autofy.']]) {
        document.body.firstChild.append(Object.assign(document.createElement(tag), { textContent: text }));
      }
    } catch (error) { say('#update-msg', error.message); busy(button, false, 'Baixando a versão nova…'); }
  });

  $('#close-app').addEventListener('click', async event => {
    if (!confirm('Fechar o Autofy? O servidor é encerrado e esta aba para de funcionar.')) return;
    const button = event.currentTarget;
    busy(button, true);
    try {
      await call('encerrar', {});
      document.body.replaceChildren(Object.assign(document.createElement('main'), { className: 'closed' }));
      for (const [tag, text] of [['h1', 'Autofy encerrado'], ['p', 'Pode fechar esta aba. Para abrir de novo, clique no ícone Autofy.']]) {
        document.body.firstChild.append(Object.assign(document.createElement(tag), { textContent: text }));
      }
    } catch (error) { alert(error.message); busy(button, false); }
  });

  // Link do email "trocar a senha": o Supabase volta para cá com o token no fim do endereço (#...).
  const hash = new URLSearchParams(location.hash.slice(1));
  if (location.hash) history.replaceState(null, '', location.pathname);
  if (hash.get('type') === 'recovery' && hash.get('access_token')) {
    resetToken = hash.get('access_token');
    show('reset');
    call('estado').then(next => { state = next; $('#foot-version').textContent = 'Autofy v' + (next.versions?.local || ''); }).catch(() => {});
  } else if (hash.get('error')) {
    load().then(() => { if (!state?.allowed) { show('forgot'); say('#forgot-msg', hash.get('error_code') === 'otp_expired' ? 'O link expirou ou já foi usado. Peça outro.' : 'O link não funcionou. Peça outro.'); } });
  } else load();
})();
