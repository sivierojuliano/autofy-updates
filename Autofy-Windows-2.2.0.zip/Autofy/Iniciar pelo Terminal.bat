@echo off
rem Alternativa com janela: mostra as mensagens do servidor. Q + Enter encerra.
chcp 65001 >nul
cd /d "%~dp0"
if exist "runtime\node.exe" (
  "runtime\node.exe" start.mjs
) else (
  node start.mjs
)
echo.
pause
