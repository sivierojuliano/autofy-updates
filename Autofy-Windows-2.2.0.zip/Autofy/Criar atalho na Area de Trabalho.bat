@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows\atalho.ps1"
