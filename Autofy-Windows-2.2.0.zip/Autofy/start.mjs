import { spawn } from 'node:child_process';
import { readFile, writeFile, unlink } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { PassThrough } from 'node:stream';
import { homedir } from 'node:os';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { createInterface } from 'node:readline';
import { fileURLToPath } from 'node:url';

const messages = Object.freeze({
  PLATFORM: 'Este iniciador funciona no macOS e no Windows.',
  NODE_VERSION: 'Instale o Node.js oficial 22 ou superior; recomendamos Node.js 24 LTS.',
  PACKAGE_INVALID: 'Pacote incompleto ou alterado. Extraia novamente o ZIP de testes; não execute npm install.',
  DATA_PATH: 'Não foi possível definir a pasta de dados do usuário.',
  DATA_LOCK: 'Outra cópia pode estar aberta usando os mesmos dados. Feche a cópia existente e tente novamente.',
  START_FAILED: 'Não foi possível iniciar o painel. Confira a instalação do Node.js e a permissão da pasta de dados.',
  BROWSER_OPEN: 'Não foi possível abrir o navegador. Abra manualmente o endereço local mostrado acima.',
  BUSY: 'Há uma operação em andamento. Aguarde terminar e tente Q + Enter ou Ctrl+C novamente.',
  FORCED_CLOSE: 'A sessão do terminal foi encerrada. Fechando os recursos desta cópia; uma publicação em andamento pode ser interrompida.',
  SHUTDOWN_FAILED: 'Não foi possível concluir o encerramento. A trava dos dados foi preservada.',
  STOPPED: 'Painel encerrado.',
});

// Autofy Simples: o mesmo programa com a tela única; dados e porta próprios, para poder
// conviver com o Autofy completo no mesmo computador.
export const SIMPLE_EDITION = existsSync(join(dirname(fileURLToPath(import.meta.url)), 'edicao-simples.txt'));
export function macDataDirectory(home = homedir()) {
  return join(home, 'Library', 'Application Support', SIMPLE_EDITION ? 'MiwraPublisherSimples' : 'MiwraPublisher');
}
// Windows: %LOCALAPPDATA%\JSAutopost. No Mac o nome antigo da pasta é mantido para preservar os dados.
export function dataDirectory({ platform = process.platform, home = homedir(), env = process.env } = {}) {
  if (platform !== 'win32') return macDataDirectory(home);
  const base = env.LOCALAPPDATA && isAbsolute(env.LOCALAPPDATA) ? env.LOCALAPPDATA : join(home, 'AppData', 'Local');
  return join(base, SIMPLE_EDITION ? 'JSAutopostSimples' : 'JSAutopost');
}

export function validateRuntime({ platform = process.platform, nodeVersion = process.versions.node } = {}) {
  if (!['darwin', 'win32'].includes(platform)) return 'PLATFORM';
  if (!/^\d+\.\d+\.\d+(?:[-+].*)?$/.test(nodeVersion) || Number(nodeVersion.split('.')[0]) < 22) return 'NODE_VERSION';
  return null;
}

function isLocalUrl(value) {
  if (typeof value !== 'string' || !/^http:\/\/127\.0\.0\.1:[1-9]\d{0,4}\/$/.test(value)) return false;
  const port = Number(value.slice('http://127.0.0.1:'.length, -1));
  return port <= 65535;
}

export async function openLocalBrowser(url) {
  // The actual platform check cannot be bypassed through injected test options.
  if (!['darwin', 'win32'].includes(process.platform) || !isLocalUrl(url)) throw new Error('BROWSER_OPEN');
  // Windows: abre o endereço no navegador padrão sem passar por um shell.
  const [command, args] = process.platform === 'win32'
    ? [join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'rundll32.exe'), ['url.dll,FileProtocolHandler', url]]
    : ['/usr/bin/open', [url]];
  await new Promise((resolveOpen, reject) => {
    const child = spawn(command, args, { shell: false, stdio: 'ignore', windowsHide: true });
    child.once('error', () => reject(new Error('BROWSER_OPEN')));
    child.once('exit', code => code === 0 ? resolveOpen() : reject(new Error('BROWSER_OPEN')));
  });
}

async function loadCore() {
  // In the extracted source package this file is start.mjs next to core/.
  // Importing this launcher for tests never imports or starts the backend.
  const [server, desktop] = await Promise.all([
    import('./core/server.mjs'), import('./core/desktop-host.mjs'),
  ]);
  return { makeApp: server.createApp, acquireLock: desktop.acquireDataLock, listen: desktop.listenDesktop };
}

export async function runDevLauncher({
  directory = dataDirectory(), input = process.stdin, output = process.stdout,
  signals = process, makeApp, acquireLock, listen, openBrowser = openLocalBrowser,
  preferred = SIMPLE_EDITION ? 3033 : 3032, loadDependencies = loadCore,
} = {}) {
  if (!isAbsolute(directory)) throw new Error('DATA_PATH');
  if (!Number.isInteger(preferred) || preferred < 0 || preferred > 65535) throw new Error('START_FAILED');
  if (!makeApp || !acquireLock || !listen) {
    const core = await loadDependencies();
    makeApp ||= core.makeApp;
    acquireLock ||= core.acquireLock;
    listen ||= core.listen;
  }

  let app, release, url, lines, initialized, resolveDone;
  let phase = 'starting', forced = false, stopPromise, finished = false, successful = false;
  let forcedNotice = false, commandChain = Promise.resolve();
  const initialization = new Promise(resolveReady => { initialized = resolveReady; });
  const done = new Promise(resolveClosed => { resolveDone = resolveClosed; });
  const write = text => {
    if (output.destroyed || output.writableEnded) return;
    try { output.write(text + '\n'); } catch { /* Closed terminal. */ }
  };
  const report = code => write(`[${code}] ${messages[code]}`);

  const removeControls = () => {
    lines?.removeListener('close', onInputClose);
    lines?.removeListener('line', onLine);
    lines?.close();
    input.removeListener('error', onInputClose);
    output.removeListener?.('error', onInputClose);
    input.pause();
    input.unref?.();
    for (const [signal, handler] of signalHandlers) signals.removeListener(signal, handler);
  };
  const settle = success => {
    finished = true;
    successful = success;
    phase = 'closed';
    removeControls();
    resolveDone({ exitCode: success ? 0 : 1 });
  };

  function requestStop(force = false, terminalClosed = false) {
    if (finished) return Promise.resolve(successful);
    if (force) forced = true;
    if (terminalClosed && !forcedNotice) { forcedNotice = true; report('FORCED_CLOSE'); }
    if (stopPromise) return stopPromise;
    stopPromise = (async () => {
      await initialization;
      phase = 'closing';
      try {
        let closed = !app;
        if (app) {
          if (forced) { await app.close(); closed = true; }
          else {
            // The backend checks busy state and blocks new writes before awaiting.
            // Do not call close() after a refused normal quit: it would stop jobs.
            closed = await app.closeIfIdle();
            if (!closed && forced) { await app.close(); closed = true; }
          }
        }
        if (!closed) { phase = 'ready'; report('BUSY'); return false; }
        // Never remove the data lease before app.close/closeIfIdle has completed.
        if (release) { await release(); release = undefined; }
        settle(true);
        if (app) report('STOPPED');
        return true;
      } catch {
        report('SHUTDOWN_FAILED');
        settle(false);
        return false;
      } finally {
        if (!finished) stopPromise = undefined;
      }
    })();
    return stopPromise;
  }

  async function reopen() {
    if (phase !== 'ready' || !isLocalUrl(url)) return;
    try { await openBrowser(url); } catch { report('BROWSER_OPEN'); }
  }
  function onLine(line) {
    if (line.length > 32 || phase !== 'ready') return;
    const command = line.trim().toUpperCase();
    if (command === 'Q') { void requestStop(); return; }
    if (command === 'A') commandChain = commandChain.then(reopen).catch(() => report('BROWSER_OPEN'));
  }
  function onInputClose() { void requestStop(true, true); }
  const signalHandlers = [
    ['SIGINT', () => { void requestStop(); }],
    ['SIGHUP', onInputClose],
    ['SIGTERM', onInputClose],
  ];
  const host = {
    get app() { return app; }, get url() { return url; }, done,
    requestClose: () => requestStop(),
    // Explicit forced cleanup is reserved for a lost terminal/host teardown.
    close: () => requestStop(true, true),
  };
  for (const [signal, handler] of signalHandlers) signals.on(signal, handler);
  input.on('error', onInputClose);
  output.on?.('error', onInputClose);
  try {
    release = await acquireLock(directory);
    app = await makeApp({ directory, lan: false });
    // Botão Encerrar do painel (POST /api/shutdown): força só quando o usuário confirma na tela.
    app.onShutdown = force => requestStop(force === true);
    if (!forced) {
      url = await listen(app, preferred);
      if (!isLocalUrl(url)) throw new Error('START_FAILED');
    }
    phase = 'ready';
    initialized();
    if (stopPromise) await stopPromise;
    if (finished) return host;
    write(`Autofy\nEndereço local: ${url}`);
    write('A + Enter: reabrir no navegador. Q + Enter ou Ctrl+C: fechar quando estiver livre.');
    write('Mantenha este terminal aberto. Fechar a janela ou forçar o encerramento pode interromper uma publicação.');
    lines = createInterface({ input, crlfDelay: Infinity, terminal: false });
    lines.on('line', onLine);
    lines.on('close', onInputClose);
    // Redirected/exhausted stdin must not leave an unreachable background host.
    if (input.readableEnded || input.destroyed) await requestStop(true, true);
    else await reopen();
    return host;
  } catch (error) {
    initialized();
    await requestStop(true);
    throw new Error(error?.message === 'DATA_LOCK' ? 'DATA_LOCK' : 'START_FAILED');
  }
}

export async function main() {
  const report = code => process.stdout.write(`[${code}] ${messages[code]}\n`);
  const runtimeError = validateRuntime();
  if (runtimeError) { report(runtimeError); return 1; }
  try {
    const { verifyPackage } = await import('./verificar.mjs');
    const verification = await verifyPackage(dirname(fileURLToPath(import.meta.url)));
    if (verification?.ok !== true) throw new Error('PACKAGE_INVALID');
  } catch { report('PACKAGE_INVALID'); return 1; }
  try {
    // The packaged launcher controls binding and child runtime behavior itself.
    // Clearing these here also avoids forwarding inherited Node injection flags.
    for (const name of ['PORT', 'NODE_OPTIONS', 'NODE_PATH']) delete process.env[name];
    // --background: aberto pelo ícone (Autofy.app), sem Terminal. Não há teclado:
    // o painel é encerrado pelo botão Encerrar. O endereço fica salvo para o ícone reabrir a tela.
    const background = process.argv.includes('--background');
    const urlFile = join(dataDirectory(), 'painel-url.json');
    let options = {};
    if (background) {
      process.on('SIGHUP', () => {});
      options = { input: new PassThrough(), signals: {
        on: (signal, handler) => { if (signal !== 'SIGHUP') process.on(signal, handler); },
        removeListener: (signal, handler) => { process.removeListener(signal, handler); },
      } };
    }
    let host;
    try { host = await runDevLauncher(options); }
    catch (error) {
      if (background && error?.message === 'DATA_LOCK') {
        // Já está aberto: só traz a tela de volta.
        try { const saved = JSON.parse(await readFile(urlFile, 'utf8')); await openLocalBrowser(saved.url); return 0; } catch { /* cai no aviso abaixo */ }
      }
      throw error;
    }
    if (host.url) await writeFile(urlFile, JSON.stringify({ pid: process.pid, url: host.url }), { mode: 0o600 }).catch(() => {});
    const result = await host.done;
    await unlink(urlFile).catch(() => {});
    // Conexões abertas do navegador não devem segurar o processo depois de encerrado.
    setTimeout(() => process.exit(result.exitCode), 1500).unref();
    return result.exitCode;
  } catch (error) {
    report(['DATA_LOCK', 'DATA_PATH'].includes(error?.message) ? error.message : 'START_FAILED');
    return 1;
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  process.exitCode = await main();
}
