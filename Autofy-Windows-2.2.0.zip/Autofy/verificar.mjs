import { lstat, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const invalid = () => new Error('PACKAGE_INVALID');
const validPath = path => typeof path === 'string' && path.length <= 512 &&
  !/[\\:\x00-\x1f]/.test(path) && path.split('/').every(part => part && part !== '.' && part !== '..');

// Detects incomplete extraction or accidental modification, not publisher identity
// or malware. The manifest is not a digital signature. Finder metadata is ignored.
export async function verifyPackage(root = here) {
  try {
    const manifestPath = join(root, 'manifest.json');
    const stat = await lstat(manifestPath);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size > 2_000_000) throw invalid();
    const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
    if (manifest.format !== 1 || !/^\d+\.\d+\.\d+$/.test(manifest.version) ||
        !Array.isArray(manifest.files) || !manifest.files.length || manifest.files.length > 10000) throw invalid();
    const seen = new Set();
    for (const file of manifest.files) {
      if (!validPath(file.path) || file.path === 'manifest.json' || seen.has(file.path.toLowerCase()) ||
          !Number.isSafeInteger(file.size) || file.size < 0 || file.size > 100_000_000 ||
          !/^[0-9a-f]{64}$/.test(file.sha256)) throw invalid();
      seen.add(file.path.toLowerCase());
      let path = resolve(root);
      const parts = file.path.split('/');
      for (let i = 0; i < parts.length; i++) {
        path = join(path, parts[i]);
        const item = await lstat(path);
        if (item.isSymbolicLink()) throw invalid();
        if (i < parts.length - 1) { if (!item.isDirectory()) throw invalid(); }
        else if (!item.isFile() || item.size !== file.size) throw invalid();
      }
      const bytes = await readFile(path);
      if (createHash('sha256').update(bytes).digest('hex') !== file.sha256) throw invalid();
    }
    return { ok: true, files: seen.size, version: manifest.version };
  } catch { throw invalid(); }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const result = await verifyPackage();
    process.stdout.write(`Integridade conferida: ${result.files} arquivos, versão ${result.version}.\n`);
  } catch {
    process.stderr.write('Pacote incompleto ou alterado. Extraia novamente o ZIP de testes.\n');
    process.exitCode = 1;
  }
}
