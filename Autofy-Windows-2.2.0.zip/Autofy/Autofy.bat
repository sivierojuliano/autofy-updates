@echo off
rem Abre o Autofy sem janela de terminal. Para encerrar, use o botao Encerrar no painel.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0windows\launcher.ps1"
