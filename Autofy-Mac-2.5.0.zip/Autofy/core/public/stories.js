(() => {
 const $=id=>document.getElementById(id), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 // Restore the last links in this browser, including an intentionally cleared field.
 for (const [id, storageKey] of [['stories-checkout','autofy-stories-checkout'],['stories-drive','autofy-stories-drive']]) {
   const input = $(id);
   if (!input) continue;
   try {
     const saved = localStorage.getItem(storageKey);
     if (saved !== null && !input.value) input.value = saved;
   } catch {}
   const remember = () => { try { localStorage.setItem(storageKey, input.value); } catch {} };
   input.addEventListener('input', remember);
   input.addEventListener('change', remember);
 }
 let pages=[], analytics=null, driveFiles=[], prepared=null, preparing=false, prepVersion=0, bindings={};
 try{const saved=JSON.parse(localStorage.getItem('autofy-story-bindings')||'{}');if(saved&&typeof saved==='object'&&!Array.isArray(saved))bindings=saved;}catch{}
 const deselectedPages = new Set();
 let reviewSnapshot=null,lastRun=null,loadedDriveUrl='',draftTimer=null,restoringDraft=false,pendingPreparationId='',serverSaveTimer=null,lastServerKey='',draftReady=false,prepPolling=false,latestRun=null,recentPosted=new Map(),partialPages=new Map(),recentTimer=null,scheduleReport=null;
 const status=t=>{$('stories-status').textContent=t||''};
 async function load(){invalidatePreparation();deselectedPages.clear();const btn=$('stories-load-pages'),list=$('stories-pages');btn.disabled=true;btn.textContent='Carregando…';btn.setAttribute('aria-busy','true');list.setAttribute('aria-busy','true');list.innerHTML='<div class="stories-drive-progress"><span class="stories-spinner" aria-hidden="true"></span><span>Carregando dados locais e consultando a Meta…</span></div>';status('Lendo Analytics local…');let seconds=0;const ticker=setInterval(()=>{seconds++;status('Consultando páginas na Meta… '+seconds+' s');},1000);try{analytics=await api('stories/ranking');pages=(analytics.pages||[]).filter(p=>p.active||p.followers!=null).map(p=>({id:String(p.id),facebookId:String(p.id),name:p.name,followers:p.followers,active:true,provisional:true}));render();status(pages.length+' página(s) do Analytics carregadas; conferindo lista atual da Meta…');try{const fresh=await api('pages/followers');pages=fresh.pages||[];pages=pages.filter(p=>p.facebookId&&p.active!==false);render();status(pages.length+' página(s) ativas carregadas com dados da Meta.');}catch(e){status(pages.length+' página(s) locais carregadas; validação da Meta falhou: '+(e.message||'erro'));}}catch(e){list.innerHTML='<p class="stories-drive-error">Não foi possível carregar os dados do Analytics.</p><p>'+esc(e.message||'Erro de comunicação')+'</p>';status('Falha ao carregar páginas: '+(e.message||'erro'));}finally{clearInterval(ticker);btn.disabled=false;btn.textContent='Carregar Páginas';btn.removeAttribute('aria-busy');list.removeAttribute('aria-busy');}}
 function render(){
  const min=Number($('stories-min-followers').value||0),shown=pages.filter(p=>Number(p.followers||0)>=min&&p.active!==false).sort((a,b)=>(b.followers||0)-(a.followers||0));
  $('stories-pages').innerHTML=shown.length?shown.map(p=>{
   const id=String(p.facebookId||p.id),posted=recentPosted.get(id),partial=partialPages.get(id),disabled=Boolean(posted);
   const until=posted?.at?new Date(Date.parse(posted.at)+24*3600000).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'';
   const note=posted?'Já postou nas últimas 24h'+(until?' — libera em '+until:''):partial?'Isca já postada; link pendente':'';
   return '<label class="story-page-row'+(disabled?' story-page-posted':'')+'"><input type="checkbox" data-page="'+esc(id)+'" data-name="'+esc(p.name)+'" '+(disabled?'disabled ':'')+((!disabled&&!deselectedPages.has(id))?'checked':'')+'><span>'+esc(p.name)+'</span><small>'+new Intl.NumberFormat('pt-BR').format(p.followers||0)+' seguidores</small>'+(note?'<small class="story-page-note">'+esc(note)+'</small>':'')+'</label>';
  }).join(''):'Nenhuma página atende ao mínimo informado.';
  const boxes=[...$('stories-pages').querySelectorAll('input[data-page]:not(:disabled)')];
  $('stories-select-bar').hidden=!shown.length;
  $('stories-select-count').textContent=boxes.filter(x=>x.checked).length+' de '+boxes.length+' selecionada(s)';
  plan();queueDraft();
 }
 // Seleção em massa: vale para as Páginas mostradas (já filtradas pelo mínimo de seguidores).
 function selectPages(mode){
  const min=Number($('stories-min-followers').value||0);
  for(const p of pages.filter(p=>Number(p.followers||0)>=min&&p.active!==false)){
   const id=String(p.facebookId||p.id),on=mode==='all'||(mode==='followers'&&Number(p.followers||0)>0);
   if(on)deselectedPages.delete(id);else deselectedPages.add(id);
  }
  invalidatePreparation();render();
 }
 $('stories-select-bar').addEventListener('click',event=>{const mode=event.target.closest('[data-select]')?.dataset.select;if(mode)selectPages(mode);});
 function plan(){
  const chosen=new Set([...$('stories-pages').querySelectorAll('input:checked')].map(x=>x.dataset.page));
  const out=pages.filter(p=>chosen.has(String(p.facebookId||p.id))).sort((a,b)=>(b.followers||0)-(a.followers||0)),reels=analytics?.rankedReels||[],fmt=new Intl.NumberFormat('pt-BR');
  $('stories-plan-summary').textContent=out.length+' página(s) selecionada(s) · '+out.length*2+' Stories — ver distribuição';
  $('stories-plan').innerHTML=out.length?'<table class="views-table"><thead><tr><th>Página de destino</th><th>Seguidores</th><th>Origem do Reel</th><th>Plays em 7 dias</th></tr></thead><tbody>'+out.map((p,i)=>{const r=reels[i%Math.max(reels.length,1)];return '<tr><td>'+esc(p.name)+'</td><td>'+fmt.format(p.followers||0)+'</td><td>'+(r?'<a target="_blank" rel="noopener noreferrer" href="https://www.facebook.com/reel/'+encodeURIComponent(r.id)+'">'+esc(r.pageName||r.pageId)+'</a>':'Sem Reel disponível')+'</td><td>'+(r?fmt.format(r.plays):'—')+'</td></tr>';}).join('')+'</tbody></table>':'Selecione as páginas de destino.';
 }
 $('stories-drive-load').addEventListener('click',async()=>{invalidatePreparation();const url=$('stories-drive').value.trim(),btn=$('stories-drive-load'),statusEl=$('stories-drive-status'),list=$('stories-drive-files');if(!url){statusEl.textContent='Cole o link da pasta.';statusEl.dataset.state='error';return;}btn.disabled=true;btn.setAttribute('aria-busy','true');btn.textContent='Lendo Drive…';$('stories-drive-details').open=false;$('stories-drive-summary').textContent='Lendo vídeos…';statusEl.dataset.state='loading';list.setAttribute('aria-busy','true');list.innerHTML='<div class="stories-drive-progress"><span class="stories-spinner" aria-hidden="true"></span><span>Conectando ao Google Drive e percorrendo a pasta raiz e as subpastas…</span></div>';let seconds=0;statusEl.textContent='Iniciando leitura…';const ticker=setInterval(()=>{seconds++;statusEl.textContent='Lendo vídeos e subpastas… '+seconds+' s';},1000);try{const r=await api('stories/drive-list',{folderUrl:url});driveFiles=r.files||[];loadedDriveUrl=url;$('stories-drive-summary').textContent=driveFiles.length+' vídeo(s) encontrados — expandir lista';list.innerHTML=driveFiles.length?'<p class="stories-result-summary">'+driveFiles.length+' vídeo(s) encontrados em '+((r.folderCount||0)+1)+' pasta(s).</p>'+driveFiles.map((f,i)=>'<label class="story-page-row"><input type="checkbox" data-hook-index="'+i+'" checked><span>'+esc(f.name)+'</span></label>').join(''):'<p>Nenhum vídeo MP4 público encontrado nesta pasta ou nas subpastas.</p>';statusEl.dataset.state=driveFiles.length?'success':'empty';statusEl.textContent=driveFiles.length+' vídeo(s) encontrados.';}catch(e){$('stories-drive-summary').textContent='Não foi possível carregar os vídeos';list.innerHTML='<p class="stories-drive-error">Não foi possível ler a pasta.</p>';statusEl.dataset.state='error';statusEl.textContent=e.message||'Falha ao consultar o Drive.';}finally{clearInterval(ticker);btn.disabled=false;btn.removeAttribute('aria-busy');btn.textContent='Ler vídeos da pasta';list.removeAttribute('aria-busy');queueDraft();}});$('stories-load-pages').addEventListener('click',load);$('stories-min-followers').addEventListener('input',render);$('stories-pages').addEventListener('change',event=>{const input=event.target;if(input.matches('input[data-page]')){if(input.checked)deselectedPages.delete(input.dataset.page);else deselectedPages.add(input.dataset.page);const boxes=[...$('stories-pages').querySelectorAll('input[data-page]:not(:disabled)')];$('stories-select-count').textContent=boxes.filter(x=>x.checked).length+' de '+boxes.length+' selecionada(s)';}plan();});
 let posting=false;
 function renderStoryRun(run){
  if(run.phase==='idle'&&lastRun?.phase&&lastRun.phase!=='idle')run={...lastRun,running:false};
  else lastRun=run;
  queueDraft();
  renderExecution(run);renderSkipHook(run);
  const results=run.results||[],visible=results.filter(r=>r.status!=='pending'),done=visible.filter(r=>r.status==='posted'),fail=visible.filter(r=>r.status==='error');
  for(const input of $('stories-pages').querySelectorAll('input[data-page]'))if(deselectedPages.has(input.dataset.page))input.checked=false;
  plan();
  $('stories-run-state').textContent=run.running?(run.stopping?'Encerrando…':run.current+' de '+run.total):(run.phase==='idle'?'Aguardando':run.phase==='stopped'?'Encerrado':'Finalizado');
  const messages=[...(run.logs||[]),...visible.map(r=>(r.status==='posted'?'[PUBLICADO] ':r.status==='stopped'?'[ENCERRADO] ':'[ERRO] ')+(r.name||r.pageId)+' — '+(r.status==='posted'?'Dois Stories confirmados.':r.error||r.status))];
  if(run.error)messages.push('[LOTE] '+run.error);
  if(run.running)messages.push('[EM ANDAMENTO] Página '+run.current+' de '+run.total+' · '+(run.stopping?'Encerrando após concluir a etapa atual.':run.phase==='publishing'?'Preparando publicação':run.phase));
  const log=$('stories-logs'),atBottom=log.scrollTop+log.clientHeight>=log.scrollHeight-24;
  const text=messages.join('\n')||'Sem atividade.';if(log.textContent!==text){log.textContent=text;if(atBottom)log.scrollTop=log.scrollHeight;}
  $('stories-stop').hidden=!run.running;$('stories-stop').disabled=!!run.stopping;
  $('stories-stop').textContent=run.stopping?'Encerrando…':'Encerrar lote';
  $('stories-start').disabled=!!run.running||!prepared?.ready;$('stories-prepare').disabled=!!run.running||preparing;$('stories-start').textContent=run.running?'Publicando…':'Publicar Stories';
  if(run.phase!=='idle')status(run.running?'Página '+run.current+' de '+run.total:done.length+' página(s) publicada(s) · '+fail.length+' com erro'+(run.phase==='stopped'?' · lote encerrado':''));
 }
 async function pollStories(){while(posting){try{const run=await api('stories/status');renderStoryRun(run);if(!run.running){posting=false;invalidatePreparation();saveDraft();void loadRuns();void loadSchedule();break;}}catch(e){status('Não foi possível atualizar o registro: '+e.message);}await new Promise(r=>setTimeout(r,2000));}}
 $('stories-stop').addEventListener('click',async()=>{const btn=$('stories-stop');btn.disabled=true;btn.textContent='Encerrando…';try{await api('stories/stop',{});status('Encerrando lote. Aguardando confirmação de qualquer envio já iniciado.');}catch(e){btn.disabled=false;btn.textContent='Encerrar lote';status('Não foi possível encerrar: '+e.message);}});
  async function restoreStoryRun(){if(posting)return;try{const run=await api('stories/status');if(posting)return;renderStoryRun(run);if(run.running){posting=true;void pollStories();}}catch(e){status('Não foi possível ler a rodada: '+e.message);}void pollPreparation();void loadRuns();void loadSchedule();}
 window.addEventListener('hashchange',()=>{if(location.hash==='#stories')void restoreStoryRun();});
 if(location.hash==='#stories')void restoreStoryRun();
  function invalidatePreparation(){prepared=null;pendingPreparationId='';prepVersion++;queueDraft();$('stories-start').disabled=true;if(!$('stories-preflight').hidden)$('stories-preflight-summary').textContent='Prepare novamente para conferir os vínculos da seleção atual';}
  function newRequestId(){return globalThis.crypto?.randomUUID?globalThis.crypto.randomUUID():'story-'+Date.now()+'-'+Math.random().toString(36).slice(2);}
  async function pollPreparation(){
    if(prepPolling)return;
    prepPolling=true;
    try{
      while(!posting){
        let state;try{state=await api('stories/prepare/status');}catch(e){status('Não foi possível acompanhar o preparo: '+e.message);break;}
        if(state.running){
          preparing=true;const btn=$('stories-prepare');btn.disabled=true;btn.textContent='Preparo em andamento…';$('stories-start').disabled=true;
          const since=state.startedAt?new Date(state.startedAt).toLocaleTimeString('pt-BR'):'';
          status('Preparo em andamento'+(since?' desde '+since:'')+' — pode atualizar a página que ele continua.');
          await new Promise(r=>setTimeout(r,1500));continue;
        }
        preparing=false;
        const btn=$('stories-prepare');btn.disabled=posting;btn.textContent='Preparar e conferir vínculos';
        if(state.error){pendingPreparationId='';queueDraft();status('O preparo anterior falhou: '+state.error);}
        else if(state.ready&&pendingPreparationId&&state.id===pendingPreparationId){await restorePrepared(state.id);}
        else if(state.ready&&!prepared){pendingPreparationId='';queueDraft();status('Um preparo terminou, mas a seleção mudou. Clique em Preparar e conferir vínculos.');}
        else if(pendingPreparationId&&!state.ready){pendingPreparationId='';queueDraft();$('stories-preflight-summary').textContent='Dados preservados — confira os vínculos novamente antes de publicar';}
        break;
      }
    }finally{prepPolling=false;if(!posting&&!preparing){const btn=$('stories-prepare');btn.disabled=false;btn.textContent='Preparar e conferir vínculos';}}
  }
 function requestSelection(){
  const chosen=[...$('stories-pages').querySelectorAll('input:checked')].map(x=>x.dataset.page),checkout=$('stories-checkout').value.trim(),folderUrl=$('stories-drive').value.trim();
  if(!chosen.length)throw new Error('Selecione ao menos uma página de destino.');
  if(!/^https:\/\//i.test(checkout))throw new Error('Informe o checkout HTTPS.');
  if(!folderUrl||!driveFiles.length||folderUrl!==loadedDriveUrl)throw new Error('Carregue os vídeos da pasta do Drive informada.');
  const hookIds=[...$('stories-drive-files').querySelectorAll('[data-hook-index]:checked')].map(x=>driveFiles[Number(x.dataset.hookIndex)]?.id).filter(Boolean);
  if(!hookIds.length)throw new Error('Marque pelo menos um vídeo de gancho.');
  return {pageIds:chosen,pages:pages.filter(p=>chosen.includes(String(p.facebookId||p.id))),checkoutUrl:checkout,folderUrl,hookIds,bindings};
 }
 function situationText(situation){
  if(!situation)return '<span class="story-status">Prepare novamente para ver a situação</span>';
  const access={token:'Token: OK',reference:'Token: referência',none:'Token: sem acesso','binding-no-access':'Token: perfil sem acesso'}[situation.access]||'Token: —';
  const miwra={active:'Miwra: ativa',inactive:'Miwra: inativa',outside:'Fora do Miwra',unavailable:'Miwra indisponível',unknown:'Miwra: sem dados'}[situation.miwra]||'Miwra: —';
  const when=situation.lastOkAt?new Date(situation.lastOkAt).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'sem análise';
  return '<span class="story-status">'+esc(access)+'</span><span class="story-status">'+esc(miwra)+'</span><small>Análise: '+esc(when)+'</small>';
 }
 function renderPreparation(){
  if(!reviewSnapshot)return;
  const only=$('stories-preflight-only').checked,checks=reviewSnapshot.checks.filter(c=>!only||c.warning||c.error);
  $('stories-preflight-list').innerHTML='<table class="views-table"><thead><tr><th>Página</th><th>Uso no lote</th><th>Perfil vinculado</th><th>Situação</th><th>Conferência</th></tr></thead><tbody>'+(checks.length?checks.map(c=>'<tr class="'+(c.error?'story-reference-error':c.warning?'story-reference-warning':'')+'"><td>'+esc(c.name)+'</td><td>'+esc(c.roles.join(' / '))+'</td><td><select data-story-binding="'+esc(c.pageId)+'" aria-label="Perfil de '+esc(c.name)+'"><option value="">Detectar automaticamente</option>'+reviewSnapshot.accounts.map(a=>'<option value="'+esc(a.id)+'" '+(a.id===(bindings[c.pageId]||c.account)?'selected':'')+'>'+esc(a.name)+'</option>').join('')+'</select></td><td>'+situationText(c.situation)+'</td><td>'+esc(c.error||c.warning||'Acesso confirmado')+'</td></tr>').join(''):'<tr><td colspan="5">Nenhuma página precisa de conferência.</td></tr>')+'</tbody></table>'+(reviewSnapshot.accountErrors?.length?'<p class="hint">'+reviewSnapshot.accountErrors.map(e=>esc(e.name+': '+e.error)).join(' · ')+'</p>':'');
 }
 function stepLabel(value){return value==='unconfirmed'?'Sem confirmação (confira na Página)':value==='posted'?'Postado':value==='previous'?'Já confirmada':value==='failed'?'Falhou':value==='skipped'?'Pulado':value==='pending'?'Pendente':'—';}
 function hookAlreadyPosted(item){return ['posted','previous','unconfirmed'].includes(item?.steps?.hook)||Boolean(item?.hookPublished);}
 function pendingLinkPages(){return [...partialPages.values()];}
 function renderSkipHook(){const items=[...partialPages.values()];$('stories-skip-hook-wrap').hidden=!items.length;$('stories-skip-hook-count').textContent=items.length;$('stories-skip-hook-pages').textContent=items.map(item=>item.name||item.pageId).join(', ');}
 function scheduleRecentRefresh(){clearTimeout(recentTimer);const now=Date.now(),times=[...recentPosted.values()].map(item=>Date.parse(item.at)+24*3600000).filter(time=>Number.isFinite(time)&&time>now),delay=times.length?Math.max(30000,Math.min(...times)-now+1000):5*60*1000;recentTimer=setTimeout(()=>{void loadRuns();void loadSchedule();},delay);}
 function renderExecution(run){
  const source=run?.results?.length?run:lastRun,results=(source?.results||[]).filter(item=>item.steps),box=$('stories-run-log');
  if(!results.length){box.hidden=true;return;}
  const posted=results.filter(item=>item.status==='posted').length,failed=results.filter(item=>item.status==='error').length;
  box.hidden=false;
  $('stories-run-log-summary').textContent='Execução do último lote · '+posted+' completo(s) · '+failed+' com erro · '+results.length+' página(s)';
  $('stories-run-log-table').innerHTML='<table class="views-table"><thead><tr><th>Página</th><th>Isca</th><th>Story 2 (link)</th><th>Situação</th></tr></thead><tbody>'+results.map(item=>{
    const cls=item.status==='error'?'story-reference-error':hookAlreadyPosted(item)&&item.steps?.link!=='posted'&&item.status!=='posted'?'story-reference-warning':'';
    return '<tr class="'+cls+'"><td>'+esc(item.name||item.pageId)+'<small>'+esc(String(item.pageId))+'</small></td><td>'+esc(stepLabel(item.steps?.hook))+'</td><td>'+esc(stepLabel(item.steps?.link))+'</td><td>'+esc(item.error||(item.status==='posted'?'Completo':item.status==='pending'?'Ainda não executado':item.status))+'</td></tr>';
  }).join('')+'</tbody></table>';
 }
 async function loadRuns(){try{const data=await api('stories/runs');latestRun=data.latest||null;recentPosted=new Map((data.recent||[]).map(item=>[String(item.pageId),item]));partialPages=new Map((data.partial||[]).map(item=>[String(item.pageId),item]));for(const id of recentPosted.keys())deselectedPages.delete(id);renderExecution(latestRun);renderSkipHook();render();scheduleRecentRefresh();}catch{}}
 async function loadSchedule(){try{const data=await api('stories/schedule');scheduleReport=data;$('stories-schedule-enabled').checked=Boolean(data.enabled);if(data.time)$('stories-schedule-time').value=data.time;renderSchedule();}catch{}}
 function renderSchedule(){const data=scheduleReport;if(!data)return;const next=data.enabled&&data.nextAt?new Date(data.nextAt).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'',last=data.lastResult?' · último: '+data.lastResult:'';$('stories-schedule-status').textContent=(data.enabled?'Ligado · próxima execução '+next:'Desligado')+last;}
 function showPreparation(review){
  reviewSnapshot=review;queueDraft();
  const missing=review.checks.filter(c=>c.error).length,warnings=review.checks.filter(c=>c.warning&&!c.error).length,miwraDown=review.miwra?.loaded===false;
  const panel=$('stories-preflight');panel.hidden=false;panel.open=!review.ready||warnings>0;
  $('stories-preflight-summary').textContent=review.ready?(warnings?'Vínculos conferidos · '+warnings+' página(s) para conferir'+(miwraDown?' · Miwra indisponível':'')+' · lote liberado':'Vínculos conferidos · lote pronto para publicar'+(miwraDown?' · Miwra indisponível':'')):missing+' página(s) com pendência — ajuste antes de publicar'+(miwraDown?' · Miwra indisponível':'');
  renderPreparation();
 }
 $('stories-preflight-only').addEventListener('change',renderPreparation);
 $('stories-schedule-save').addEventListener('click',async()=>{const button=$('stories-schedule-save');button.disabled=true;try{scheduleReport=await api('stories/schedule',{enabled:$('stories-schedule-enabled').checked,time:$('stories-schedule-time').value});renderSchedule();status('Agendamento diário salvo.');}catch(e){status('Não foi possível salvar o agendamento: '+e.message);}finally{button.disabled=false;}});
 $('stories-preflight-list').addEventListener('change',event=>{const id=event.target.dataset.storyBinding;if(!id)return;if(event.target.value)bindings[id]=event.target.value;else delete bindings[id];try{localStorage.setItem('autofy-story-bindings',JSON.stringify(bindings));}catch{}invalidatePreparation();$('stories-preflight-summary').textContent='Vínculos alterados — confira novamente para liberar o lote';status('Perfil selecionado. Clique em Preparar e conferir vínculos.');});
 for(const id of ['stories-pages','stories-drive-files','stories-checkout','stories-drive','stories-min-followers'])$(id).addEventListener('input',invalidatePreparation);
 $('stories-prepare').addEventListener('click',async()=>{
  let body;try{body=requestSelection();}catch(e){status(e.message);return;}
  invalidatePreparation();const version=prepVersion;preparing=true;const btn=$('stories-prepare');btn.disabled=true;btn.textContent='Conferindo vínculos…';let seconds=0;status('Conferindo páginas, perfis e acesso aos Reels…');const ticker=setInterval(()=>status('Conferindo páginas e acesso aos Reels… '+(++seconds)+' s'),1000);
  const requestId=newRequestId();body.requestId=requestId;pendingPreparationId=requestId;queueDraft();
  try{const review=await api('stories/prepare',body);if(version!==prepVersion){status('Seleção alterada durante a conferência. Prepare novamente.');return;}pendingPreparationId='';prepared=review;showPreparation(review);$('stories-start').disabled=!review.ready;status(review.ready?'Preparo concluído. Revise os vínculos e clique em Publicar Stories.':'Publicação bloqueada até resolver as pendências acima.');}catch(e){
    let state=null;try{state=await api('stories/prepare/status');}catch{}
    if(state?.running){void pollPreparation();status('Um preparo já está em andamento; ele continua em segundo plano e aparece aqui quando terminar.');}
    else{status('Falha no preparo: '+e.message);pendingPreparationId='';queueDraft();}
  }finally{clearInterval(ticker);if(!prepPolling){preparing=false;btn.disabled=posting;btn.textContent='Preparar e conferir vínculos';}}
 });
 $('stories-start').addEventListener('click',async()=>{
  if(!prepared?.ready)return status('Prepare o lote e resolva os vínculos antes de publicar.');
  const planId=prepared.id,skipHookPageIds=$('stories-skip-hook').checked?pendingLinkPages().map(item=>String(item.pageId)):[];$('stories-start').disabled=true;$('stories-prepare').disabled=true;posting=true;
  try{await api('stories/start',{planId,skipHookPageIds});prepared=null;pendingPreparationId='';queueDraft();status('Lote iniciado com os vínculos conferidos.');void pollStories();}catch(e){posting=false;invalidatePreparation();$('stories-prepare').disabled=false;status('Não foi possível iniciar: '+e.message);}
 });

 const DRAFT_KEY='autofy-stories-draft-v1';
 function queueDraft(){if(restoringDraft)return;clearTimeout(draftTimer);draftTimer=setTimeout(saveDraft,150);}
 function draftValue(){
   return {version:1,checkout:$('stories-checkout').value,folderUrl:$('stories-drive').value,minFollowers:$('stories-min-followers').value,loadedDriveUrl,
     pages:pages.map(p=>({id:p.id,facebookId:p.facebookId,name:p.name,followers:p.followers,active:p.active,account:p.account,accountName:p.accountName,provisional:p.provisional})),
     rankedReels:analytics?.rankedReels||[],driveFiles,deselectedPages:[...deselectedPages],hookIds:[...$('stories-drive-files').querySelectorAll('[data-hook-index]:checked')].map(x=>driveFiles[Number(x.dataset.hookIndex)]?.id).filter(Boolean),
     bindings,review:reviewSnapshot,preparedId:prepared?.id||pendingPreparationId||null,lastRun,
     expanded:{drive:$('stories-drive-details').open,plan:$('stories-plan-details').open,preflight:$('stories-preflight').open}};
 }
 function queueServerDraft(value){
   const key=JSON.stringify({...value,savedAt:undefined});
   if(posting||!draftReady||key===lastServerKey)return;
   clearTimeout(serverSaveTimer);
   serverSaveTimer=setTimeout(async()=>{
     if(restoringDraft||!draftReady)return;
     try{await api('stories/draft',{draft:value});lastServerKey=key;}catch(e){status('Preparo salvo neste navegador; não foi possível gravar na pasta de dados do Autofy: '+(e.message||'erro'));}
   },1000);
 }
 function saveDraft(){
   if(restoringDraft)return;clearTimeout(draftTimer);
   const value={...draftValue(),savedAt:new Date().toISOString()};
   try{localStorage.setItem(DRAFT_KEY,JSON.stringify(value));}catch{status('Não foi possível salvar o preparo neste navegador. Verifique o armazenamento disponível.');}
   if(draftReady)queueServerDraft(value);
 }
 function draftFromLocal(){
   try{const value=JSON.parse(localStorage.getItem(DRAFT_KEY)||'null');return value&&value.version===1?value:null;}catch{return null;}
 }
 function draftStamp(value){const time=Date.parse(value?.savedAt||'');return Number.isFinite(time)?time:0;}
 function applyDraft(value,fromServer=false){
   if(!value||value.version!==1)return false;
   restoringDraft=true;
   try{
     for(const [id,key] of [['stories-checkout','checkout'],['stories-drive','folderUrl'],['stories-min-followers','minFollowers']])if(typeof value[key]==='string')$(id).value=value[key];
     pages=Array.isArray(value.pages)?value.pages:[];analytics={rankedReels:Array.isArray(value.rankedReels)?value.rankedReels:[]};driveFiles=Array.isArray(value.driveFiles)?value.driveFiles:[];loadedDriveUrl=value.loadedDriveUrl||'';
     deselectedPages.clear();for(const id of value.deselectedPages||[])deselectedPages.add(String(id));
     if(value.bindings&&typeof value.bindings==='object')bindings=value.bindings;
     try{localStorage.setItem('autofy-story-bindings',JSON.stringify(bindings));}catch{}
     render();
     const hooks=new Set(value.hookIds||[]);
     $('stories-drive-files').innerHTML=driveFiles.length?driveFiles.map((f,i)=>'<label class="story-page-row"><input type="checkbox" data-hook-index="'+i+'" '+(hooks.has(f.id)?'checked':'')+'><span>'+esc(f.name)+'</span></label>').join(''):'Carregue os vídeos do Drive.';
     $('stories-drive-summary').textContent=driveFiles.length+' vídeo(s) salvos — expandir lista';
     if(value.review?.checks&&value.review?.accounts){showPreparation(value.review);$('stories-preflight-summary').textContent='Preparo restaurado — conferindo validade';}
     pendingPreparationId=typeof value.preparedId==='string'?value.preparedId:'';
     if(value.lastRun&&!lastRun){lastRun=value.lastRun;renderStoryRun({...lastRun,running:false});}
     if(value.expanded){$('stories-drive-details').open=!!value.expanded.drive;$('stories-plan-details').open=!!value.expanded.plan;$('stories-preflight').open=!!value.expanded.preflight;}
     status(fromServer?'Preparo restaurado da pasta de dados do Autofy.':'Preparo restaurado com as páginas, vídeos e vínculos salvos.');
   }finally{restoringDraft=false;}
   lastServerKey=JSON.stringify({...value,savedAt:undefined});
   if(pendingPreparationId)void restorePrepared(pendingPreparationId);
   else if(reviewSnapshot)$('stories-preflight-summary').textContent='Preparo salvo — confira os vínculos novamente antes de publicar';
   return true;
 }
 async function restoreDraft(){
   const local=draftFromLocal();
   if(local)applyDraft(local);
   let server=null;
   try{server=(await api('stories/draft')).draft;}catch{}
   if(server&&!(local&&draftStamp(local)>=draftStamp(server)))applyDraft(server,true);
   else lastServerKey='';
   draftReady=true;queueDraft();
 }
 async function restorePrepared(id){
  const version=prepVersion;
  try{const result=await api('stories/prepared?id='+encodeURIComponent(id));if(version!==prepVersion||pendingPreparationId!==id)return;
    if(result.valid){prepared=result;pendingPreparationId='';showPreparation(result);$('stories-start').disabled=posting||!result.ready;status(result.ready?'Preparo restaurado e válido para publicação.':'Preparo restaurado. Resolva os vínculos pendentes.');}
    else{$('stories-preflight-summary').textContent='Dados preservados — verificando se o preparo ainda está em andamento';$('stories-start').disabled=true;void pollPreparation();}
    queueDraft();
  }catch{if(version===prepVersion){$('stories-start').disabled=true;status('Dados restaurados. Não foi possível conferir a validade do preparo; confira os vínculos antes de publicar.');}}
 }
 $('screen-stories').addEventListener('input',queueDraft);
 $('screen-stories').addEventListener('change',queueDraft);
 for(const id of ['stories-drive-details','stories-plan-details','stories-preflight'])$(id).addEventListener('toggle',queueDraft);
 window.addEventListener('pagehide',saveDraft);
 window.addEventListener('hashchange',()=>{
  if(location.hash==='#stories'&&prepared?.id){pendingPreparationId=prepared.id;prepared=null;$('stories-start').disabled=true;void restorePrepared(pendingPreparationId);}
  saveDraft();
 });
 void restoreDraft();
})();
