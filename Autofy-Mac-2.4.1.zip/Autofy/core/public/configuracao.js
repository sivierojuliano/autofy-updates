// Configurações sem botões de salvar e assistente do primeiro acesso.
// Roda depois do app.js e do views.js: usa $, api, settings, sync e selectLinked de lá.
(()=>{
  const state=$('#settings-auto');
  const say=(text,tone='')=>{state.textContent=text;state.dataset.tone=tone;};
  const fields={'base-url':'baseUrl',profile:'profile',cookie:'cookie','browser-mode':'browser','adspower-id':'adsPowerUserId','adspower-api':'adsPowerApi','adspower-key':'adsPowerKey','incogniton-id':'incognitonProfileId','incogniton-api':'incognitonApi','facebook-password':'facebookPassword','main-account-name':'mainName'};
  const secrets=new Set(['cookie','adspower-key','facebook-password']);
  const connection=new Set(['base-url','profile','cookie']);
  let meta=null,queue=Promise.resolve();

  function tag(id,text,ok){const item=$('#'+id);item.textContent=text;item.classList.toggle('ok',ok);}
  function tags(){
    const miwra=Boolean(settings.baseUrl&&settings.cookieConfigured&&settings.profile),extras=(settings.accounts||[]).length;
    tag('tag-miwra',miwra?'Conectado':'Pendente',miwra);
    if(meta)tag('tag-meta',meta.tokenConfigured?'Conectada':'Pendente',Boolean(meta.tokenConfigured));
    tag('tag-accounts',extras?(1+extras)+' contas':'Só a principal',false);
    tag('tag-browser',nomeNavegador(settings.browser),false);
    const mode=$('#browser-mode').value;
    for(const id of ['adspower-id','adspower-api','adspower-key'])$('#'+id).closest('label').hidden=mode!=='adspower';
    for(const id of ['incogniton-id','incogniton-api'])$('#'+id).closest('label').hidden=mode!=='incogniton';
    $('#adspower-hint').hidden=mode!=='adspower';$('#incogniton-hint').hidden=mode!=='incogniton';
  }
  async function refreshMeta(){try{meta=await api('views');}catch{meta=meta||{};}tags();return meta;}
  function connectionFields(){
    $('#base-url').value=settings.baseUrl||'';$('#profile').value=settings.profile||'';$('#cookie').value='';
    $('#cookie-state').textContent=settings.cookieConfigured?'Cookie salvo. Cole um novo para trocar.':'Ainda não configurado.';
    $('#setup-reminder').hidden=Boolean(settings.cookieConfigured&&settings.profile);
  }

  // Salva só o campo que mudou: rascunhos de outras telas não vão junto.
  // Navegador anti-detect escolhido antes de ter o ID do perfil: mostra os campos e espera o ID.
  const profileField={adspower:'adspower-id',incogniton:'incogniton-id'};
  function autosave(id){
    const input=$('#'+id),value=input.value.trim();
    if(secrets.has(id)&&!value)return;
    if(String(settings[fields[id]]??'')===value&&!secrets.has(id))return;
    if(id==='browser-mode'&&PERFIS[value]&&!$('#'+profileField[value]).value.trim()){tags();say('Cole o ID do perfil do '+PERFIS[value]+' logo abaixo. O navegador muda para o '+PERFIS[value]+' assim que o ID for salvo.');return;}
    const wanted=$('#browser-mode').value;
    queue=queue.then(async()=>{
      say('Salvando e conferindo…');
      try{
        settings=await api('settings',{[fields[id]]:value});
        if(secrets.has(id))input.value='';
        browserFields();
        // O ID chegou depois da escolha do navegador: mantém a escolha na tela e salva o navegador em seguida.
        const pending=wanted!==(settings.browser||'chrome')&&profileField[wanted]===id;
        if(pending)$('#browser-mode').value=wanted;
        tags();
        if(pending){autosave('browser-mode');return;}
        if(connection.has(id)){
          connectionFields();
          if(settings.cookieConfigured&&settings.profile&&settings.baseUrl){await sync(true);say('Salvo. Miwra conectado.','ok');return;}
        }
        say('Salvo.','ok');
      }catch(error){say(error.message,'error');}
    });
  }
  for(const id of Object.keys(fields)){
    const input=$('#'+id);let timer;
    const later=()=>{clearTimeout(timer);timer=setTimeout(()=>autosave(id),300);};
    input.addEventListener('change',later);
    if(id==='browser-mode')input.addEventListener('change',tags);
    input.addEventListener('paste',later);
  }

  // Token da conta principal: valida ao colar.
  const token=$('#views-token');let tokenTimer;
  const saveToken=()=>{clearTimeout(tokenTimer);tokenTimer=setTimeout(async()=>{if(token.value.trim()&&!$('#views-save').disabled){$('#views-save').click();setTimeout(refreshMeta,2500);}},300);};
  token.addEventListener('change',saveToken);token.addEventListener('paste',saveToken);
  $('#views-version').addEventListener('change',()=>{if(meta?.tokenConfigured)$('#views-save').click();});
  $('#views-disconnect').addEventListener('click',()=>setTimeout(refreshMeta,1200));

  // Contas do Facebook: linha completa salva sozinha; token e senha de cada conta, ao colar.
  window.saveAccountsLater=()=>{
    const list=accountsDraft();
    if(list.some(item=>!item.name||!item.profile)){$('#accounts-state').textContent='Preencha o nome e o perfil para salvar a conta.';return;}
    $('#accounts-save').click();
  };
  const list=$('#accounts-list');
  list.addEventListener('change',event=>{
    if(event.target.matches('.acct-name,.acct-profile,.acct-ids'))window.saveAccountsLater();
    if(event.target.matches('.acct-token'))event.target.closest('.acct-row').querySelector('.acct-token-save').click();
    if(event.target.matches('.acct-pass'))event.target.closest('.acct-row').querySelector('.acct-pass-save').click();
  });
  list.addEventListener('paste',event=>{
    if(event.target.matches('.acct-token'))setTimeout(()=>event.target.blur(),50);
  });

  // ===== Assistente =====
  const STEPS=['Endereço do Miwra','Cookie do Miwra','Perfil do Miwra','Token da Meta','IDs das Páginas'];
  const check='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 13l4 4L19 7"></path></svg>';
  let box=null,step=1,review=false,status='idle',message='',profiles=[],idsRun=false,idsNote='',ids=false,timer=null;
  const tokenOk=()=>Boolean(meta?.tokenConfigured);
  const stepDone=n=>({1:Boolean(settings.baseUrl),2:Boolean(settings.cookieConfigured),3:Boolean(settings.profile),4:tokenOk(),5:idsRun||Object.keys(settings.mappings||{}).length>0})[n];
  const firstPending=()=>[1,2,3,4,5].find(n=>!stepDone(n))||5;
  const waiting={1:'Cole o endereço para continuar.',2:'Cole o cookie para continuar.',3:'Escolha um perfil para continuar.',4:'Cole o token para continuar.',5:'Busque os IDs para continuar.'};
  const saved={1:'Endereço salvo.',2:'Cookie salvo.',3:'Perfil salvo.',4:'Token salvo.',5:'IDs das Páginas salvos.'};
  const input=(id,type,label,placeholder,value='')=>'<label class="wizard-label" for="'+id+'">'+label+'</label><input id="'+id+'" type="'+type+'" autocomplete="off" spellcheck="false" placeholder="'+esc(placeholder)+'" value="'+esc(value)+'">';
  function body(){
    if(step===1)return '<h2>Qual é o endereço do seu Miwra?</h2><p>Abra o seu painel do Miwra no Chrome, copie o endereço do topo do navegador e cole aqui.</p>'+input('wizard-url','url','Endereço do painel','https://seu-painel.miwra.com.br',settings.baseUrl||'');
    if(step===2)return '<h2>Copie o cookie do Miwra</h2><p>É o que permite ao Autofy ler o seu painel.</p><ol><li>Abra o painel do Miwra no Chrome e faça login.</li><li>Aperte <b>F12</b> e clique na aba <b>Rede</b> (Network).</li><li>Aperte <b>F5</b>.</li><li>Clique em qualquer linha do endereço do Miwra.</li><li>Em <b>Cabeçalhos de solicitação</b>, ache a linha <b>Cookie:</b></li><li>Copie o valor inteiro e cole abaixo.</li></ol>'+input('wizard-cookie','password','Cookie do Miwra',settings.cookieConfigured?'Cookie salvo. Cole um novo para trocar.':'Cole aqui');
    if(step===3){
      const current=settings.profile||'',options=[...profiles.map(name=>({value:name,label:name})),{value:'*',label:'Todos os perfis'}];
      if(current&&!options.some(item=>item.value===current))options.unshift({value:current,label:current});
      return '<h2>Qual perfil do Miwra é o seu?</h2><p>Estes são os perfis do seu painel. Não precisa digitar o nome.</p><div class="wizard-options">'+options.map(item=>'<button type="button" class="wizard-option'+(item.value===current?' on':'')+'" data-profile="'+esc(item.value)+'" aria-pressed="'+(item.value===current)+'"><span>'+esc(item.label)+'</span>'+(item.value===current?check:'')+'</button>').join('')+'</div>';
    }
    if(step===4)return '<h2>Conecte o token da Meta</h2><p>O token busca os IDs das Páginas, lê as views e posta pela API.</p><ol><li>Com o Facebook da conta logado, abra o <a href="https://developers.facebook.com/tools/explorer" target="_blank" rel="noreferrer noopener">Explorador da Graph API</a>.</li><li>Adicione as permissões abaixo.</li><li>Gere o token, copie e cole abaixo.</li></ol><div class="wizard-perms">'+['pages_show_list','pages_read_engagement','read_insights','pages_manage_posts','pages_manage_engagement','pages_manage_metadata'].map(name=>'<span>'+name+'</span>').join('')+'</div>'+input('wizard-token','password','Token de usuário da Meta',tokenOk()?'Token salvo. Cole um novo para trocar.':'Cole aqui');
    return '<h2>Puxe os IDs das suas Páginas</h2><p>O Autofy liga cada Página do Miwra à Página certa do Facebook. É o último passo.</p>'+(ids?'<div class="wizard-loading"><i></i><span>Buscando os IDs. Isso pode levar alguns minutos.</span></div>':'<button id="wizard-ids" type="button" class="cta">'+(stepDone(5)?'Buscar IDs de novo':'Buscar IDs das Páginas')+'</button>')+(idsNote?'<p class="wizard-note">'+esc(idsNote)+'</p>':'');
  }
  function render(){
    const canGo=stepDone(step)&&status!=='busy'&&!ids;
    const text=status==='busy'?'Salvando e conferindo…':status==='error'?message:status==='ok'?message:stepDone(step)?saved[step]:waiting[step];
    const tone=status==='busy'?'':status==='error'?'error':stepDone(step)?'ok':'';
    box.innerHTML='<div class="wizard-card" role="dialog" aria-modal="true" aria-label="Configuração do Autofy">'
      +'<aside><div class="wizard-brand"><strong>Autofy</strong><small>'+(review?'Rever tutorial':'Configuração inicial')+'</small></div><ol class="wizard-rail">'+STEPS.map((label,index)=>{const n=index+1,name=n<step?'done':n===step?'current':'';return '<li class="'+name+'"'+(n===step?' aria-current="step"':'')+'><i>'+(n<step?check:n)+'</i><span>'+label+'</span></li>';}).join('')+'</ol><small class="wizard-privacy">Tudo fica salvo só neste computador.</small></aside>'
      +'<main><div class="wizard-top"><b>Passo '+step+' de 5</b>'+(review?'<button id="wizard-close" type="button">Fechar</button>':'')+'</div><div class="wizard-body">'+body()+'</div>'
      +'<div class="wizard-status" role="status" data-tone="'+tone+'">'+esc(text)+'</div><div class="wizard-actions">'+(step>1?'<button id="wizard-back" type="button">Voltar</button>':'')+'<button id="wizard-next" type="button" class="primary"'+(canGo?'':' disabled')+'>'+(step===5?'Concluir':'Continuar')+'</button></div></main></div>';
    box.querySelector('.wizard-body input')?.focus();
  }
  const run=async action=>{status='busy';render();try{message=await action();status='ok';}catch(error){message=error.message;status='error';}render();};
  const saveUrl=value=>run(async()=>{settings=await api('settings',{baseUrl:value,setupStarted:true});connectionFields();tags();return 'Endereço salvo.';});
  const saveCookie=value=>run(async()=>{
    const result=await api('setup/miwra',{cookie:value});
    settings=result.settings;profiles=result.profiles;connectionFields();tags();
    return 'Salvo. Miwra conectado: '+result.pageCount+' Página(s) encontrada(s).';
  });
  const saveToken2=value=>run(async()=>{
    await api('views/settings',{token:value,apiVersion:$('#views-version').value.trim()||'v26.0',enabled:true});
    await refreshMeta();
    if(!tokenOk())throw new Error('A Meta não confirmou o token. Gere um novo e cole de novo.');
    return 'Salvo. Token válido'+(meta.user?.name?' · '+meta.user.name:'')+'.';
  });
  const loadProfiles=()=>run(async()=>{
    const result=await api('setup/miwra',{});
    settings=result.settings;profiles=result.profiles;return stepDone(3)?saved[3]:waiting[3];
  });
  const searchIds=async()=>{
    ids=true;status='idle';idsNote='';render();
    try{
      const result=await api('pages/import-ids',{account:'main'});
      settings=result.settings;settings.mappings||={};await selectLinked(result);
      const missing=(result.rows||[]).filter(row=>!row.facebookPageId).map(row=>row.name).filter(Boolean);
      idsRun=true;message=(result.added+result.kept)+' Página(s) ligada(s).';status='ok';
      if(missing.length)idsNote=missing.length+' Página(s) ficaram sem ID e podem ser ligadas depois em Publicações: '+missing.slice(0,5).join(', ')+(missing.length>5?'…':'')+'.';
    }catch(error){message=error.message;status='error';}
    ids=false;render();
  };
  function go(n){
    step=n;status='idle';message='';render();
    if(n===3)void loadProfiles();
  }
  function close(){box?.remove();box=null;document.removeEventListener('keydown',onKey);}
  function onKey(event){if(review&&event.key==='Escape')close();}
  async function finish(){
    if(!review){settings=await api('settings',{setupDone:true});settings.mappings||={};}
    close();connectionFields();tags();
    if(!review){location.hash='#publicacoes';await sync().catch(error=>notice(error.message));}
  }
  async function open(asReview=false){
    if(box)return;
    review=asReview;await refreshMeta();
    box=document.createElement('div');box.className='wizard';document.body.appendChild(box);
    box.addEventListener('click',event=>{
      const button=event.target.closest('button');if(!button||button.disabled)return;
      if(button.id==='wizard-close')return close();
      if(button.id==='wizard-back')return go(step-1);
      if(button.id==='wizard-ids')return void searchIds();
      if(button.id==='wizard-next')return step===5?void finish().catch(error=>{message=error.message;status='error';render();}):go(step+1);
      if(button.dataset.profile)void run(async()=>{settings=await api('settings',{profile:button.dataset.profile});connectionFields();tags();return saved[3];});
    });
    const submit=target=>{
      const value=target.value.trim();if(!value)return;
      clearTimeout(timer);timer=setTimeout(()=>{({'wizard-url':saveUrl,'wizard-cookie':saveCookie,'wizard-token':saveToken2})[target.id]?.(value);},300);
    };
    box.addEventListener('paste',event=>{if(event.target.matches('input'))setTimeout(()=>submit(event.target),0);});
    box.addEventListener('change',event=>{if(event.target.matches('input'))submit(event.target);});
    document.addEventListener('keydown',onKey);
    idsRun=false;idsNote='';go(review?1:firstPending());
  }
  // Rever tutorial: abre de qualquer forma. Sozinho, só em instalação nova ou assistente pela metade;
  // quem já usa o Autofy (cookie salvo sem passar pelo assistente) não vê nada.
  $('#setup-review').onclick=()=>void open(true);
  window.autofySetup={start:async()=>{
    await refreshMeta();
    if(!settings.setupDone&&!settings.networkMode&&(settings.setupStarted||!settings.cookieConfigured))await open(false);
  }};
})();
