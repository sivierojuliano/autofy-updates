// Aba TESTE: ritmo das postagens pela API, banco de legendas sorteadas e a mesma interface do
// Postar por API. Só aparece quando o servidor diz que o modo teste está habilitado neste computador
// (arquivo modo-teste.txt ao lado da pasta core).
(() => {
  const el = id => document.getElementById(id);
  if (!el('screen-teste')) return;
  const PRODUCT = { all: 'ED + WL', ed: 'ED', wl: 'WL' };
  let report = null, enabled = false;
  const hours = minutes => minutes >= 60 ? Math.floor(minutes / 60) + 'h' + String(Math.round(minutes % 60)).padStart(2, '0') : Math.round(minutes) + ' min';
  function estimate() {
    const min = Number(el('rt-min').value) || 0, max = Number(el('rt-max').value) || 0;
    el('rt-estimate').textContent = max > 0 && max >= min
      ? 'Exemplo: 50 Páginas levam cerca de ' + hours((min + max) / 2 * 49) + ' só de espera, mais o tempo de envio de cada vídeo. O Autofy precisa ficar aberto até o fim.'
      : '';
  }
  function aviso() { const box = document.getElementById('api-teste-aviso'); const r = window.autofyRitmo; if (box) box.hidden = !(location.hash === '#teste' && r && r.enabled && r.on && r.schedule === true); }
  function fieldsState() { el('rt-fields').disabled = !el('rt-on').checked; el('rt-schedule-box').hidden = !el('rt-schedule').checked; }
  const windowsValue = () => [0, 1, 2].map(i => ({ from: el('rt-w' + i + '-from').value, to: el('rt-w' + i + '-to').value }));
  function renderBank() {
    const list = report.captions || [];
    el('rt-bank-count').textContent = list.length;
    el('rt-bank-rows').innerHTML = list.map(item => '<tr>'
      + '<td class="pp-wide">' + esc(item.text).replace(/\n/g, '<br>') + '<small>' + item.text.length + ' caractere(s)' + (/\{[^{}]*\|[^{}]*\}/.test(item.text) ? ' · com trechos que variam' : '') + '</small></td>'
      + '<td>' + esc(PRODUCT[item.product] || item.product) + '</td>'
      + '<td>' + (item.uses || 0) + '</td>'
      + '<td class="pp-remove"><button type="button" class="link-button" data-remove-caption="' + esc(item.id) + '" aria-label="Remover a legenda">Remover</button></td></tr>').join('')
      || '<tr><td colspan="4" class="empty">Nenhuma legenda ainda. Escreva uma por linha acima e clique em Adicionar ao banco.</td></tr>';
  }
  function render() {
    el('rt-on').checked = report.on; el('rt-min').value = report.minMinutes; el('rt-max').value = report.maxMinutes;
    el('rt-shuffle').checked = report.shuffle; el('rt-vary').checked = report.vary; el('rt-schedule').checked = report.schedule === true;
    (report.windows || []).forEach((w, i) => { el('rt-w' + i + '-from').value = w.from; el('rt-w' + i + '-to').value = w.to; });
    fieldsState(); estimate(); renderBank();
    el('rt-state').textContent = report.on ? 'Modo TESTE ligado: as próximas rodadas pela API já usam estas opções.' + (report.schedule ? ' Os slots 1, 2 e 3 de cada Página saem em horários sorteados: deixe o Autofy aberto até o último horário.' : '') : 'Modo TESTE desligado: as rodadas pela API seguem como sempre.';
  }
  // A interface do Postar por API é a mesma da outra aba: vem para esta aba enquanto ela está aberta e volta depois.
  function place() {
    const host = el('teste-api-host'), screen = el('screen-api');
    const [from, to] = enabled && location.hash === '#teste' ? [screen, host] : [host, screen];
    while (from.firstChild) to.appendChild(from.firstChild);
  }
  async function load() {
    try { report = await api('ritmo'); } catch { report = { enabled: false }; }
    enabled = Boolean(report.enabled);
    // BETA (modo-teste.txt): mostra os recursos em teste (.so-beta). Fora dele, quem abrir #computador volta.
    document.documentElement.classList.toggle('modo-beta', enabled);
    if (!enabled && location.hash === '#computador') location.hash = '#publicacoes'; window.autofyRitmo = report; window.dispatchEvent(new Event('autofy-ritmo')); aviso();
    if (!enabled) { if (location.hash === '#teste') location.hash = '#publicacoes'; return; }
    el('nav-teste').hidden = false;
    render(); place();
  }
  el('rt-on').addEventListener('change', fieldsState);
  el('rt-schedule').addEventListener('change', fieldsState);
  for (const id of ['rt-min', 'rt-max']) el(id).addEventListener('input', estimate);
  el('rt-save').addEventListener('click', guarded(async () => {
    report = await api('ritmo/save', { on: el('rt-on').checked, minMinutes: Number(el('rt-min').value), maxMinutes: Number(el('rt-max').value), shuffle: el('rt-shuffle').checked, vary: el('rt-vary').checked, schedule: el('rt-schedule').checked, windows: windowsValue() });
    window.autofyRitmo = report; window.dispatchEvent(new Event('autofy-ritmo')); aviso(); render(); el('rt-state').textContent = 'Salvo. ' + el('rt-state').textContent;
  }));
  el('rt-bank-add').addEventListener('click', guarded(async () => {
    const result = await api('ritmo/captions/add', { text: el('rt-bank-new').value, product: el('rt-bank-product').value });
    report = result; window.autofyRitmo = report; window.dispatchEvent(new Event('autofy-ritmo')); aviso(); renderBank(); el('rt-bank-new').value = '';
    el('rt-bank-hint').textContent = result.added + ' legenda(s) adicionada(s)' + (result.repeated ? ', ' + result.repeated + ' repetida(s) ignorada(s)' : '') + '.';
  }));
  el('rt-bank-rows').addEventListener('click', guarded(async event => {
    const button = event.target.closest('[data-remove-caption]'); if (!button) return;
    report = await api('ritmo/captions/remove', { id: button.dataset.removeCaption }); window.autofyRitmo = report; window.dispatchEvent(new Event('autofy-ritmo')); aviso(); renderBank(); el('rt-bank-hint').textContent = 'Legenda removida.';
  }));
  // Atualiza os usos do banco enquanto a aba está aberta (as rodadas contam cada sorteio).
  setInterval(() => { if (enabled && location.hash === '#teste' && !document.hidden) api('ritmo').then(data => { report = { ...report, captions: data.captions }; renderBank(); }).catch(() => {}); }, 15000);
  window.addEventListener('hashchange', () => { if (report && !enabled && location.hash === '#computador') { location.hash = '#publicacoes'; return; } place(); aviso(); });
  load();
})();
