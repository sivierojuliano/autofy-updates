// Aba "Vídeos do computador": escolhe vídeos do computador, mostra as miniaturas, envia os marcados
// para o Autofy (no próprio computador) e posta pela API da Meta, um vídeo por Página.
(() => {
  const el=id=>document.getElementById(id), key=document.querySelector('meta[name=publisher-key]').content;
  const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const MAX_VIDEOS=100, MAX_BYTES=1024*1024*1024;
  const mb=bytes=>(bytes/1024/1024).toFixed(1)+' MB';
  const clock=seconds=>Number.isFinite(seconds)&&seconds>0?Math.floor(seconds/60)+':'+String(Math.round(seconds%60)).padStart(2,'0'):'';
  // items: vídeos na tela, na ordem em que aparecem. Do computador (file) ou já guardados no Autofy (só id).
  let items=[],selected=new Set(),data={files:[],pages:[]},pages=new Set(),product='all',plan=null,working=false,loaded=false,revision=0,timer;
  // Sorteio ativo: pares vídeo → Página escolhidos pelo botão Sortear (some quando a seleção muda à mão).
  let draw=null;
  let account='main';try{account=localStorage.getItem('autofy-pc-conta')||'main';}catch{}
  const shownPages=()=>data.pages.filter(p=>product==='all'||p.product===product);
  const freePages=()=>shownPages().filter(p=>!p.postedToday);
  const hour=value=>value&&Number.isFinite(Date.parse(value))?new Date(value).toLocaleTimeString('pt-BR',{timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit'}):'';
  function error(message){el('pc-error').textContent=message||'';el('pc-error').hidden=!message;}
  async function api(path,body){
    if(body!==undefined)body={...body,account};else path+=(path.includes('?')?'&':'?')+'account='+encodeURIComponent(account);
    const r=await fetch('/api/local'+path,{method:body===undefined?'GET':'POST',headers:{'x-publisher-key':key,'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
    const result=await r.json().catch(()=>({}));
    if(r.status===401){location.assign('/login');throw Error('Entre novamente no Autofy.');}
    if(!r.ok)throw Error(result.error||'Falha na aba Vídeos do computador.');
    return result;
  }
  async function upload(item){
    const r=await fetch('/api/local/upload',{method:'POST',headers:{'x-publisher-key':key,'content-type':'application/octet-stream','x-file-name':encodeURIComponent(item.name)},body:item.file});
    const result=await r.json().catch(()=>({}));
    if(!r.ok)throw Error(result.error||'Não foi possível enviar '+item.name+'.');
    return result;
  }
  // ---- Impressão digital do vídeo (igual à do servidor, lib/local-videos.mjs): SHA-256 de
  // "tamanho|" + primeiro MB + último MB, 16 primeiros caracteres. Lê só 2 MB de cada arquivo.
  const FP=1024*1024;
  async function fingerprint(file){
    const head=new Uint8Array(await file.slice(0,Math.min(FP,file.size)).arrayBuffer());
    const tail=new Uint8Array(await file.slice(Math.max(0,file.size-FP),file.size).arrayBuffer());
    const prefix=new TextEncoder().encode(file.size+'|'),all=new Uint8Array(prefix.length+head.length+tail.length);
    all.set(prefix,0);all.set(head,prefix.length);all.set(tail,prefix.length+head.length);
    const digest=globalThis.crypto?.subtle?new Uint8Array(await crypto.subtle.digest('SHA-256',all)):sha256(all);
    return [...digest].map(b=>b.toString(16).padStart(2,'0')).join('').slice(0,16);
  }
  // SHA-256 em JavaScript, para quando o painel é aberto pela rede (sem crypto.subtle).
  function sha256(bytes){
    const K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    const H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    const length=bytes.length,padded=new Uint8Array(((length+9+63)>>6)<<6);padded.set(bytes);padded[length]=0x80;
    const view=new DataView(padded.buffer);view.setUint32(padded.length-4,length*8>>>0);view.setUint32(padded.length-8,Math.floor(length/0x20000000));
    const W=new Uint32Array(64),r=(x,n)=>(x>>>n)|(x<<(32-n));
    for(let o=0;o<padded.length;o+=64){
      for(let i=0;i<16;i++)W[i]=view.getUint32(o+i*4);
      for(let i=16;i<64;i++){const a=W[i-15],b=W[i-2];W[i]=(W[i-16]+(r(a,7)^r(a,18)^(a>>>3))+W[i-7]+(r(b,17)^r(b,19)^(b>>>10)))>>>0;}
      let [a,b,c,d,e,f,g,h]=H;
      for(let i=0;i<64;i++){const t1=(h+(r(e,6)^r(e,11)^r(e,25))+((e&f)^(~e&g))+K[i]+W[i])>>>0,t2=((r(a,2)^r(a,13)^r(a,22))+((a&b)^(a&c)^(b&c)))>>>0;h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;}
      H[0]=(H[0]+a)>>>0;H[1]=(H[1]+b)>>>0;H[2]=(H[2]+c)>>>0;H[3]=(H[3]+d)>>>0;H[4]=(H[4]+e)>>>0;H[5]=(H[5]+f)>>>0;H[6]=(H[6]+g)>>>0;H[7]=(H[7]+h)>>>0;
    }
    const out=new Uint8Array(32);H.forEach((v,i)=>new DataView(out.buffer).setUint32(i*4,v));return out;
  }
  const shuffle=list=>{const copy=[...list];for(let i=copy.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[copy[i],copy[j]]=[copy[j],copy[i]];}return copy;};
  // Casa ao acaso um vídeo diferente para cada Página, sem vídeo que a Página já recebeu
  // (emparelhamento máximo, com ordem sorteada: se existe uma combinação para todas, ele acha).
  function drawPairs(pageIds,videos){
    const sent=data.sentByPage||{},owner=new Map(),order=pageIds.map(()=>shuffle(videos.map((_,index)=>index)));
    const ok=(pi,vi)=>!(sent[pageIds[pi]]||[]).includes(videos[vi].fp);
    const tryPage=(pi,seen)=>{for(const vi of order[pi]){if(seen.has(vi)||!ok(pi,vi))continue;seen.add(vi);if(!owner.has(vi)||tryPage(owner.get(vi),seen)){owner.set(vi,pi);return true;}}return false;};
    for(const pi of shuffle(pageIds.map((_,index)=>index)))tryPage(pi,new Set());
    const byPage=new Map([...owner].map(([vi,pi])=>[pi,vi]));
    return {pairs:pageIds.map((pageId,pi)=>byPage.has(pi)?{key:videos[byPage.get(pi)].key,pageId}:null).filter(Boolean),missing:pageIds.filter((_,pi)=>!byPage.has(pi))};
  }
  el('pc-draw').onclick=async()=>{
    if(working||!loaded)return;
    const pageIds=[...pages];
    if(!pageIds.length){error('Marque as Páginas que vão receber os vídeos antes de sortear.');return;}
    if(pageIds.length>MAX_VIDEOS){error('Marque no máximo '+MAX_VIDEOS+' Páginas por sorteio.');return;}
    working=true;controls();error('');
    try{
      const candidates=items.filter(item=>!item.problem);
      for(const [index,item] of candidates.entries()){
        if(item.fp)continue;
        if(!item.file){item.fp=item.id;continue;}
        el('pc-upload-state').textContent='Conferindo os vídeos '+(index+1)+' de '+candidates.length+'…';
        item.fp=await fingerprint(item.file);
      }
      // O mesmo vídeo duas vezes na tela (outro nome) conta uma vez só.
      const unique=[...new Map(candidates.map(item=>[item.fp,item])).values()];
      const result=drawPairs(pageIds,unique);
      if(!result.pairs.length)throw Error('Nenhum vídeo da tela serve: as Páginas marcadas já receberam todos eles. Escolha mais vídeos.');
      draw={pairs:result.pairs};
      selected=new Set(result.pairs.map(pair=>pair.key));
      const name=id=>data.pages.find(p=>p.id===id)?.name||id;
      el('pc-upload-state').dataset.done='Sorteados '+result.pairs.length+' vídeo(s) diferentes para '+result.pairs.length+' Página(s).'+(result.missing.length?' Sem vídeo novo para '+result.missing.length+' Página(s): '+result.missing.slice(0,5).map(name).join(', ')+(result.missing.length>5?'…':'')+' (já receberam todos os vídeos da tela).':'');
      if(result.missing.length)error('Faltaram vídeos que essas Páginas ainda não receberam: '+result.missing.slice(0,5).map(name).join(', ')+(result.missing.length>5?'…':'')+'. Adicione mais vídeos e sorteie de novo, ou siga só com as sorteadas.');
      invalidate(true);grid();
    }catch(cause){error(cause.message);}finally{working=false;controls();}
  };
  // ---- Miniaturas: geradas aqui no navegador, a partir do arquivo, sem enviar nada ----
  const thumbQueue=[];let thumbsRunning=0;
  function queueThumb(item){thumbQueue.push(item);pumpThumbs();}
  function pumpThumbs(){
    while(thumbsRunning<2&&thumbQueue.length){
      const item=thumbQueue.shift();thumbsRunning++;
      makeThumb(item.file).then(result=>{item.thumb=result.image;item.duration=result.duration;}).catch(()=>{item.thumb='';item.thumbFailed=true;})
        .finally(()=>{thumbsRunning--;paintCard(item);pumpThumbs();});
    }
  }
  function makeThumb(file){
    return new Promise((resolve,reject)=>{
      const url=URL.createObjectURL(file),video=document.createElement('video');let done=false;
      const finish=(fn,value)=>{if(done)return;done=true;clearTimeout(limit);video.removeAttribute('src');video.load();URL.revokeObjectURL(url);fn(value);};
      const limit=setTimeout(()=>finish(reject,new Error('tempo')),20000);
      video.muted=true;video.preload='metadata';video.playsInline=true;
      video.onloadedmetadata=()=>{video.currentTime=Math.min(1,(video.duration||2)/3);};
      video.onseeked=()=>{
        try{
          const width=180,height=Math.round(width*(video.videoHeight||16)/(video.videoWidth||9));
          const canvas=document.createElement('canvas');canvas.width=width;canvas.height=Math.min(height,400);
          canvas.getContext('2d').drawImage(video,0,0,canvas.width,canvas.height);
          finish(resolve,{image:canvas.toDataURL('image/jpeg',0.72),duration:video.duration});
        }catch(cause){finish(reject,cause);}
      };
      video.onerror=()=>finish(reject,new Error('vídeo'));
      video.src=url;
    });
  }
  // ---- Grade de vídeos ----
  const keyOfFile=file=>'f:'+file.name+'|'+file.size+'|'+file.lastModified;
  function cardHtml(item){
    const on=selected.has(item.key),off=!on&&selected.size>=MAX_VIDEOS||Boolean(item.problem);
    const badge=item.state==='uploading'?'Enviando…':item.id?'No Autofy':'';
    const thumb=item.thumb?'<img src="'+esc(item.thumb)+'" alt="">':'<span>'+(item.file?(item.thumbFailed?'Sem prévia':'Gerando miniatura…'):'Guardado no Autofy')+'</span>';
    return '<label class="pc-card'+(on?' on':'')+(off?' off':'')+'" data-key="'+esc(item.key)+'"><input type="checkbox"'+(on?' checked':'')+(off||working?' disabled':'')+' aria-label="'+esc(item.name)+'">'
      +(badge?'<span class="pc-badge">'+esc(badge)+'</span>':'')+'<span class="pc-thumb">'+thumb+'</span><span class="pc-name" title="'+esc(item.name)+'">'+esc(item.name)+'</span>'
      +'<span class="pc-meta">'+[mb(item.size),clock(item.duration)].filter(Boolean).join(' · ')+(item.problem?' · '+esc(item.problem):'')+'</span></label>';
  }
  function paintCard(item){const card=el('pc-videos').querySelector('[data-key="'+CSS.escape(item.key)+'"]');if(card)card.outerHTML=cardHtml(item);}
  function grid(){el('pc-videos').innerHTML=items.map(cardHtml).join('')||'<p class="hint">Nenhum vídeo escolhido. Use "Escolher pasta" ou "Escolher vídeos".</p>';controls();}
  function addFiles(list){
    const known=new Set(items.map(item=>item.key));let added=0,ignored=0;
    const files=[...list].filter(file=>{if(!/\.mp4$/i.test(file.name)){ignored++;return false;}return true;})
      .sort((a,b)=>(a.webkitRelativePath||a.name).localeCompare(b.webkitRelativePath||b.name,'pt-BR',{numeric:true}));
    for(const file of files){
      const k=keyOfFile(file);if(known.has(k))continue;known.add(k);
      const item={key:k,file,name:file.name,size:file.size,thumb:'',problem:file.size>MAX_BYTES?'passa de 1 GB':''};
      items.push(item);added++;
      if(!item.problem&&selected.size<MAX_VIDEOS)selected.add(k);
      queueThumb(item);
    }
    grid();invalidate();
    error(ignored&&!added?'Nenhum MP4 nessa escolha.':'');
    el('pc-upload-state').textContent=added?added+' vídeo(s) adicionado(s)'+(ignored?' · '+ignored+' arquivo(s) que não são MP4 ignorado(s)':'')+'.':'';
  }
  for(const id of ['pc-folder','pc-files'])el(id).addEventListener('change',event=>{addFiles(event.target.files||[]);event.target.value='';});
  el('pc-videos').addEventListener('change',event=>{
    const card=event.target.closest('.pc-card');if(!card||working)return;
    const k=card.dataset.key;
    if(event.target.checked){if(selected.size>=MAX_VIDEOS){event.target.checked=false;error('Limite de 100 vídeos por lote.');return;}selected.add(k);}else selected.delete(k);
    error('');invalidate();grid();
  });
  el('pc-all-videos').onchange=()=>{
    if(working)return;
    selected=new Set(el('pc-all-videos').checked?items.filter(item=>!item.problem).slice(0,MAX_VIDEOS).map(item=>item.key):[]);
    invalidate();grid();
  };
  // Vídeos guardados no Autofy (de envios anteriores, até 3 dias) que não estão na grade: entram no fim, desmarcados.
  function mergeStored(files){
    const ids=new Set(items.filter(item=>item.id).map(item=>item.id));
    items=items.filter(item=>item.file||files.some(file=>file.id===item.id));
    for(const file of files)if(!ids.has(file.id))items.push({key:'s:'+file.id,id:file.id,name:file.name,size:file.size,thumb:''});
  }
  el('pc-remove').onclick=async()=>{
    const stored=items.filter(item=>selected.has(item.key)&&item.id);
    if(!stored.length||working)return;
    if(!confirm('Apagar do Autofy '+stored.length+' vídeo(s) guardado(s)? Os arquivos do seu computador não são apagados.'))return;
    working=true;controls();
    try{
      const result=await api('/remove',{ids:[...new Set(stored.map(item=>item.id))]});
      for(const item of stored){if(item.file){item.id=null;}else selected.delete(item.key);}
      items=items.filter(item=>item.file||!stored.includes(item));
      data.files=result.files||[];mergeStored(data.files);invalidate();grid();
    }catch(cause){error(cause.message);}finally{working=false;controls();}
  };
  // ---- Páginas ----
  function pageList(){
    const tag=p=>p.product?'<span class="product-tag product-'+esc(p.product)+'">'+esc(p.product.toUpperCase())+'</span> ':'<span class="product-tag product-none" title="Página sem ID salvo em Publicações ou fora do perfil no Miwra">—</span> ';
    el('pc-pages').innerHTML=shownPages().map(p=>'<label class="views-choice'+(p.postedToday?' posted-today':'')+'"><input type="checkbox" data-id="'+esc(p.id)+'"'+(p.postedToday?' data-blocked="1" disabled':pages.has(p.id)?' checked':'')+'><span>'+tag(p)+esc(p.name)+'<small>ID '+esc(p.id)+'</small>'+(p.postedToday?'<small class="posted-today-note">'+(p.postedToday.uncertain?'Envio de hoje com resultado incerto':'Já recebeu vídeo desta tela hoje')+(hour(p.postedToday.at)?' às '+hour(p.postedToday.at):'')+' · libera à meia-noite</small>':'')+'</span></label>').join('')||'<p class="hint">'+(data.pages.length?'Nenhuma Página de '+esc(product.toUpperCase())+' no token.':'Nenhuma Página retornada pela Meta.')+'</p>';
    const count=value=>data.pages.filter(p=>p.product===value).length,none=data.pages.filter(p=>!p.product).length;
    el('pc-product-state').textContent=data.productError||('Páginas do token: '+count('ed')+' de ED e '+count('wl')+' de WL'+(none?' · '+none+' sem produto (só aparecem em Todos)':'')+'.');
  }
  el('pc-pages').onchange=event=>{const id=event.target.dataset.id;if(!id||working)return;if(event.target.checked)pages.add(id);else pages.delete(id);error('');invalidate();};
  el('pc-all-pages').onchange=()=>{if(working||!loaded)return;pages=new Set(el('pc-all-pages').checked?freePages().map(p=>p.id):[]);pageList();invalidate();};
  el('pc-product').onchange=()=>{if(working||!loaded){el('pc-product').value=product;return;}product=el('pc-product').value;pages=new Set();pageList();invalidate();};
  el('pc-load').onclick=async()=>{
    if(working)return;working=true;controls();error('');el('pc-counts').textContent='Carregando as Páginas do token da Meta…';
    try{const result=await api('/load',{});data=result;loaded=true;pages=new Set();mergeStored(result.files||[]);pageList();grid();}
    catch(cause){error(/token|190/i.test(cause.message)?cause.message+' A Meta bloqueou o token desta conta: entre no Facebook dela, resolva o aviso que aparecer, gere um token novo e salve em Configurações. Ou troque de conta nas abas acima.':cause.message);el('pc-counts').textContent='Não foi possível carregar as Páginas.';}
    finally{working=false;controls();}
  };
  // ---- Prévia e textos ----
  let textsEdited=false,optionsFilled=false;
  for(const id of ['pc-caption-ed','pc-caption-wl'])el(id).addEventListener('input',()=>{textsEdited=true;});
  const daysView=()=>{const all=el('pc-comment-scope').value==='all';el('pc-comment-days-box').hidden=all;el('pc-comment-scope-help').hidden=all;};
  el('pc-comment-scope').addEventListener('change',daysView);daysView();
  function fillOptions(source){
    if(optionsFilled||!source||source.commentOn===undefined)return;optionsFilled=true;
    el('pc-comment-on').checked=source.commentOn===true;el('pc-comment-ed').value=source.comment||'';el('pc-comment-wl').value=source.commentWl||'';
    el('pc-comment-scope').value=source.commentScope==='all'?'all':'new';el('pc-comment-days').value=String(source.commentMaxDays||7);daysView();
  }
  el('pc-caption-reset').onclick=()=>{const saved=data.captionsFromSettings||{};el('pc-caption-ed').value=saved.caption||'';el('pc-caption-wl').value=saved.captionWl||'';textsEdited=true;};
  function invalidate(keepDraw=false){revision++;plan=null;if(!keepDraw)draw=null;el('pc-preview').hidden=true;controls();}
  function controls(){
    const busy=working||data.operation?.running;
    const chosen=items.filter(item=>selected.has(item.key));
    el('pc-load').disabled=busy;el('pc-folder').disabled=busy;el('pc-files').disabled=busy;
    el('pc-draw').disabled=busy||!loaded||!pages.size||!items.some(item=>!item.problem);
    el('pc-prepare').disabled=busy||!loaded||!chosen.length||!pages.size;
    // Diz o que falta para liberar o botão (em vez de só deixá-lo apagado).
    const missing=busy?'':!loaded?'Para liberar o botão: clique em Carregar Páginas.':!chosen.length?'Para liberar o botão: escolha e marque pelo menos um vídeo.':!pages.size?'Para liberar o botão: marque pelo menos uma Página.':'';
    if(!working)el('pc-upload-state').textContent=missing||(el('pc-upload-state').dataset.done||'');
    el('pc-start').disabled=busy||!plan;el('pc-stop').disabled=!data.operation?.running;
    el('pc-remove').disabled=busy||!chosen.some(item=>item.id);
    const selectable=items.filter(item=>!item.problem).slice(0,MAX_VIDEOS).length;
    el('pc-all-videos').disabled=busy||!items.length;el('pc-all-videos').checked=Boolean(selected.size&&selected.size===selectable);el('pc-all-videos').indeterminate=Boolean(selected.size&&selected.size<selectable);
    el('pc-all-pages').disabled=busy||!loaded||!freePages().length;el('pc-all-pages').checked=Boolean(pages.size&&pages.size===freePages().length);el('pc-all-pages').indeterminate=Boolean(pages.size&&pages.size<freePages().length);
    el('pc-product').disabled=busy||!loaded;
    el('pc-pages').querySelectorAll('input').forEach(input=>{input.disabled=busy||input.dataset.blocked==='1';});
    el('pc-counts').textContent=items.length+' vídeo(s) na tela · '+selected.size+' marcado(s) (máximo '+MAX_VIDEOS+')'+(loaded?' · '+pages.size+' de '+freePages().length+' Página(s) livres marcada(s)'+(shownPages().length-freePages().length?' · '+(shownPages().length-freePages().length)+' já receberam vídeo desta tela hoje':''):' · clique em Carregar Páginas');
  }
  el('pc-prepare').onclick=async()=>{
    if(working||!loaded)return;invalidate();const current=revision;working=true;controls();error('');
    try{
      const chosen=items.filter(item=>selected.has(item.key));
      // Já guardado no Autofy (mesma impressão digital): não precisa enviar de novo.
      for(const item of chosen)if(!item.id&&item.fp&&(data.files||[]).some(file=>file.id===item.fp))item.id=item.fp;
      const pending=chosen.filter(item=>!item.id);
      for(const [index,item] of pending.entries()){
        el('pc-upload-state').textContent='Enviando para o Autofy '+(index+1)+' de '+pending.length+': '+item.name+' ('+mb(item.size)+')…';
        item.state='uploading';paintCard(item);
        try{const saved=await upload(item);item.id=saved.id;}
        finally{item.state='';paintCard(item);}
        // O mesmo conteúdo já guardado (outro nome ou envio anterior): fica um cartão só.
        items=items.filter(other=>other===item||other.file||other.id!==item.id);
      }
      el('pc-upload-state').dataset.done=pending.length?pending.length+' vídeo(s) enviado(s) para o Autofy.':'';el('pc-upload-state').textContent=el('pc-upload-state').dataset.done;
      const fileIds=[...new Set(chosen.map(item=>item.id))];
      const byKey=new Map(items.map(item=>[item.key,item]));
      const result=draw?await api('/prepare',{pairs:draw.pairs.map(pair=>({fileId:byKey.get(pair.key)?.id,pageId:pair.pageId})),product})
        :await api('/prepare',{fileIds,pageIds:[...pages],product});
      if(current!==revision)return;plan=result;
      el('pc-preview').hidden=false;
      if(!textsEdited){el('pc-caption-ed').value=plan.caption||'';el('pc-caption-wl').value=plan.captionWl||'';}
      const count=value=>plan.pairs.filter(pair=>(pair.page.product==='wl'?'wl':'ed')===value).length;
      el('pc-caption-ed-count').textContent='· '+count('ed')+' Página(s) neste lote'+(plan.noProduct?' ('+plan.noProduct+' sem produto, tratadas como ED)':'');
      el('pc-caption-wl-count').textContent='· '+count('wl')+' Página(s) neste lote';
      el('pc-plan-count').textContent=plan.pairs.length+' postagem(ns) · '+({all:'Todos (ED + WL)',ed:'Somente ED',wl:'Somente WL'}[plan.product||'all'])+(plan.reusedFiles?' · '+plan.reusedFiles+' reutilização(ões) em Páginas diferentes':'');
      el('pc-plan-rows').innerHTML=plan.pairs.map((p,i)=>'<tr><td>'+(i+1)+'</td><td>'+esc(p.file.name)+'</td><td>'+(p.page.product?'<span class="product-tag product-'+esc(p.page.product)+'">'+esc(p.page.product.toUpperCase())+'</span> ':'')+esc(p.page.name)+'<small>ID '+esc(p.page.id)+'</small></td></tr>').join('');
      el('pc-skipped').textContent=(plan.skipped||[]).map(v=>v.page.name+': '+v.reason).join('\n');
      el('pc-preview').scrollIntoView({behavior:'smooth',block:'start'});
    }catch(cause){error(cause.message);}finally{working=false;grid();controls();}
  };
  el('pc-start').onclick=async()=>{
    if(!plan||working)return;
    const days=Number(el('pc-comment-days').value);
    if(el('pc-comment-scope').value==='new'&&(!Number.isInteger(days)||days<1||days>365)){error('Os dias de criação para comentar devem ser um número de 1 a 365.');return;}
    working=true;controls();error('');
    try{await api('/start',{planId:plan.id,caption:el('pc-caption-ed').value,captionWl:el('pc-caption-wl').value,commentOn:el('pc-comment-on').checked,comment:el('pc-comment-ed').value,commentWl:el('pc-comment-wl').value,commentScope:el('pc-comment-scope').value,commentMaxDays:days});textsEdited=false;invalidate();el('pc-upload-state').dataset.done='';progress(await api(''));}
    catch(cause){error(cause.message);}finally{working=false;controls();}
  };
  el('pc-stop').onclick=async()=>{try{await api('/stop',{});progress(await api(''));}catch(cause){error(cause.message);}};
  // ---- Contas e andamento ----
  function renderTabs(result){
    const all=result.accounts||[];el('pc-acct-bar').hidden=all.length<2;
    if(all.length&&!all.some(item=>item.account===account))account=all[0].account;
    const tabs=all.map(item=>'<button type="button" role="tab" data-account="'+esc(item.account)+'" aria-selected="'+(item.account===account)+'" class="acct-tab'+(item.running?' running':'')+(item.token?'':' no-token')+'"><b>'+esc(item.name)+'</b><small>'+esc((item.running?'Lote em andamento':item.token?'Token salvo':'Sem token da Meta')+(item.main?' · principal':''))+'</small></button>').join('');
    if(el('pc-tabs').dataset.sig!==tabs){el('pc-tabs').innerHTML=tabs;el('pc-tabs').dataset.sig=tabs;}
  }
  el('pc-tabs').addEventListener('click',event=>{
    const button=event.target.closest('button[data-account]');if(!button||button.dataset.account===account||working)return;
    account=button.dataset.account;try{localStorage.setItem('autofy-pc-conta',account);}catch{}
    loaded=false;data={files:[],pages:[]};pages=new Set();optionsFilled=false;textsEdited=false;
    el('pc-pages').innerHTML='<p class="hint">Clique em Carregar Páginas para ver as Páginas desta conta.</p>';el('pc-product-state').textContent='';
    invalidate();error('');el('pc-tabs').dataset.sig='';clearTimeout(timer);void poll();
  });
  function progress(result){
    renderTabs(result);
    data.operation=result.operation;data.captionsFromSettings=result.captionsFromSettings;if(result.sentByPage)data.sentByPage=result.sentByPage;fillOptions(result);
    if(loaded&&Array.isArray(result.pages)&&result.pages.length){const before=JSON.stringify(data.pages.map(p=>[p.id,p.postedToday?.at]));data.pages=result.pages;if(JSON.stringify(data.pages.map(p=>[p.id,p.postedToday?.at]))!==before){for(const p of data.pages)if(p.postedToday)pages.delete(p.id);pageList();}}
    const operation=result.operation||{};
    el('pc-status').textContent=operation.running?'Postando pela API…':({done:'Lote concluído.',error:'Lote interrompido por erro.',stopped:'Lote parado.'}[operation.phase]||'Nenhum lote em andamento.');
    if(operation.results?.length)el('pc-status').textContent+=' '+operation.results.filter(v=>['local_sent','local_posted'].includes(v.status)).length+' envio(s); '+operation.results.filter(v=>['failed','uncertain'].includes(v.status)).length+' ocorrência(s).';
    const text=operation.logs?.length?operation.logs.map(v=>v.at+'  '+v.message).join('\n'):'Sem atividade.';
    if(el('pc-log').textContent!==text){el('pc-log').textContent=text;el('pc-log').scrollTop=el('pc-log').scrollHeight;}
    controls();
  }
  async function poll(){
    const asked=account;
    try{const result=await api('');if(asked===account)progress(result);}catch(cause){error(cause.message);}
    // Só consulta com frequência enquanto a aba está aberta ou um lote roda.
    timer=setTimeout(poll,!el('screen-computador').hidden||data.operation?.running?2000:10000);
  }
  window.addEventListener('pagehide',()=>clearTimeout(timer));grid();void poll();
})();
