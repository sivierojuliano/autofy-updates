// Configurações → Proxy da API: um proxy por conta do Facebook para as chamadas à API da Meta.
// Cada dado num campo (tipo, endereço, porta, usuário, senha). A senha nunca volta para a tela: se ficar
// vazia numa conta que já tem senha salva, vai a máscara e o servidor mantém a senha salva.
(() => {
  const el = id => document.getElementById(id);
  if (!el('proxy-list')) return;
  const MASK = '••••••';
  let report = null;
  const saved = account => report?.accounts?.find(item => item.account === account) || null;
  const field = (row, name) => row.querySelector('[data-f="' + name + '"]');

  function card(item) {
    const p = item.parts || {}, on = Boolean(item.parts);
    return '<div class="proxy-row" data-account="' + esc(item.account) + '">'
      + '<div class="proxy-head"><strong>' + esc(item.name) + (item.main && !/principal/i.test(item.name) ? ' <span class="proxy-main">principal</span>' : '') + '</strong>'
      + '<span class="proxy-status ' + (on ? 'is-on' : 'is-off') + '">' + (on ? 'Com proxy' : 'Sem proxy') + '</span></div>'
      + '<div class="proxy-grid">'
      + '<label class="proxy-type">Tipo<select data-f="protocol"><option value="http"' + (p.protocol === 'socks5' ? '' : ' selected') + '>HTTP</option><option value="socks5"' + (p.protocol === 'socks5' ? ' selected' : '') + '>SOCKS5</option></select></label>'
      + '<label class="proxy-host">Endereço (host)<input data-f="host" type="text" autocomplete="off" spellcheck="false" maxlength="500" placeholder="ex.: gw.fornecedor.com ou 123.45.67.89" value="' + esc(p.host || '') + '"></label>'
      + '<label class="proxy-port">Porta<input data-f="port" type="text" inputmode="numeric" autocomplete="off" maxlength="5" placeholder="ex.: 8080" value="' + esc(p.port ? String(p.port) : '') + '"></label>'
      + '<label class="proxy-user">Usuário<input data-f="username" type="text" autocomplete="off" spellcheck="false" maxlength="255" placeholder="se o proxy pedir" value="' + esc(p.username || '') + '"></label>'
      + '<label class="proxy-pass">Senha<input data-f="password" type="password" autocomplete="new-password" maxlength="255" placeholder="' + (p.hasPassword ? 'senha salva (deixe vazio para manter)' : 'se o proxy pedir') + '"></label>'
      + '</div>'
      + '<div class="proxy-actions"><button type="button" class="proxy-test">Testar</button><button type="button" class="proxy-save primary">Salvar</button><button type="button" class="proxy-clear danger"' + (on ? '' : ' hidden') + '>Remover proxy</button></div>'
      + '<small class="proxy-note">' + (on ? 'As chamadas da API desta conta saem por ' + esc(p.host + ':' + p.port) + '.' : 'Sem proxy: a API desta conta usa a sua internet.') + '</small></div>';
  }
  function render() {
    const accounts = report?.accounts || [];
    const count = accounts.filter(item => item.parts).length;
    el('tag-proxy').textContent = count ? count + ' com proxy' : '';
    el('proxy-list').innerHTML = accounts.map(card).join('');
  }
  async function load() { report = await api('proxies'); render(); }
  const note = (row, text, kind) => { const small = row.querySelector('.proxy-note'); small.textContent = text; small.className = 'proxy-note' + (kind ? ' proxy-' + kind : ''); };

  // Colou a linha inteira do fornecedor no Endereço? Separa em tipo, host, porta, usuário e senha.
  function splitPasted(row) {
    const host = field(row, 'host'), text = host.value.trim();
    if (!/[:@]/.test(text)) return;
    let protocol = '', h = '', port = '', user = '', pass = '';
    const scheme = text.match(/^([a-z0-9]+):\/\//i);
    if (scheme) {
      protocol = /^socks/i.test(scheme[1]) ? 'socks5' : 'http';
      try { const url = new URL(text.replace(/^[a-z0-9]+:\/\//i, 'http://')); h = url.hostname.replace(/^\[|\]$/g, ''); port = url.port; user = decodeURIComponent(url.username); pass = decodeURIComponent(url.password); } catch { return; }
    } else if (text.includes('@')) {
      // usuario:senha@host:porta
      const [auth, addr] = [text.slice(0, text.lastIndexOf('@')), text.slice(text.lastIndexOf('@') + 1)];
      [h, port] = addr.split(':'); const cut = auth.indexOf(':'); user = cut < 0 ? auth : auth.slice(0, cut); pass = cut < 0 ? '' : auth.slice(cut + 1);
    } else {
      const parts = text.split(':');
      if (parts.length !== 2 && parts.length !== 4) return;
      [h, port, user = '', pass = ''] = parts;
    }
    host.value = h || ''; field(row, 'port').value = port || '';
    if (protocol) field(row, 'protocol').value = protocol;
    if (user || pass) { field(row, 'username').value = user; field(row, 'password').value = pass; }
    note(row, 'Separei os dados nos campos. Confira e clique em Testar ou Salvar.');
  }
  el('proxy-list').addEventListener('paste', event => { const row = event.target.closest('.proxy-row'); if (row && event.target.dataset.f === 'host') setTimeout(() => splitPasted(row)); });
  el('proxy-list').addEventListener('change', event => { const row = event.target.closest('.proxy-row'); if (row && event.target.dataset.f === 'host') splitPasted(row); });

  // Monta o texto que o servidor entende (protocolo://usuario:senha@host:porta).
  function build(row) {
    const protocol = field(row, 'protocol').value, host = field(row, 'host').value.trim(), port = field(row, 'port').value.trim();
    const user = field(row, 'username').value.trim(), typed = field(row, 'password').value;
    if (!host && !port && !user && !typed) return '';
    if (!host) throw new Error('Preencha o Endereço (host) do proxy.');
    if (!/^\d{1,5}$/.test(port) || Number(port) < 1 || Number(port) > 65535) throw new Error('Preencha a Porta com um número de 1 a 65535.');
    if (/[\s/@]/.test(host)) throw new Error('O Endereço é só o host, sem http://, espaços ou @. Ex.: gw.fornecedor.com');
    const pass = typed ? encodeURIComponent(typed) : saved(row.dataset.account)?.parts?.hasPassword && user ? MASK : '';
    if (pass && !user) throw new Error('Preencha o Usuário do proxy junto com a senha.');
    return protocol + '://' + (user ? encodeURIComponent(user) + ':' + pass + '@' : '') + host + ':' + port;
  }

  el('proxy-list').addEventListener('click', guarded(async event => {
    const button = event.target.closest('button'); if (!button) return;
    const row = button.closest('.proxy-row'), account = row.dataset.account;
    const clearing = button.classList.contains('proxy-clear');
    let proxy = '';
    if (!clearing) { try { proxy = build(row); } catch (error) { note(row, error.message, 'bad'); return; } }
    if (button.classList.contains('proxy-test')) {
      if (!proxy) { note(row, 'Preencha o Endereço e a Porta antes de testar.', 'bad'); return; }
      button.disabled = true; note(row, 'Testando o proxy (até 40 segundos)…');
      try {
        const result = await api('proxies/test', { account, proxy });
        if (result.ok) note(row, 'Funcionou: o IP de saída é ' + result.ip + ' e a Meta respondeu por ele (' + (result.ms / 1000).toFixed(1) + ' s). Clique em Salvar para usar.', 'ok');
        else note(row, result.error, 'bad');
      } catch (error) { note(row, error.message, 'bad'); }
      finally { button.disabled = false; }
      return;
    }
    if (!clearing && !proxy) { note(row, 'Preencha o Endereço e a Porta. Para tirar o proxy, use Remover proxy.', 'bad'); return; }
    if (clearing && !confirm('Remover o proxy desta conta? As chamadas da API dela voltam a sair pela sua internet.')) return;
    try {
      report = await api('proxies/save', { account, proxy: clearing ? '' : proxy }); render();
      note(el('proxy-list').querySelector('.proxy-row[data-account="' + CSS.escape(account) + '"]'), clearing ? 'Proxy removido. A API desta conta usa a sua internet.' : 'Salvo. As próximas chamadas da API desta conta saem por este proxy. Use Testar para conferir.', 'ok');
    } catch (error) { note(row, error.message, 'bad'); }
  }));
  el('proxy-setup').addEventListener('toggle', () => { if (el('proxy-setup').open) load().catch(error => el('proxy-state').textContent = error.message); });
  load().catch(() => {});
})();
