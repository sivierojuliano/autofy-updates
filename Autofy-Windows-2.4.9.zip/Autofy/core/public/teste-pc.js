// Aba TESTE · "Vídeos do computador com horários": escolhe vídeos e Páginas, quantos vídeos por Página e a
// faixa de horário; o servidor sorteia os vídeos (os menos usados primeiro, nunca repetindo na Página), um
// horário para cada um e posta na hora, com legendas do banco de legendas. Usa as rotas de /api/local.
(() => {
  const el = id => document.getElementById(id);
  if (!el('tpc')) return;
  const key = document.querySelector('meta[name=publisher-key]').content;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const clock = iso => new Date(iso).toLocaleTimeString('pt-BR', { timeZone: 'America/Sao_Paulo', hour: '2-digit', minute: '2-digit' });
  let account = 'main', pages = [], chosen = new Set(), plan = null, busy = false, started = false, timer = null, running = false;
  try { account = localStorage.getItem('autofy-tpc-conta') || 'main'; } catch {}
  for (const id of ['tpc-per', 'tpc-from', 'tpc-to', 'tpc-gap']) { try { const saved = localStorage.getItem('autofy-' + id); if (saved) el(id).value = saved; } catch {} }

  function error(message) { el('tpc-error').textContent = message || ''; el('tpc-error').hidden = !message; }
  async function call(path, body) {
    const response = await fetch('/api/local' + path + (body === undefined ? (path.includes('?') ? '&' : '?') + 'account=' + encodeURIComponent(account) : ''), {
      method: body === undefined ? 'GET' : 'POST', headers: { 'x-publisher-key': key, 'content-type': 'application/json' },
      ...(body === undefined ? {} : { body: JSON.stringify({ ...body, account }) }) });
    const data = await response.json().catch(() => ({}));
    if (response.status === 401) { location.assign('/login'); throw Error('Entre novamente no Autofy.'); }
    if (!response.ok) throw Error(data.error || 'Falha na comunicação.');
    return data;
  }
  const guard = fn => async (...args) => { if (busy) return; busy = true; buttons(); error(''); try { await fn(...args); } catch (cause) { error(cause.message); } finally { busy = false; buttons(); } };
  function buttons() {
    for (const id of ['tpc-folder', 'tpc-pick', 'tpc-clear', 'tpc-load', 'tpc-draw', 'tpc-start', 'tpc-redraw']) el(id).disabled = busy || running;
    el('tpc-stop').disabled = !running;
    el('tpc-account').disabled = busy || running;
  }
  function invalidate() { plan = null; el('tpc-preview').hidden = true; }

  // ---- 1. Vídeos ----
  async function files() {
    const result = await call('/files', {});
    el('tpc-files').textContent = result.files.length
      ? result.files.length + ' vídeo(s) guardado(s) no Autofy para sortear. Os vídeos ficam guardados por 3 dias; escolher de novo o mesmo vídeo não duplica.'
      : 'Nenhum vídeo guardado ainda. Clique em Escolher pasta ou Escolher vídeos.';
    return result.files;
  }
  async function upload(list) {
    const mp4 = [...list].filter(file => /\.mp4$/i.test(file.name));
    if (!mp4.length) throw Error('Nenhum arquivo MP4 nessa escolha.');
    let done = 0, failed = [];
    for (const file of mp4) {
      el('tpc-files').textContent = 'Guardando no Autofy: ' + (done + 1) + ' de ' + mp4.length + ' (' + file.name + ')…';
      const response = await fetch('/api/local/upload', { method: 'POST', headers: { 'x-publisher-key': key, 'content-type': 'application/octet-stream', 'x-file-name': encodeURIComponent(file.name) }, body: file });
      if (!response.ok) failed.push(file.name + ': ' + ((await response.json().catch(() => ({}))).error || 'falhou'));
      done++;
    }
    invalidate(); await files();
    if (failed.length) error(failed.length + ' vídeo(s) não foram guardados: ' + failed.slice(0, 3).join(' · '));
  }
  for (const id of ['tpc-folder', 'tpc-pick']) el(id).addEventListener('change', guard(async event => { const list = event.target.files; try { await upload(list); } finally { event.target.value = ''; } }));
  el('tpc-clear').addEventListener('click', guard(async () => {
    const list = (await call('/files', {})).files;
    if (!list.length) return;
    if (!confirm('Apagar os ' + list.length + ' vídeo(s) guardados no Autofy? Os arquivos no seu computador não são mexidos.')) return;
    await call('/remove', { ids: list.map(file => file.id) }).catch(cause => { if (!/Carregue/.test(cause.message)) throw cause; });
    invalidate(); await files();
  }));

  // ---- 2. Páginas ----
  const product = () => el('tpc-product').value;
  const shown = () => pages.filter(page => product() === 'all' || page.product === product());
  function pageList() {
    const list = shown();
    for (const id of [...chosen]) if (!list.some(page => page.id === id)) chosen.delete(id);
    el('tpc-pages').innerHTML = list.map(page => '<label><input type="checkbox" data-page="' + esc(page.id) + '"' + (chosen.has(page.id) ? ' checked' : '') + '><span>' + (page.product ? '<b>' + esc(page.product.toUpperCase()) + '</b> ' : '') + esc(page.name) + '</span></label>').join('');
    el('tpc-all').checked = list.length > 0 && list.every(page => chosen.has(page.id));
    el('tpc-pages-state').textContent = pages.length ? chosen.size + ' de ' + list.length + ' Página(s) marcada(s).' : 'Clique em Carregar Páginas.';
  }
  el('tpc-load').addEventListener('click', guard(async () => {
    el('tpc-pages-state').textContent = 'Carregando as Páginas desta conta na Meta…';
    const result = await call('/load', {});
    pages = result.pages || []; chosen = new Set(); invalidate(); pageList();
    if (result.productError) error(result.productError);
  }));
  el('tpc-pages').addEventListener('change', event => { const id = event.target.dataset?.page; if (!id) return; event.target.checked ? chosen.add(id) : chosen.delete(id); invalidate(); pageList(); });
  el('tpc-all').addEventListener('change', () => { chosen = el('tpc-all').checked ? new Set(shown().map(page => page.id)) : new Set(); invalidate(); pageList(); });
  el('tpc-product').addEventListener('change', () => { invalidate(); pageList(); });

  // ---- 3. Rodada ----
  for (const id of ['tpc-per', 'tpc-from', 'tpc-to', 'tpc-gap']) el(id).addEventListener('change', () => { invalidate(); try { localStorage.setItem('autofy-' + id, el(id).value); } catch {} });
  function bankNote() {
    const captions = window.autofyRitmo?.captions || [];
    const count = item => captions.filter(caption => caption.product === 'all' || caption.product === item).length;
    el('tpc-bank').textContent = captions.length
      ? 'Legendas: sorteadas do banco acima (' + count('ed') + ' para ED, ' + count('wl') + ' para WL). Sem legenda no banco para um produto, vale a descrição da aba Vídeos do computador. O comentário segue o que está salvo na aba Vídeos do computador.'
      : 'O banco de legendas acima está vazio: adicione legendas para cada vídeo sair com uma diferente. Sem elas, vale a descrição da aba Vídeos do computador.';
  }

  // ---- 4. Sortear e começar ----
  const draw = guard(async () => {
    if (!pages.length) throw Error('Clique em Carregar Páginas primeiro.');
    if (!chosen.size) throw Error('Marque pelo menos uma Página.');
    const result = await call('/prepare', { random: true, pageIds: [...chosen], perPage: Number(el('tpc-per').value), from: el('tpc-from').value, to: el('tpc-to').value, gapHours: Number(el('tpc-gap').value), product: product() });
    plan = result;
    const perPage = new Set(result.pairs.map(pair => pair.page.id)).size;
    el('tpc-summary').textContent = result.pairs.length + ' vídeo(s) para ' + perPage + ' Página(s), de ' + clock(result.first) + ' a ' + clock(result.last) + ' (horário de Brasília)' + (result.timing.gapHours > 0 ? ', com no mínimo ' + String(result.timing.gapHours).replace('.', ',') + ' h entre os vídeos da mesma Página.' : '.')
      + (result.short.length ? ' Faltaram vídeos novos para ' + result.short.length + ' Página(s): ' + result.short.slice(0, 4).join(', ') + (result.short.length > 4 ? '…' : '') + ' (já receberam todos os vídeos guardados).' : '')
      + ' A legenda de cada um é sorteada do banco na hora de postar.';
    el('tpc-rows').innerHTML = result.pairs.map(pair => '<tr><td>' + clock(pair.plannedAt) + '</td><td>' + esc(pair.page.name) + '</td><td>' + esc(pair.file.name) + '</td></tr>').join('');
    el('tpc-preview').hidden = false;
  });
  el('tpc-draw').addEventListener('click', draw);
  el('tpc-redraw').addEventListener('click', draw);
  el('tpc-start').addEventListener('click', guard(async () => {
    if (!plan) throw Error('Sorteie primeiro.');
    if (!confirm('Começar a rodada? ' + plan.pairs.length + ' vídeo(s) entre ' + clock(plan.first) + ' e ' + clock(plan.last) + '. Deixe o Autofy aberto e o computador ligado até o último horário.')) return;
    await call('/start', { planId: plan.id });
    invalidate(); await poll();
  }));
  el('tpc-stop').addEventListener('click', guard(async () => { await call('/stop', {}); await poll(); }));

  // ---- Conta e andamento ----
  el('tpc-account').addEventListener('change', () => {
    account = el('tpc-account').value; try { localStorage.setItem('autofy-tpc-conta', account); } catch {}
    pages = []; chosen = new Set(); invalidate(); pageList(); error(''); void poll();
  });
  async function poll() {
    clearTimeout(timer);
    try {
      const result = await call('');
      const accounts = result.accounts || [];
      el('tpc-account-row').hidden = accounts.length < 2;
      const options = accounts.map(item => '<option value="' + esc(item.account) + '"' + (item.account === account ? ' selected' : '') + '>' + esc(item.name + (item.main ? ' (principal)' : '') + (item.token ? '' : ' · sem token da Meta')) + '</option>').join('');
      if (el('tpc-account').dataset.sig !== options) { el('tpc-account').innerHTML = options; el('tpc-account').dataset.sig = options; }
      if (accounts.length && !accounts.some(item => item.account === account)) { account = accounts[0].account; el('tpc-account').value = account; }
      const operation = result.operation || {};
      running = operation.running === true;
      el('tpc-pill').textContent = running ? (operation.current?.waitingUntil ? 'Aguardando ' + clock(operation.current.waitingUntil) : 'Postando') : ({ done: 'Concluída', stopped: 'Parada', error: 'Erro' }[operation.phase] || 'Parado');
      el('tpc-log').textContent = (operation.logs || []).map(line => line.at + '  ' + line.message).join('\n') || 'Sem atividade.';
      buttons();
    } catch (cause) { error(cause.message); }
    timer = setTimeout(poll, location.hash === '#teste' && !document.hidden ? (running ? 3000 : 8000) : 20000);
  }
  // Começa quando a aba TESTE está habilitada (teste.js põe o banco em window.autofyRitmo).
  function begin() {
    if (started || !window.autofyRitmo?.enabled) return;
    started = true; bankNote(); buttons(); void files().catch(cause => error(cause.message)); void poll();
  }
  window.addEventListener('autofy-ritmo', () => { begin(); bankNote(); });
  window.addEventListener('hashchange', () => { if (location.hash === '#teste') { begin(); bankNote(); void poll(); } });
  begin();
})();
