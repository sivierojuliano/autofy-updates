import { sweepDownloads, sizeText } from './lib/download-cleanup.mjs';
import http from 'node:http';
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { join, resolve, sep, basename, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { PageMetaStatus } from './lib/page-status.mjs';
import { TopSchedule, criteriaFor, PERIODS as TOP_PERIODS } from './lib/top-schedule.mjs';
import { RemoteCommands } from './lib/remote-commands.mjs';
import { pageInScope } from './lib/storage.mjs';
import { Store, validateSettings, publicSettings, buildQueue, publicationContext, profilePages, blockedStates, pageProduct, productSetting, dayKey, MAIN_ACCOUNT, accountList, accountSettings } from './lib/storage.mjs';
import { AccountTokens } from './lib/accounts.mjs';
import { matchPageIds, pageLinks, matchFromMiwra } from './lib/page-ids.mjs';
import { Miwra } from './lib/miwra.mjs';
import { Facebook, uniqueVisible } from './lib/facebook.mjs';
import { profileMenuDiagnosis } from './lib/native-composer.mjs';
import { PageDeleter, readDeleted } from './lib/page-delete.mjs';
import { describeUrl } from './lib/diagnose.mjs';
import { Runner } from './lib/runner.mjs';
import { DownloadVerifier } from './lib/availability.mjs';
import { loadNetworkAccess, localAddresses, allowedPeer, allowedHosts } from './lib/network-access.mjs';
import { ViewsMonitor } from './lib/meta-views.mjs';
import { ViewsRepost } from './lib/views-repost.mjs';
import { MiwraAnalytics } from './lib/miwra-analytics.mjs';
import { DriveBatch } from './lib/drive-batch.mjs';
import { AutoRepost } from './lib/auto-repost.mjs';
import { ScheduledStart, apiBucket } from './lib/scheduled-start.mjs';
import { PlaysAnalytics, miwraIndex } from './lib/plays-analytics.mjs';
import { PageHealth } from './lib/page-health.mjs';
import { pageAges, scanTargets } from './lib/page-age.mjs';
import { CreatedScan } from './lib/page-created.mjs';
import { MetaPublisher } from './lib/meta-publish.mjs';
import { CountryRestrict } from './lib/country-restrict.mjs';
import { CommentReplies } from './lib/comment-replies.mjs';
import { PageAvatars } from './lib/page-avatars.mjs';
import { PageProfile } from './lib/page-profile.mjs';
import { Updater } from './lib/updater.mjs';

const root = fileURLToPath(new URL('.', import.meta.url));
async function envFile(directory) {
  try {
    const lines = (await readFile(join(directory,'.env'),'utf8')).split(/\r?\n/);
    return Object.fromEntries(lines.filter(line => line.trim() && !line.trim().startsWith('#') && line.includes('=')).map(line => { const i = line.indexOf('='); return [line.slice(0,i).trim(),line.slice(i+1).trim()]; }));
  } catch (error) { if (error.code === 'ENOENT') return {}; throw error; }
}
export async function createApp({ directory = root, makeMiwra = settings => new Miwra(settings), facebook, lan = false, addresses = localAddresses(), viewsOptions, repostOptions, driveOptions, autoOptions, analyticsOptions, publisherOptions, scheduleOptions, agesOptions, playsOptions, healthOptions, countryOptions, profileOptions, replyOptions, accountOptions = {}, updateOptions = {} } = {}) {
  // LAN mode is explicit and fails closed without a configured password.
  // Local mode remains loopback-only for existing installations.
  const access = lan ? await loadNetworkAccess(directory) : null;
  const store = await new Store(join(directory,'data','state.json')).load();
  const env = await envFile(directory);
  // Botão Atualizar: confere a versão publicada ao abrir e a cada 6 horas (desligado na pasta BETA).
  const updater = await new Updater({ installRoot: resolve(root, '..'), directory, baseUrl: process.env.AUTOFY_UPDATE_URL || env.AUTOFY_UPDATE_URL || undefined, busy: () => isBusy(), ...updateOptions }).load();
  if (updateOptions.auto !== false) updater.start();
  const port = Number(process.env.PORT || env.PORT || 3032);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT deve ser um número de 1 a 65535.');
  store.data.settings = validateSettings({
    baseUrl: env.MIWRA_BASE_URL || undefined, profile: env.MIWRA_PROFILE || '', cookie: env.MIWRA_COOKIE || '',
    ...store.data.settings
  });
  let recovered = false;
  for (const entry of store.data.history) {
    if (entry.status === 'sending') { entry.status = 'uncertain'; entry.error = 'Servidor encerrado durante uma tentativa. Confira a Página.'; recovered = true; }
    if (entry.status === 'submitted') { entry.status = 'sent_pending_sync'; entry.facebookConfirmed = false; entry.error = 'Postar foi acionado antes da interrupção. Sincronize somente o Miwra; não reenvie o vídeo.'; recovered = true; }
  }
  if (recovered) await store.save();
  const fb = facebook || new Facebook(join(directory,'facebook-session'), () => store.data.settings);
  // Exclusão de Páginas fora do Miwra pelo navegador da conta principal (pedido pela caixa de comandos).
  // Cada Página é excluída pelo Facebook da conta dona dela (principal ou extra), com a senha dessa conta.
  const passwordFor = id => !id || id === MAIN_ACCOUNT ? store.data.settings.facebookPassword || '' : store.data.settings.deletePasswords?.[id] || '';
  const deleter = new PageDeleter({ getFacebook: id => facebookFor(id), getPassword: passwordFor, folder: join(root, '..', 'comandos') });
  const verifier = new DownloadVerifier();
  const views = await new ViewsMonitor(directory, viewsOptions).load();
  // Postagem pela API usa o mesmo token da Conexão com a Meta (Configurações).
  const publisher = new MetaPublisher(() => views.config, publisherOptions);
  // Aba "Analytics": plays de todos os Reels das Páginas, coletados pela API da Meta (mesmo token) de
  // hora em hora. Só leitura. Nome, produto e Páginas ativas vêm do Miwra pelo ID do Facebook.
  // Tokens da Meta das contas extras de Facebook (a principal usa o da Conexão com a Meta).
  const tokens = await new AccountTokens(directory, accountOptions.tokens).load();
  const metaConfigs = () => [views.config, ...(store.data.settings.accounts || []).map(account => tokens.config(account.id))].filter(config => config?.token);
  const plays = await new PlaysAnalytics(directory, { getConfig: () => views.config, getConfigs: metaConfigs, miwraPages: async () => miwraIndex(await makeMiwra(store.data.settings).summary(), store.data.settings), ...playsOptions }).load();
  // Aba "Gestão de Páginas": todo dia, as Páginas ativas abaixo do limite de plays no período (Analytics
  // do Miwra). Nome repetido no Miwra: usa a coleta do Autofy por ID quando ela já cobre o período.
  const health = await new PageHealth(directory, { store, makeMiwra, own: async days => {
    const report = await plays.report('24h', days * 86400000);
    return report.ref && report.coveredMs >= days * 86400000 * 0.9 ? new Map(report.pages.map(page => [page.id, page.win.t])) : null;
  }, ...healthOptions }).load();
  const runner = new Runner({ store, facebook: fb, makeMiwra, verifier, publisher, directory: join(directory,'downloads') });
  // Ao abrir: apaga os vídeos que ficaram de rodadas antigas (o vídeo só serve até ser postado).
  sweepDownloads(join(directory,'downloads')).then(done => { if (done.count) console.log('Espaço liberado: ' + done.count + ' vídeo(s) antigo(s) apagado(s) (' + sizeText(done.bytes) + ').'); }).catch(() => {});
  // Contas extras de Facebook: cada uma com o seu Chrome (pasta de sessão própria), a sua rodada e o
  // seu token. Podem rodar ao mesmo tempo que a principal e entre si.
  const extra = new Map();
  const extraFor = id => {
    const account = (store.data.settings.accounts || []).find(item => item.id === id);
    if (!account) throw new Error('Conta do Facebook não encontrada. Atualize a tela.');
    if (!extra.has(id)) {
      const facebook = accountOptions.makeFacebook?.(id) || new Facebook(join(directory, 'facebook-chrome-' + id), () => accountSettings(store.data.settings, id));
      const accountPublisher = new MetaPublisher(() => tokens.config(id) || {}, publisherOptions);
      const accountRunner = new Runner({ store, facebook, makeMiwra, verifier, publisher: accountPublisher, directory: join(directory,'downloads'),
        account: { id, get name() { return (store.data.settings.accounts || []).find(item => item.id === id)?.name || id; } }, settings: () => accountSettings(store.data.settings, id) });
      extra.set(id, { facebook, publisher: accountPublisher, runner: accountRunner });
    }
    return extra.get(id);
  };
  const isMain = id => !id || id === MAIN_ACCOUNT;
  const runnerFor = id => isMain(id) ? runner : extraFor(id).runner;
  const facebookFor = id => isMain(id) ? fb : extraFor(id).facebook;
  const publisherFor = id => isMain(id) ? publisher : extraFor(id).publisher;
  const runners = () => [runner, ...[...extra.values()].map(item => item.runner)];
  // A conta principal divide o navegador com Melhores vídeos, Google Drive e Idade das Páginas.
  const mainBusy = () => runner.progress.running || repost.progress.running || drive.progress.running || ages.progress.running || deleter.progress.running;
  const accountBusy = id => isMain(id) ? mainBusy() : Boolean(extra.get(id)?.runner.progress.running || extra.get(id)?.repost?.progress.running || (deleter.progress.running && deleter.progress.accounts?.includes(id)));
  const accountsReport = () => accountList(store.data.settings).map(account => {
    const item = isMain(account.id) ? { runner, facebook: fb } : extra.get(account.id) || null, progress = item?.runner.progress;
    return { id: account.id, name: account.name, profile: account.profile, main: account.main, running: Boolean(progress?.running), phase: progress?.phase || 'idle',
      total: progress?.total || 0, done: progress?.results?.length || 0, browserOpen: Boolean(item?.facebook.isOpen ? item.facebook.isOpen() : item?.facebook.context),
      token: isMain(account.id) ? { tokenConfigured: Boolean(views.config.token), user: views.config.user?.name || '' } : tokens.info(account.id) };
  });
  // Tela "Países": restrição de país das Páginas, pela Graph API, com o token de cada conta.
  const metaSources = () => accountList(store.data.settings).filter(account => isMain(account.id) ? Boolean(views.config.token) : Boolean(tokens.config(account.id)))
    .map(account => ({ account: account.id, name: account.name, publisher: publisherFor(account.id) }));
  // Todas as contas do Facebook do Autofy, com ou sem token: as abas de Países e Dados das Páginas.
  const metaProfiles = () => accountList(store.data.settings).map(account => ({ account: account.id, name: account.name, main: Boolean(account.main),
    token: isMain(account.id) ? Boolean(views.config.token) : Boolean(tokens.config(account.id)) }));
  const miwraPagesIndex = async () => miwraIndex(await makeMiwra(store.data.settings).summary(), store.data.settings);
  // Gestão de Páginas: status de cada Página na Meta (fora do token, despublicada, erro), por conta com token.
  const metaStatus = await new PageMetaStatus(directory, { sources: metaSources }).load();
  const healthReport = () => { const report = health.report(); return { ...report, meta: { checkedAt: metaStatus.data.checkedAt, progress: metaStatus.report().progress, accounts: Object.fromEntries(Object.entries(metaStatus.data.accounts).map(([id, item]) => [id, { name: item.name, at: item.at, error: item.error || '', count: (item.ids || []).length }])) },
    current: report.current ? { ...report.current, rows: report.current.rows.map(row => ({ ...row, meta: metaStatus.statusOf(row.fbPageId, row.accountId) })) } : null }; };
  const countries = await new CountryRestrict(directory, { sources: metaSources, profiles: metaProfiles, miwraPages: miwraPagesIndex, ...countryOptions }).load();
  // Tela "Mensagens automáticas" (modo API): responde comentários com palavra-chave pela Graph API.
  const replies = await new CommentReplies(directory, { sources: metaSources, profiles: metaProfiles, miwraPages: miwraPagesIndex, ...replyOptions }).load();
  // Tela "Avatares": banco de imagens e foto de perfil sorteada para as Páginas, pela Graph API.
  const avatars = await new PageAvatars(directory, { sources: metaSources, profiles: metaProfiles, miwraPages: miwraPagesIndex }).load();
  // Fotos de capa: o mesmo fluxo dos avatares, com banco e registro próprios.
  const covers = await new PageAvatars(directory, { kind: 'cover', sources: metaSources, profiles: metaProfiles, miwraPages: miwraPagesIndex }).load();
  const imageBanks = { avatars, covers };
  // Tela "Dados das Páginas": banco de descrições e cidades, gravados pela Graph API numa fila com limite por dia.
  const profile = (await new PageProfile(directory, { sources: metaSources, profiles: metaProfiles, miwraPages: miwraPagesIndex, ...profileOptions }).load()).startTimer();
  const analytics = new MiwraAnalytics(() => store.data.settings, analyticsOptions);
  const repost = new ViewsRepost({ store, monitor: views, facebook: fb, directory: join(directory,'downloads'), analytics, publisher, makeMiwra, ...repostOptions });
  // Melhores vídeos de uma conta extra: as Páginas dela (divisão por ID ou perfil), o token dela (Páginas e
  // download pela Meta) e o Chrome dela. O "monitor" aqui é só o mínimo que o ViewsRepost usa.
  const accountMonitor = id => ({
    get config() { const saved = tokens.config(id); return saved ? { token: saved.token, apiVersion: saved.apiVersion, user: saved.user } : {}; },
    changing: false, authBlocked: false, retryAt: 0, now: () => Date.now(), cache: { pages: [] },
    makeClient: options => views.makeClient(options),
    cacheFile: { save: async () => {} }, schedule() {},
    async loadPages() {
      if (!this.config.token) throw new Error('cadastre o token da Meta desta conta em Configurações → Contas do Facebook.');
      const client = this.makeClient({ ...this.config }), list = [];
      for await (const batch of client.pages()) list.push(...batch);
      this.cache.pages = list;
    },
  });
  const repostFor = id => {
    if (isMain(id)) return repost;
    const item = extraFor(id);
    item.repost ||= new ViewsRepost({ store, monitor: accountMonitor(id), facebook: item.facebook, directory: join(directory,'downloads'), analytics, publisher: item.publisher, makeMiwra, ...repostOptions,
      account: { id, get name() { return (store.data.settings.accounts || []).find(account => account.id === id)?.name || id; } }, settingsFor: () => accountSettings(store.data.settings, id) });
    return item.repost;
  };
  const drive = new DriveBatch({ store, monitor: views, facebook: fb, directory: join(directory,'downloads'), makeMiwra, ...driveOptions });
  // Aba "Idade das Páginas": lê a data de criação de cada Página no Facebook, pelo navegador da automação.
  const ages = new CreatedScan({ store, facebook: fb, ...agesOptions });
  // IDs das Páginas da conta escolhida. Principal: pelo token da Conexão com a Meta (como antes).
  // Conta extra: pelo Analytics do Miwra (exato, pelo ID da Página no Miwra) e, para as que
  // faltarem, pelo token da Meta dela, se houver.
  const importingIds = new Set();
  // Divisão por ID: Páginas novas que o token da conta passou a enxergar entram sozinhas na lista
  // dela (as que já estão na lista de outra conta ficam de fora). Assim "Buscar IDs no Miwra" acha
  // as Páginas recém-passadas para a conta, sem precisar refazer a lista em Configurações.
  const growIdList = async account => {
    if (isMain(account) || !tokens.config(account)) return [];
    const accounts = store.data.settings.accounts || [], me = accounts.find(item => item.id === account);
    if (!me?.pageIds?.length) return [];
    const mine = new Set(me.pageIds.map(String)), others = new Set(accounts.filter(item => item.id !== account).flatMap(item => item.pageIds || []).map(String));
    const fresh = (await tokens.pageIds(account)).map(page => String(page.id)).filter(id => !mine.has(id) && !others.has(id));
    if (!fresh.length) return [];
    const previous = store.data.settings;
    store.data.settings = validateSettings({ accounts: accounts.map(item => item.id === account ? { ...item, pageIds: [...me.pageIds, ...fresh] } : item) }, previous);
    try { await store.save(); } catch (error) { store.data.settings = previous; throw error; }
    return fresh;
  };
  const importPageIds = async account => {
    const grown = await growIdList(account).catch(() => []);
    const settings = structuredClone(accountSettings(store.data.settings, account));
    if (!settings.profile || !settings.cookie) throw new Error('Configure e salve o perfil e cookie do Miwra primeiro.');
    // Conta com divisão por ID: a busca olha também as Páginas ainda sem ID (do perfil dela e da
    // principal) e só guarda as que caírem nos IDs da lista.
    const listed = new Set(isMain(account) ? [] : (store.data.settings.accounts || []).find(item => item.id === account)?.pageIds || []);
    if (listed.size) settings.importing = true;
    const summary = await makeMiwra(settings).summary();
    let report;
    if (isMain(account)) {
      const metaPages = await views.listPageIds();
      // Para nomes repetidos: liga cada ID do Facebook à Página do Miwra pelos vídeos já publicados
      // (Analytics dos últimos 60 dias). Se o Analytics falhar, a busca segue sem esse apoio.
      let links = new Map();
      try { links = pageLinks(summary,(await analytics.loaded(dayKey(new Date(Date.now()-60*86400000)),false)).rows); } catch {}
      report = matchPageIds(summary,settings,metaPages,links);
    } else {
      // Páginas conectadas no Miwra: pela tela de conexões (rápida); se ela falhar, pelo painel do Analytics.
      let mine;
      try { mine = await health.connectedPages(); }
      catch { mine = (await health.panel(24)).minhasPaginas; }
      report = matchFromMiwra(summary, settings, mine);
      if (report.unresolved && tokens.config(account)) {
        const viaMiwra = new Map(report.rows.filter(row => row.status === 'added').map(row => [row.id, row]));
        const meta = matchPageIds(summary, { ...settings, mappings: report.mappings }, await tokens.pageIds(account));
        const rows = meta.rows.map(row => viaMiwra.get(row.id) || row);
        report = { ...meta, source: 'miwra+meta', rows, added: rows.filter(r => r.status === 'added').length, kept: rows.filter(r => r.status === 'kept').length, unresolved: rows.filter(r => !r.facebookPageId).length };
      }
    }
    const previous = store.data.settings;
    let mappings = report.mappings;
    if (!isMain(account)) {
      // A busca da conta extra pode correr junto com outras operações: grava só os IDs das Páginas
      // dela sobre os IDs atuais, sem desfazer o que foi salvo enquanto a busca corria.
      const own = new Set(profilePages(summary, settings, true).map(page => String(page.id)));
      mappings = { ...(previous.mappings || {}) };
      for (const [id, value] of Object.entries(report.mappings || {})) if (own.has(String(id)) && value && !mappings[id] && (!listed.size || listed.has(String(value)))) mappings[id] = value;
      if (listed.size) {
        // O resultado mostra só as Páginas da lista; IDs da lista sem Página no Miwra aparecem para conferir.
        const rows = report.rows.filter(row => listed.has(String(row.facebookPageId)));
        const found = new Set(rows.map(row => String(row.facebookPageId)));
        const missing = [...listed].filter(id => !found.has(id) && !Object.values(mappings).includes(id));
        rows.push(...missing.map(id => ({ id: '', name: 'ID ' + id, facebookPageId: id, status: 'missing', message: 'Está na lista desta conta, mas nenhuma Página do Miwra ficou ligada a ele (nome diferente ou Página não conectada no Miwra). Ligue o ID à mão na Página certa.' })));
        report = { ...report, rows, metaCount: listed.size, added: rows.filter(r => r.status === 'added').length, kept: rows.filter(r => r.status === 'kept').length, unresolved: missing.length };
      }
    }
    store.data.settings = validateSettings({mappings},previous);
    try { await store.save(); } catch (error) { store.data.settings = previous; throw error; }
    const {mappings:_ignored,...result} = report;
    return {...result,listAdded:grown.length,settings:{...publicSettings(store.data.settings),networkMode:lan}};
  };
  // Envio de uma conta extra (para conferir/sincronizar sem esperar a conta principal).
  const extraOwner = id => {
    const item = store.data.history.find(row => row.id === id);
    return item && !['drive','views'].includes(item.source) && item.account && (store.data.settings.accounts || []).some(account => account.id === item.account) ? item.account : null;
  };
  let activeRunner = runner;
  // isBusy é definido mais abaixo; só é chamado depois que o servidor está de pé.
  const auto = await new AutoRepost({ directory, monitor: views, repost, busy: () => isBusy(), onStart: () => { activeRunner = repost; }, ...autoOptions }).load();
  // Início programado das rodadas de Publicações (até 3 horários, cada um com o seu slot, uma vez
  // cada). Na hora, aplica o slot, o produto e o navegador guardados e inicia a mesma rodada do
  // botão "Publicar rodada".
  // Cada programação é de uma conta de Facebook; contas diferentes podem rodar ao mesmo tempo.
  // Programação diária dos Melhores vídeos (por conta): top 1º/2º/3º de cada Página, no horário marcado.
  // Top N de cada Página de uma conta (programação diária e caixa de comandos).
  const fireTop = async row => {
      const main = isMain(row.account), target = repostFor(row.account);
      if (main) changing = true;
      try {
        const plan = await target.prepareFromAnalytics({ ...criteriaFor(row.period), force: true });
        const keys = plan.entries.filter(video => (video.rank || 1) === row.rank && !video.repostBlocked).map(video => video.key);
        if (!keys.length) return { started: 0, message: 'nenhum vídeo ' + row.rank + 'º para repostar (nenhum com 1.500 plays ou mais no período, ou todos já repostados hoje).' };
        if (main && row.method !== 'api') await chooseBrowser(row.method);
        target.start({ mode: 'publish', planId: plan.id, keys, method: row.method === 'api' ? 'api' : 'chrome' });
        if (main) activeRunner = repost;
        return { started: keys.length, pages: new Set(keys.map(key => key.split(':')[0])).size };
      } finally { if (main) changing = false; }
  };
  const topSchedule = await new TopSchedule(directory, { accounts: () => accountList(store.data.settings),
    busy: account => isMain(account) ? changing || mainBusy() : accountBusy(account), fire: fireTop }).load();
  const scheduled = await new ScheduledStart({ store, busy: job => job ? changing || accountBusy(job.account) : isBusy(), fire: async job => {
    const account = job.account || MAIN_ACCOUNT, target = runnerFor(account), viaApi = job.browser === 'api';
    const previous = store.data.settings;
    // Programação da tela "Postar por API": publica pela Graph API, sem abrir navegador (o navegador salvo não muda).
    store.data.settings = validateSettings({ postingSlot: job.postingSlot, product: job.product, ...(isMain(account) && !viaApi ? { browser: job.browser } : {}) }, previous);
    try { await store.save(); } catch (error) { store.data.settings = previous; throw error; }
    target.start('publish', viaApi ? { method: 'api' } : {}); if (isMain(account)) activeRunner = runner;
    target.log('Rodada do Slot ' + job.postingSlot + (viaApi ? ' pela API da Meta' : '') + ' iniciada pelo início programado (' + job.time + ').');
  }, ...scheduleOptions }).load();
  // Caixa de comandos (pasta "comandos" ao lado do pacote): o Claude opera o Autofy à distância
  // escrevendo pedidos nela. Mesmas travas dos botões do painel. Ver lib/remote-commands.mjs.
  const findAccount = name => {
    const list = accountList(store.data.settings), wanted = String(name ?? 'principal').trim().toLocaleLowerCase('pt-BR');
    const found = ['', 'principal', 'main'].includes(wanted) ? list.find(item => item.main) : list.find(item => item.name.toLocaleLowerCase('pt-BR') === wanted) || list.find(item => item.name.toLocaleLowerCase('pt-BR').includes(wanted));
    if (!found) throw new Error('conta não encontrada: ' + name + '. Contas: ' + list.map(item => item.main ? 'principal (' + item.name + ')' : item.name).join(', ') + '.');
    return found;
  };
  // Motivos de exclusão da rodada (linhas "… fora da rodada — motivo"), agrupados, para ler à distância.
  const excludedOf = logs => {
    const groups = new Map();
    for (const line of logs || []) {
      const found = String(line.message).match(/^(.*?) · Slot \d+: fora da rodada — (.*)$/) || String(line.message).match(/^(.*?): fora da rodada — (.*)$/);
      if (!found) continue;
      const reason = found[2].replace(/\(ID \d+\)/, '').trim();
      if (!groups.has(reason)) groups.set(reason, []);
      groups.get(reason).push(found[1]);
    }
    return [...groups].map(([motivo, paginas]) => ({ motivo, quantidade: paginas.length, paginas: paginas.slice(0, 40) })).sort((a, b) => b.quantidade - a.quantidade);
  };
  const progressOf = progress => ({ rodando: Boolean(progress?.running), fase: progress?.phase || 'idle', feitos: progress?.results?.length || 0, total: progress?.total || 0, erro: progress?.error || '',
    foraDaRodada: excludedOf(progress?.logs), ultimosRegistros: (progress?.logs || []).slice(-15).map(line => line.at + '  ' + line.message) });
  // Registro completo de cada rodada que termina (Publicações e Melhores vídeos), em comandos/registros/.
  const savedRuns = new WeakMap();
  const saveRunLogs = async () => {
    const jobs = accountList(store.data.settings).flatMap(account => [[account, 'publicacoes', runnerFor(account.id)], [account, 'melhores', account.main ? repost : extra.get(account.id)?.repost]]).filter(([, , job]) => job);
    for (const [account, kind, job] of jobs) {
      const progress = job.progress;
      if (progress.running || !progress.logs?.length || savedRuns.get(job) === progress) continue;
      savedRuns.set(job, progress);
      const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
      const name = (account.main ? 'principal' : account.name).normalize('NFD').replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-|-$/g, '').toLowerCase();
      try {
        await mkdir(join(root, '..', 'comandos', 'registros'), { recursive: true });
        await writeFile(join(root, '..', 'comandos', 'registros', stamp + '-' + name + '-' + kind + '.txt'), progress.logs.map(line => line.at + '  ' + line.message).join('\n') + '\n');
      } catch {}
    }
  };
  // Levantamento de Páginas com sinais de suspensão (caixa de comandos): refaz a Gestão de Páginas (para
  // ligar cada Página à conta dela), confere o status na Meta e grava o relatório em comandos/relatorios/.
  let survey = { running: false, step: '', startedAt: null, finishedAt: null, file: '', error: '' };
  const surveyReport = async () => {
    const report = healthReport(), rows = report.current?.rows || [];
    const names = new Map(accountList(store.data.settings).map(account => [account.id, account.main ? 'principal (' + account.name + ')' : account.name]));
    const label = { ok: 'Ativa na Meta', fora: 'Fora do token', despublicada: 'Despublicada', erro: 'Erro na Meta' };
    const lines = rows.map(row => ({ pagina: row.name, nomeNoFacebook: row.facebookName, conta: names.get(row.accountId) || row.account || '', produto: (row.product || '').toUpperCase(),
      idFacebook: row.fbPageId, idMiwra: row.id, statusMeta: row.meta ? label[row.meta.status] || row.meta.status : 'Não conferida', detalheMeta: row.meta?.detail || '',
      plays: row.plays, plays24h: row.plays24, idadeDias: row.ageDays, situacaoMiwra: row.status, observacaoMiwra: row.note || '' }));
    const suspicious = line => ['Fora do token', 'Despublicada', 'Erro na Meta'].includes(line.statusMeta) || line.situacaoMiwra === 'erro';
    const count = test => lines.filter(test).length;
    const summary = { paginasAtivasNoMiwra: lines.length, ativasNaMeta: count(l => l.statusMeta === 'Ativa na Meta'), foraDoToken: count(l => l.statusMeta === 'Fora do token'),
      despublicadas: count(l => l.statusMeta === 'Despublicada'), erroNaMeta: count(l => l.statusMeta === 'Erro na Meta'), erroDeColetaNoMiwra: count(l => l.situacaoMiwra === 'erro'),
      naoConferidas: count(l => l.statusMeta === 'Não conferida'), comSinalDeSuspensao: count(suspicious), abaixoDoLimiteDePlays: count(l => l.situacaoMiwra === 'fraca') };
    const stamp = new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-'), folder = join(root, '..', 'comandos', 'relatorios');
    await mkdir(folder, { recursive: true });
    const base = join(folder, stamp + '-levantamento-suspensas');
    await writeFile(base + '.json', JSON.stringify({ geradoEm: new Date().toISOString(), metaConferidaEm: metaStatus.data.checkedAt, contasMeta: report.meta.accounts, resumo: summary,
      comSinalDeSuspensao: lines.filter(suspicious), todas: lines }, null, 2));
    const cell = value => { const text = String(value ?? ''); return /[";\n\r]/.test(text) ? '"' + text.replaceAll('"', '""') + '"' : text; };
    const head = Object.keys(lines[0] || { pagina: '' });
    await writeFile(base + '.csv', '﻿' + [head, ...lines.map(line => head.map(key => line[key]))].map(row => row.map(cell).join(';')).join('\r\n') + '\r\n');
    return { file: base + '.json', summary };
  };
  const runSurvey = async () => {
    survey = { running: true, step: 'Gestão de Páginas (Analytics do Miwra)', startedAt: new Date().toISOString(), finishedAt: null, file: '', error: '' };
    try {
      await health.check('manual');
      survey.step = 'Status na Meta';
      metaStatus.start(); await metaStatus.task;
      if (metaStatus.progress.error) throw new Error('conferência na Meta parou: ' + metaStatus.progress.error);
      survey.step = 'Gravando o relatório';
      const result = await surveyReport();
      Object.assign(survey, { file: result.file, resumo: result.summary });
    } catch (error) { survey.error = String(error.message || error).slice(0, 300); }
    finally { survey.running = false; survey.finishedAt = new Date().toISOString(); survey.step = ''; }
  };
  const anyJobRunning = () => changing || runners().some(job => job.progress.running) || repost.progress.running || [...extra.values()].some(item => item.repost?.progress.running) || drive.progress.running || ages.progress.running || deleter.progress.running;
  // Páginas protegidas (comandos/protegidas.json): toda Página recolocada entra nela, e a retirada não
  // mexe nelas (a não ser com "ignorarProtegidas": true). Protege contra a rotina tirar de novo.
  const protectedFile = join(root, '..', 'comandos', 'dados', 'protegidas.json');
  const readProtected = async () => { try { const data = JSON.parse(await readFile(protectedFile, 'utf8')); return Array.isArray(data?.ids) ? data.ids.map(id => String(id).toLowerCase()) : []; } catch { return []; } };
  const changeActive = async (action, ids, confirm, { nomes, ignorarProtegidas = false } = {}) => {
    let list = [...new Set((Array.isArray(ids) ? ids : String(ids || '').split(/[\s,;]+/)).map(value => String(value).trim().toLowerCase()).filter(Boolean))];
    const askedNames = [...new Set((Array.isArray(nomes) ? nomes : []).map(value => String(value).normalize('NFC').trim().replace(/\s+/g, ' ')).filter(Boolean))];
    if (!list.length && !askedNames.length) throw new Error('informe os códigos das Páginas no Miwra (ex.: ["ed953"]) ou os nomes (ex.: "nomes": ["Alice Peterson"]).');
    if (list.length > 300) throw new Error('muitas Páginas de uma vez (máximo 300).');
    if (confirm === true && anyJobRunning()) throw new Error('há rodada, lote ou outra operação em andamento. Espere terminar: gravar o estado agora poderia desfazer marcações de slot.');
    const miwra = makeMiwra(store.data.settings), summary = await miwra.summary({ fresh: true }), estado = summary.estado;
    if (!estado || !Array.isArray(estado.paginaIds) || !estado.slots) throw new Error('o estado do Miwra veio fora do formato esperado. Nada foi feito.');
    const names = new Map((summary.paginas || []).map(page => [String(page.id).toLowerCase(), String(page.nome || page.name || page.id)]));
    // Nomes → códigos: comparação exata, sem acento ou caixa importarem só na caixa (como no Facebook). Nome
    // repetido no Miwra não é resolvido (fica em nomesAmbiguos) e nome sem Página fica em nomesNaoEncontrados.
    const key = value => String(value).normalize('NFC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('pt-BR');
    const byName = new Map();
    for (const [id, name] of names) { const k = key(name); byName.set(k, [...(byName.get(k) || []), id]); }
    const ambiguous = [], notFound = [];
    for (const name of askedNames) { const found = byName.get(key(name)) || []; if (found.length === 1) list.push(found[0]); else (found.length ? ambiguous : notFound).push(name); }
    list = [...new Set(list)];
    const protectedIds = action === 'retirar' && !ignorarProtegidas ? new Set(await readProtected()) : new Set();
    const keptProtected = list.filter(id => protectedIds.has(id)); list = list.filter(id => !protectedIds.has(id));
    const active = estado.paginaIds.map(String), activeSet = new Set(active.map(id => id.toLowerCase()));
    const unknown = list.filter(id => !names.has(id));
    const targets = list.filter(id => names.has(id) && (action === 'retirar' ? activeSet.has(id) : !activeSet.has(id)));
    const skipped = list.filter(id => names.has(id) && !targets.includes(id));
    const page = id => ({ id, nome: names.get(id) || id });
    const after = action === 'retirar' ? active.length - targets.length : active.length + targets.length;
    const preview = { [action === 'retirar' ? 'vaoSair' : 'vaoVoltar']: targets.map(page), [action === 'retirar' ? 'jaNaoEstavamAtivas' : 'jaEstavamAtivas']: skipped.map(page), naoExistemNoMiwra: unknown, nomesNaoEncontrados: notFound, nomesAmbiguos: ambiguous, protegidasMantidas: keptProtected.map(page), ativasAntes: active.length, ativasDepois: after };
    if (confirm !== true) return { mensagem: 'Prévia (nada foi gravado): ' + targets.length + ' Página(s) ' + (action === 'retirar' ? 'saem' : 'voltam') + '. Mande de novo com "confirmar": true para aplicar.', ...preview };
    if (!targets.length) return { mensagem: 'Nada a fazer.', ...preview };
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-'), folder = join(root, '..', 'comandos', 'relatorios');
    await mkdir(folder, { recursive: true });
    await writeFile(join(folder, stamp + '-backup-paginas-ativas.json'), JSON.stringify({ antesDe: action, em: new Date().toISOString(), paginaIds: active }, null, 2));
    changing = true;
    let check;
    try {
      const next = { ...estado, paginaIds: action === 'retirar' ? active.filter(id => !targets.includes(id.toLowerCase())) : [...active, ...targets], updatedAt: new Date().toISOString() };
      await miwra.putEstado(next);
      check = (await miwra.summary({ fresh: true })).estado;
    } finally { changing = false; }
    const nowActive = new Set((check?.paginaIds || []).map(id => String(id).toLowerCase()));
    if (action === 'recolocar') { const current = await readProtected(); await mkdir(dirname(protectedFile), { recursive: true }).catch(() => {}); await writeFile(protectedFile, JSON.stringify({ ids: [...new Set([...current, ...targets])], nota: 'Páginas recolocadas: a retirada automática não mexe nelas.' }, null, 2)).catch(() => {}); }
    const failed = targets.filter(id => action === 'retirar' ? nowActive.has(id) : !nowActive.has(id));
    const slotsOk = Object.keys(check?.slots || {}).length >= Object.keys(estado.slots).length;
    return { mensagem: (failed.length ? 'Atenção: ' + failed.length + ' Página(s) não mudaram no Miwra. ' : '') + (targets.length - failed.length) + ' Página(s) ' + (action === 'retirar' ? 'retiradas' : 'recolocadas') + '. Ativas agora: ' + nowActive.size + '. Slots ' + (slotsOk ? 'preservados' : 'DIFERENTES do antes — confira o painel') + '. Backup da lista anterior em comandos/relatorios/' + stamp + '-backup-paginas-ativas.json.',
      ...preview, ativasDepois: nowActive.size, naoMudaram: failed.map(page), slotsPreservados: slotsOk };
  };
  // Exclusão de Páginas: as Páginas FORA das ativas do Miwra (todas, ou só os códigos pedidos), cada uma
  // com o motivo de ficar de fora do lote quando não pode ser excluída.
  const commandsFolder = join(root, '..', 'comandos');
  const deletionPlan = async (only = null) => {
    const summary = await makeMiwra(store.data.settings).summary({ fresh: true }), estado = summary.estado;
    if (!estado || !Array.isArray(estado.paginaIds)) throw new Error('o estado do Miwra veio fora do formato esperado. Nada foi feito.');
    const names = new Map((summary.paginas || []).map(page => [String(page.id).toLowerCase(), String(page.nome || page.name || page.id)]));
    const key = value => String(value).normalize('NFC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('pt-BR');
    const nameCount = new Map(); for (const name of names.values()) nameCount.set(key(name), (nameCount.get(key(name)) || 0) + 1);
    const active = new Set(estado.paginaIds.map(id => String(id).toLowerCase())), protectedIds = new Set(await readProtected()), deleted = await readDeleted(commandsFolder);
    const mappings = Object.fromEntries(Object.entries(store.data.settings.mappings || {}).map(([id, value]) => [String(id).toLowerCase(), String(value)]));
    const ids = only ? only.map(id => String(id).toLowerCase()) : [...names.keys()].filter(id => !active.has(id));
    // Conta dona: a extra que enxerga a Página (perfil ou lista de IDs); senão, a principal.
    const settings = store.data.settings, accounts = accountList(settings), byId = new Map((summary.paginas || []).map(page => [String(page.id).toLowerCase(), page]));
    const ownerOf = id => { const page = byId.get(id); if (!page) return accounts[0]; for (const account of accounts) if (!account.main) { try { if (pageInScope(page, accountSettings(settings, account.id))) return account; } catch {} } return accounts[0]; };
    const pages = ids.map(id => {
      const nome = names.get(id) || id, done = deleted[id];
      const motivo = !names.has(id) ? 'não existe no Miwra' : active.has(id) ? 'ativa no Miwra (só Páginas fora do quadro)' : done ? 'já excluída (' + (done.como || '') + (done.em ? ', ' + new Date(done.em).toLocaleDateString('pt-BR') : '') + ')' : protectedIds.has(id) ? 'protegida' : nameCount.get(key(nome)) > 1 ? 'nome repetido no Miwra' : !mappings[id] ? 'sem ID do Facebook salvo (Buscar IDs)' : '';
      const owner = ownerOf(id);
      return { id, nome, facebookId: mappings[id] || '', conta: owner.id, contaNome: owner.name, senhaDaConta: Boolean(passwordFor(owner.id)), elegivel: !motivo, motivo, excluida: Boolean(done) };
    }).sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
    return { pages, ativas: active.size, senhaSalva: Boolean(store.data.settings.facebookPassword), contas: accounts.map(account => ({ id: account.id, nome: account.name, principal: account.main, senhaSalva: Boolean(passwordFor(account.id)) })) };
  };
  // locked: chamado de dentro da trava das rotas POST (lá "changing" já é a própria trava).
  const startDeletion = (entries, { locked = false } = {}) => {
    if (deleter.progress.running) throw new Error('a exclusão de Páginas já está rodando.');
    const owners = [...new Set(entries.map(item => item.conta || MAIN_ACCOUNT))];
    for (const id of owners) {
      if (isMain(id) ? (!locked && changing) || mainBusy() : accountBusy(id)) throw new Error('a conta ' + (entries.find(item => item.conta === id)?.contaNome || id) + ' está ocupada (rodada, lote ou outra operação). Espere terminar.');
      if (!passwordFor(id)) throw new Error('falta a senha do Facebook da conta ' + (entries.find(item => item.conta === id)?.contaNome || id) + ' (salve na aba Excluir Páginas).');
    }
    deleter.start(entries.map(item => ({ pageId: item.id, pageName: item.nome, facebookPageId: item.facebookId, accountId: item.conta || MAIN_ACCOUNT, accountName: item.contaNome || '' })));
  };
  const deletionReport = () => ({ running: deleter.progress.running, accounts: deleter.progress.accounts || [], phase: deleter.progress.phase, total: deleter.progress.total, done: deleter.progress.results.length, deleted: deleter.progress.results.filter(item => item.status === 'excluida').length, current: deleter.progress.current || '', error: deleter.progress.error, results: deleter.progress.results, logs: deleter.progress.logs.slice(-80), report: deleter.progress.relatorio || '' });
  const remote = await new RemoteCommands(join(root, '..', 'comandos'), {
    status: () => (void saveRunLogs(), {
      contas: accountList(store.data.settings).map(account => ({ conta: account.main ? 'principal' : account.name, nome: account.name,
        publicacoes: progressOf(runnerFor(account.id).progress), melhoresVideos: progressOf((account.main ? repost : extra.get(account.id)?.repost)?.progress),
        chromeAberto: (browser => Boolean(browser.isOpen ? browser.isOpen() : browser.context))(account.main ? fb : facebookFor(account.id)),
        programacaoSlots: scheduled.report(account.id).rows.filter(row => row.pending).map(row => ({ slot: row.pending.postingSlot, quando: row.pending.label })),
        programacaoApi: scheduled.report(apiBucket(account.id)).rows.filter(row => row.pending).map(row => ({ slot: row.pending.postingSlot, quando: row.pending.label })),
        programacaoMelhores: topSchedule.report(account.id).rows.map(row => ({ horario: row.time, posicao: row.rank, ligado: row.enabled, proxima: row.next, ultimo: row.last?.message || '' })) })),
      levantamentoSuspensas: { ...survey, metaProgresso: metaStatus.progress.running ? metaStatus.progress.done + '/' + (metaStatus.progress.total || '?') : '' },
      slotEscolhido: store.data.settings.postingSlot, produto: store.data.settings.product || 'all', driveRodando: drive.progress.running, ocupadoPrincipal: changing || mainBusy(),
      exclusaoPaginas: { rodando: deleter.progress.running, fase: deleter.progress.phase, feitos: deleter.progress.results.length, total: deleter.progress.total, atual: deleter.progress.current || '', excluidas: deleter.progress.results.filter(item => item.status === 'excluida').length, erro: deleter.progress.error, relatorio: deleter.progress.relatorio || '', ultimosRegistros: deleter.progress.logs.slice(-15) } }),
    handlers: {
      status: async () => ({ mensagem: 'Estado atualizado em status.json.' }),
      publicar: async ({ conta, slot, produto, metodo = 'chrome', teste = false }) => {
        const account = findAccount(conta), id = account.id;
        if (accountBusy(id) || (isMain(id) && changing)) throw new Error('a conta ' + account.name + ' está ocupada (rodada ou lote em andamento).');
        if (!['chrome', 'api'].includes(metodo)) throw new Error('metodo deve ser chrome ou api.');
        const previous = store.data.settings;
        store.data.settings = validateSettings({ ...(slot !== undefined ? { postingSlot: Number(slot) } : {}), ...(produto !== undefined ? { product: produto } : {}) }, previous);
        try { await store.save(); } catch (error) { store.data.settings = previous; throw error; }
        runnerFor(id).start(teste ? 'test' : 'publish', { method: metodo });
        if (isMain(id)) activeRunner = runner;
        return { mensagem: (teste ? 'Teste de 1 Reel' : 'Rodada') + ' iniciada: ' + account.name + ' · Slot ' + store.data.settings.postingSlot + ' · ' + (store.data.settings.product || 'all') + ' · ' + (metodo === 'api' ? 'API da Meta' : 'Chrome') + '. Acompanhe em status.json.' };
      },
      repostar_top: async ({ conta, posicao = 1, periodo = 'all', metodo = 'chrome' }) => {
        const account = findAccount(conta), rank = Number(posicao), period = String(periodo);
        if (![1, 2, 3].includes(rank)) throw new Error('posicao deve ser 1, 2 ou 3.');
        if (!Object.hasOwn(TOP_PERIODS, period)) throw new Error('periodo deve ser all, 30 ou 7.');
        if (!['chrome', 'adspower', 'api'].includes(metodo) || (metodo === 'adspower' && !account.main)) throw new Error('metodo inválido para esta conta.');
        if (account.main ? changing || mainBusy() : accountBusy(account.id)) throw new Error('a conta ' + account.name + ' está ocupada (rodada ou lote em andamento).');
        const result = await fireTop({ account: account.id, rank, period, method: metodo });
        return { mensagem: result.started ? 'Repost do top ' + rank + 'º iniciado: ' + result.started + ' vídeo(s) em ' + result.pages + ' Página(s) de ' + account.name + '.' : 'Nada iniciado: ' + result.message };
      },
      levantamento_suspensas: async () => {
        if (survey.running || metaStatus.progress.running) throw new Error('o levantamento já está rodando. Acompanhe em status.json (levantamentoSuspensas).');
        void runSurvey();
        return { mensagem: 'Levantamento iniciado: Gestão de Páginas e depois status na Meta de cada Página (alguns minutos). O relatório sai em comandos/relatorios/ (JSON e CSV); o andamento fica em status.json.' };
      },
      // Retirar Páginas do painel do Miwra = tirar o código delas da lista de ativas (estado.paginaIds),
      // como o painel faz. Nada é apagado (slots e cadastro ficam); "recolocar_paginas" desfaz.
      retirar_paginas: async ({ ids, nomes, confirmar = false, ignorarProtegidas = false }) => changeActive('retirar', ids, confirmar, { nomes, ignorarProtegidas }),
      recolocar_paginas: async ({ ids, nomes, confirmar = false }) => changeActive('recolocar', ids, confirmar, { nomes }),
      // Excluir no Facebook Páginas que estão FORA das ativas do Miwra (a API da Meta não exclui Páginas;
      // é feito pelo navegador da conta principal, uma por vez). Prévia sem "confirmar": true.
      excluir_paginas: async ({ ids, confirmar = false, limite }) => {
        const list = [...new Set((Array.isArray(ids) ? ids : String(ids || '').split(/[\s,;]+/)).map(value => String(value).trim().toLowerCase()).filter(Boolean))];
        if (!list.length) throw new Error('informe os códigos das Páginas no Miwra (ex.: "ids": ["ed397"]).');
        if (list.length > 300) throw new Error('muitas Páginas de uma vez (máximo 300).');
        const max = limite === undefined ? list.length : Number(limite);
        if (!Number.isInteger(max) || max < 1) throw new Error('limite deve ser um número inteiro a partir de 1.');
        const plan = await deletionPlan(list), targets = plan.pages.filter(item => item.elegivel), chosen = targets.slice(0, max);
        const preview = { vaoSerExcluidas: chosen.map(item => ({ id: item.id, nome: item.nome, facebookId: item.facebookId })), ficamDeFora: plan.pages.filter(item => !item.elegivel).map(({ id, nome, motivo }) => ({ id, nome, motivo })), foraDoLimite: targets.length - chosen.length, senhaSalva: plan.senhaSalva };
        if (confirmar !== true) return { mensagem: 'Prévia (nada foi feito): ' + chosen.length + ' Página(s) seriam excluídas no Facebook. Mande de novo com "confirmar": true para começar.', ...preview };
        if (!chosen.length) return { mensagem: 'Nada a excluir.', ...preview };
        startDeletion(chosen);
        return { mensagem: 'Exclusão iniciada: ' + chosen.length + ' Página(s), uma por vez, pelo navegador da conta principal. Acompanhe em status.json (exclusaoPaginas). Para parar: {"acao":"parar"}.', ...preview };
      },
      parar: async ({ conta }) => {
        if (conta === undefined) { const active = [...runners(), repost, ...[...extra.values()].map(item => item.repost).filter(Boolean), drive, ages, deleter].filter(job => job.progress.running); for (const job of active) job.stop(); return { mensagem: active.length ? 'Parada pedida em ' + active.length + ' operação(ões). Elas terminam o item atual e param.' : 'Nada estava rodando.' }; }
        const account = findAccount(conta), jobs = [runnerFor(account.id), account.main ? repost : extra.get(account.id)?.repost, account.main ? deleter : null].filter(job => job?.progress.running);
        for (const job of jobs) job.stop();
        return { mensagem: jobs.length ? 'Parada pedida na conta ' + account.name + '.' : 'Nada estava rodando na conta ' + account.name + '.' };
      },
    },
  }).start();
  const sessionKey = randomUUID();
  // Pacote do Autofy Simples: arquivo edicao-simples.txt ao lado da pasta core.
  const simpleEdition = existsSync(join(root, '..', 'edicao-simples.txt'));
  let changing = false, shuttingDown = false;
  const json = (res, status, data) => { res.writeHead(status, {'content-type':'application/json; charset=utf-8'}); res.end(JSON.stringify(data)); };
  const server = http.createServer(async (req,res) => {
    res.setHeader('cache-control','no-store');
    res.setHeader('x-content-type-options','nosniff');
    res.setHeader('x-frame-options','DENY');
    res.setHeader('referrer-policy', 'no-referrer');
    res.setHeader('content-security-policy', "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data: blob:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    if (shuttingDown) return json(res,503,{error:'O Autofy está encerrando. Abra novamente pelo atalho.'});
    if (!allowedPeer(req.socket.remoteAddress, lan)) return json(res,403,{error:'Acesso permitido somente pela rede local privada.'});
    const expectedHost = allowedHosts(server.address().port, lan, addresses);
    if (!expectedHost.has(req.headers.host)) return json(res,403,{error:'Host não permitido.'});
    let locked = false;
    try {
      const requestUrl = new URL(req.url,'http://' + req.headers.host);
      const path = requestUrl.pathname;
      if (requestUrl.origin !== 'http://' + req.headers.host) return json(res,403,{error:'Origem não permitida.'});
      if (req.headers.origin && req.headers.origin !== requestUrl.origin) return json(res,403,{error:'Origem não permitida.'});
      if (req.headers['sec-fetch-site'] === 'cross-site') return json(res,403,{error:'Origem não permitida.'});
      if (lan && path === '/auth/login' && req.method === 'POST') {
        if (req.headers.origin !== requestUrl.origin) return json(res,403,{error:'Abra a tela de login do Autofy para entrar.'});
        if (!req.headers['content-type']?.startsWith('application/json')) return json(res,415,{error:'Use JSON.'});
        const body = await readJson(req, 2048);
        const result = await access.login(body.password, req.socket.remoteAddress);
        if (result.status === 429) res.setHeader('retry-after', '300');
        if (result.cookie) res.setHeader('set-cookie', result.cookie);
        return json(res,result.status,result.error ? {error:result.error} : {ok:true});
      }
      // Logo do painel (também usado como ícone da aba). Imagem pública, sem dados.
      // Fonte do painel (Outfit, licença OFL), servida daqui: a política de segurança não carrega fontes de fora.
      if (req.method === 'GET' && path === '/fonts/Outfit-wght.ttf') { res.writeHead(200,{'content-type':'font/ttf','cache-control':'public, max-age=604800'}); return res.end(await readFile(join(root,'public','fonts','Outfit-wght.ttf'))); }
      if (req.method === 'GET' && path === '/logo.png') { res.writeHead(200,{'content-type':'image/png'}); return res.end(await readFile(join(root,'public','logo.png'))); }
      const session = access?.session(req);
      const publicLogin = lan && ['/login','/login.js','/style.css','/theme.js'].includes(path) && req.method === 'GET';
      if (lan && !session && !publicLogin) {
        if (req.method === 'GET' && path === '/') { res.writeHead(303,{location:'/login'}); return res.end(); }
        return json(res,401,{error:'Faça login no Autofy. A sessão pode ter expirado.'});
      }
      // Miniaturas do banco de avatares (só imagens; mesma proteção de sessão do painel).
      if (req.method === 'GET' && (path.startsWith('/avatar-img/') || path.startsWith('/cover-img/'))) {
        const bank = path.startsWith('/cover-img/') ? covers : avatars;
        const found = await bank.image(path.slice(path.indexOf('-img/') + 5));
        if (!found) return json(res,404,{error:'Imagem não encontrada.'});
        res.writeHead(200,{'content-type':found.type,'cache-control':'private, max-age=86400','x-content-type-options':'nosniff'}); return res.end(found.bytes);
      }
      if (req.method === 'GET' && (['/', '/simple.js', '/simple.css', '/theme.js', '/app.js', '/views.js', '/drive.js', '/api-post.js', '/ages.js', '/delete-pages.js', '/analytics.js', '/health.js', '/countries.js', '/replies.js', '/avatars.js', '/profile.js', '/navigation.js', '/update.js', '/style.css'].includes(path) || publicLogin)) {
        // Edição simples (Autofy Simples): a tela única simple.html no lugar do painel completo.
        const filename = path === '/' ? (simpleEdition ? 'simple.html' : 'index.html') : path === '/login' ? 'login.html' : path.slice(1);
        let content;
        try { content = await readFile(join(root,'public',filename),'utf8'); }
        catch (error) {
          if (error.code !== 'ENOENT') throw error;
          // Arquivo da tela sumiu depois de abrir: OneDrive sincronizando, antivírus ou extração mexida.
          res.writeHead(500,{'content-type':'text/html; charset=utf-8'});
          return res.end('<!doctype html><meta charset="utf-8"><title>Autofy</title><body style="font:16px system-ui;max-width:640px;margin:48px auto;line-height:1.5"><h2>O Autofy não achou os arquivos da tela</h2><p>Pasta do programa:<br><code>' + root.replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])) + '</code></p>' + (/onedrive|dropbox|google drive/i.test(root) ? '<p><b>Ela está dentro do OneDrive (ou outra nuvem).</b> A nuvem mexe nos arquivos enquanto sincroniza e o painel não funciona.</p>' : '') + '<ol><li><b>Reinicie o computador</b> (isso fecha o Autofy que ficou aberto).</li><li>Extraia o ZIP de novo, digitando exatamente <code>C:\\Autofy</code> na hora de escolher a pasta (com o C, os dois-pontos e a barra). Fora do OneDrive.</li><li>Abra essa pasta nova e dê dois cliques em <b>Criar atalho na Area de Trabalho.bat</b>. Depois abra pelo ícone da Área de Trabalho.</li></ol><p>Veja a ETAPA 2 do TUTORIAL-PASSO-A-PASSO.txt.</p></body>');
        }
        if (path === '/') content = content.replace('__SESSION_KEY__',session?.csrf || sessionKey);
        res.writeHead(200,{'content-type':filename.endsWith('.html') ? 'text/html; charset=utf-8' : path.endsWith('.js') ? 'text/javascript; charset=utf-8' : 'text/css; charset=utf-8'});
        return res.end(content);
      }
      if (req.headers['x-publisher-key'] !== (session?.csrf || sessionKey)) return json(res,403,{error:'Atualize a tela do Autofy.'});
      if (req.method === 'GET') {
        if (path === '/api/views') return json(res,200,{...views.report(Object.fromEntries(requestUrl.searchParams)),canSetToken:allowedPeer(req.socket.remoteAddress,false),...(requestUrl.searchParams.get('account') && !isMain(requestUrl.searchParams.get('account')) && (store.data.settings.accounts || []).some(account => account.id === requestUrl.searchParams.get('account'))
          ? (() => { const id = requestUrl.searchParams.get('account'), target = repostFor(id); return { publisherBusy: Boolean(extra.get(id)?.runner.progress.running || target.progress.running), operation: target.progress, account: id }; })()
          : { publisherBusy:changing||runner.progress.running||repost.progress.running||drive.progress.running||ages.progress.running, operation:repost.progress })});
        if (path === '/api/auto') return json(res,200,auto.report());
        if (path === '/api/analytics') return json(res,200,await plays.report(requestUrl.searchParams.get('window') || '24h'));
        if (path === '/api/analytics/status') return json(res,200,plays.status());
        if (path === '/api/pages/health') return json(res,200,healthReport());
        if (path === '/api/top-schedule') return json(res,200,topSchedule.report(requestUrl.searchParams.get('account') || MAIN_ACCOUNT));
        if (path === '/api/countries') return json(res,200,countries.report());
        if (path === '/api/avatars') return json(res,200,avatars.report());
        if (path === '/api/covers') return json(res,200,covers.report());
        if (path === '/api/replies') return json(res,200,replies.report());
        if (path === '/api/profile') return json(res,200,profile.report());
        if (path === '/api/api-post/status') return json(res,200,await publisherFor(requestUrl.searchParams.get('account')).status({refresh:requestUrl.searchParams.get('refresh')==='1'}));
        if (path === '/api/drive') return json(res,200,{...drive.report(),publisherBusy:changing||runner.progress.running||repost.progress.running||drive.progress.running||ages.progress.running});
        if (path === '/api/settings') return json(res,200,{...publicSettings(store.data.settings),networkMode:lan});
        if (path === '/api/update') return json(res,200,updater.report());
        if (path === '/api/progress') {
          // ?account=: a rodada daquela conta de Facebook; sem ele, a operação mais recente (Drive, repostagem…).
          const account = requestUrl.searchParams.get('account');
          const current = account ? runnerFor(account) : activeRunner;
          return json(res,200,{...current.progress,account:account || null,browserOpen:(browser => Boolean(browser.isOpen ? browser.isOpen() : browser.context))(account ? facebookFor(account) : fb),opening:changing,scheduled:scheduled.report(account || MAIN_ACCOUNT),apiScheduled:scheduled.report(apiBucket(account || MAIN_ACCOUNT)),
            accounts:accountsReport(),anyRunning:runners().some(item => item.progress.running) || repost.progress.running || drive.progress.running || ages.progress.running});
        }
        if (path === '/api/history/screenshot') {
          // Captura da tela do navegador no momento da falha. Só entrega o arquivo ligado a um
          // registro do histórico, com o nome daquele registro e dentro da pasta de dados.
          const item = store.data.history.find(row => row.id === requestUrl.searchParams.get('id'));
          const file = item?.screenshot ? resolve(String(item.screenshot)) : '';
          if (!file || !file.startsWith(resolve(directory) + sep) || basename(file) !== item.id + '.png') return json(res,404,{error:'Este registro não tem captura de tela.'});
          let bytes;
          try { bytes = await readFile(file); } catch { return json(res,404,{error:'A captura de tela não está mais na pasta de dados.'}); }
          res.writeHead(200,{'content-type':'image/png','cache-control':'no-store','content-length':bytes.length}); return res.end(bytes);
        }
        if (path === '/api/pages/age') {
          // Aba "Idade das Páginas": só leitura do resumo do Miwra (data de cadastro de cada Página ativa).
          const settings = structuredClone(store.data.settings);
          return json(res,200,{...pageAges(await makeMiwra(settings).summary(), settings, Date.now(), ages.dates()),scan:ages.report(),browser:settings.browser === 'adspower' ? 'adspower' : 'chrome'});
        }
        if (path === '/api/pages/age/scan') return json(res,200,ages.report());
        // Aba "Excluir Páginas": Páginas fora do quadro do Miwra e o andamento do lote.
        if (path === '/api/pages/delete') return json(res,200,{...await deletionPlan(),progress:deletionReport()});
        if (path === '/api/pages/delete/progress') return json(res,200,deletionReport());
        // A tela mostra as 100 mais recentes: não manda o histórico inteiro a cada atualização.
        if (path === '/api/history') return json(res,200,store.data.history.slice(-150).reverse().map(({screenshot,...item}) => ({...item,hasScreenshot:Boolean(screenshot)})));
        if (path === '/api/preview') {
          const settings = structuredClone(accountSettings(store.data.settings, requestUrl.searchParams.get('account')));
          const params = requestUrl.searchParams;
          if (params.has('repost') && !['true','false'].includes(params.get('repost'))) throw new Error('Opção de republicação inválida.');
          const context = publicationContext({sourceDate:params.get('sourceDate') ?? undefined, publicationDate:params.get('publicationDate') ?? undefined, repost:params.get('repost') === 'true'});
          const date = context.sourceDate;
          const miwra = makeMiwra(settings);
          const summary = await miwra.summary();
          const availability = await verifier.inspect(summary,settings,miwra,date,{...context,force:params.get('refresh')==='1'});
          const pages = buildQueue(summary,settings,store.data.history,date,availability,context);
          const activePages = profilePages(summary,settings);
          const productCounts = { ed: activePages.filter(p=>pageProduct(p)==='ed').length, wl: activePages.filter(p=>pageProduct(p)==='wl').length };
          return json(res,200,{account:requestUrl.searchParams.get('account') || MAIN_ACCOUNT,profile:settings.profile,date,...context,pages,total:pages.length,product:productSetting(settings),productCounts,inactiveCount:profilePages(summary,settings,true).length-activePages.length,postingSlot:settings.postingSlot,selected:pages.filter(p=>p.selected).length,ready:pages.filter(p=>p.code==='ready').length,verifiedAt:new Date().toISOString()});
        }
      }
      if (req.method !== 'POST') return json(res,404,{error:'Rota não encontrada.'});
      if (!req.headers['content-type']?.startsWith('application/json')) return json(res,415,{error:'Use JSON.'});
      const body = await readJson(req, 1024*1024);
      if (path === '/api/logout' && lan) { res.setHeader('set-cookie',access.logout(req)); return json(res,200,{ok:true}); }
      if (path === '/api/views/settings') {
        if (changing || repost.progress.running || drive.progress.running||ages.progress.running) return json(res,409,{error:'Aguarde a operação atual do Autofy terminar.'});
        if (body.token && !allowedPeer(req.socket.remoteAddress,false)) return json(res,403,{error:'Configure o token no próprio notebook usando http://127.0.0.1:'+port+'. Ele não deve atravessar a rede HTTP.'});
        await views.configure(body); return json(res,200,{ok:true});
      }
      if (path === '/api/auto/save') return json(res,200,await auto.save(body));
      if (path === '/api/views/refresh') {
        if (!views.config.enabled || !views.config.token || views.authBlocked || views.retryAt > views.now() || views.changing) return json(res,409,{error:'Confira a conexão e os avisos das views antes de atualizar.'});
        void views.refresh().catch(()=>{}); return json(res,202,{ok:true});
      }
      if (path === '/api/views/disconnect') { if(changing || repost.progress.running || drive.progress.running||ages.progress.running) return json(res,409,{error:'Aguarde a operação atual do Autofy terminar.'}); await views.disconnect(); return json(res,200,{ok:true}); }
      if (path === '/api/top-schedule/save') return json(res,200,await topSchedule.set(body.account || MAIN_ACCOUNT, body.rows));
      if (path === '/api/top-schedule/run') return json(res,200,await topSchedule.runNow(body.id));
      if (path === '/api/views/stop' && body.account && !isMain(body.account)) { repostFor(body.account).stop(); return json(res,200,{ok:true}); }
      if (path === '/api/stop' || path === '/api/views/stop') { (body.account ? runnerFor(body.account) : activeRunner).stop(); return json(res,200,{ok:true}); }
      if ((path === '/api/views/prepare-miwra' || path === '/api/views/start') && body.account && !isMain(body.account)) {
        // Melhores vídeos de uma conta extra: não depende da conta principal estar livre, só desta conta.
        const target = repostFor(body.account), item = extraFor(body.account);
        if (item.runner.progress.running) return json(res,409,{error:'A rodada de Publicações desta conta está em andamento (o Chrome dela está ocupado). Aguarde terminar.'});
        if (path === '/api/views/prepare-miwra') return json(res,200,await target.prepareFromAnalytics(body));
        if (body.method !== 'api' && body.browser === 'adspower') return json(res,400,{error:'As contas extras repostam pelo Chrome próprio delas (ou pela API). O AdsPower é só da conta principal.'});
        target.start(body); return json(res,202,{ok:true});
      }
      // Textos das telas Postar por API e Melhores vídeos (descrições e comentário de ED e WL). Só esses campos mudam; a rodada
      // em andamento continua com os textos com que começou.
      if (path === '/api/api-post/texts') {
        const keys = ['api', 'top'].flatMap(prefix => ['Caption', 'CaptionWl', 'Comment', 'CommentWl', 'CommentOn', 'CommentScope', 'CommentMaxDays'].map(name => prefix + name));
        const change = Object.fromEntries(keys.filter(key => Object.hasOwn(body, key)).map(key => [key, body[key]]));
        const previous = store.data.settings;
        store.data.settings = validateSettings(change, previous);
        try { await store.save(); } catch (error) { store.data.settings = previous; throw error; }
        return json(res,200,{...publicSettings(store.data.settings),networkMode:lan});
      }
      if (path === '/api/schedule') {
        // Pela API: confere antes se a conta tem token da Meta, para não programar uma rodada que não vai sair.
        if (body.method === 'api') {
          const account = accountList(store.data.settings).find(item => item.id === (body.account || MAIN_ACCOUNT));
          if (!account) return json(res,400,{error:'Conta do Facebook não encontrada. Atualize a tela.'});
          const status = await publisherFor(account.id).status();
          if (!status.tokenConfigured) return json(res,400,{error:'Cadastre o token da Meta desta conta em Configurações antes de programar pela API.'});
        }
        return json(res,200,await scheduled.set(body));
      }
      if (path === '/api/schedule/cancel') return json(res,200,await scheduled.cancel(body));
      if (path === '/api/stop-all') {
        // Botão "Parar postagem" do topo: para o que estiver em andamento, em qualquer tela.
        const active = [...runners(),repost,...[...extra.values()].map(item => item.repost).filter(Boolean),drive,ages,deleter].filter(job => job.progress.running);
        for (const job of active) job.stop();
        return json(res,200,{ok:true,stopped:active.length});
      }
      if (path === '/api/drive/stop') { drive.stop(); return json(res,200,{ok:true}); }
      if (path === '/api/pages/age/stop') { ages.stop(); return json(res,200,{ok:true}); }
      if (path === '/api/pages/delete/stop') { deleter.stop(); return json(res,200,{ok:true}); }
      if (path === '/api/analytics/refresh') {
        // Começa a coleta e responde na hora; recusa (sem token, pausa da Meta) volta como erro.
        let refused = null; plays.refresh().catch(error => { refused = error; });
        await new Promise(resolve => setImmediate(resolve));
        return refused ? json(res,409,{error:refused.message}) : json(res,200,plays.status());
      }
      if (path === '/api/pages/health/check') { health.check('manual').catch(() => {}); await new Promise(resolve => setImmediate(resolve)); return json(res,200,healthReport()); }
      if (path === '/api/pages/health/settings') { await health.setSettings(body); return json(res,200,healthReport()); }
      if (path === '/api/pages/meta-status/check') { metaStatus.start(); return json(res,200,healthReport()); }
      if (path === '/api/pages/meta-status/stop') { metaStatus.stop(); return json(res,200,healthReport()); }
      if (path === '/api/analytics/stop') { plays.stop(); return json(res,200,plays.status()); }
      if (path === '/api/analytics/settings') return json(res,200,await plays.setEnabled(body.enabled));
      if (path === '/api/update/check') return json(res,200,await updater.check());
      if (path === '/api/update/install') {
        // Baixa e troca os arquivos com o painel livre; depois reabre o Autofy sozinho. Só no próprio computador.
        if (!allowedPeer(req.socket.remoteAddress,false)) return json(res,403,{error:'Atualize o Autofy no próprio computador servidor.'});
        if (typeof api.onShutdown !== 'function') return json(res,409,{error:'Neste modo o Autofy não consegue se reabrir sozinho. Atualize pelo ZIP.'});
        if (isBusy()) return json(res,409,{busy:true,error:'Há uma operação em andamento. Aguarde terminar para atualizar.'});
        const result = await updater.install();
        json(res,200,result);
        setTimeout(()=>{ updater.restart(); void api.onShutdown(false); },300);
        return;
      }
      if (path === '/api/shutdown') {
        // Encerra o servidor, o Chrome do Autofy e libera os dados. Só no próprio computador.
        if (!allowedPeer(req.socket.remoteAddress,false)) return json(res,403,{error:'Encerre o Autofy no próprio computador servidor.'});
        if (typeof api.onShutdown !== 'function') return json(res,409,{error:'Neste modo o Autofy é encerrado pela janela em que foi iniciado.'});
        if (isBusy() && body.force !== true) return json(res,409,{busy:true,error:'Há uma operação em andamento.'});
        json(res,200,{ok:true});
        setTimeout(()=>{ void api.onShutdown(body.force === true); },200);
        return;
      }
      if (path === '/api/continue') { runnerFor(body.account).continue(body.id); return json(res,200,{ok:true}); }
      // Rodadas de contas diferentes correm juntas: iniciar, abrir o Facebook de uma conta e salvar a
      // configuração só esperam a própria conta (e a principal espera Drive, repostagem e Idade).
      if (path === '/api/start') {
        const account = body.account || MAIN_ACCOUNT, target = runnerFor(account);
        if (accountBusy(account)) return json(res,409,{error:isMain(account) ? 'Aguarde a operação atual terminar.' : 'Esta conta do Facebook já está com uma rodada em andamento.'});
        // A trava "changing" é da conta principal (abrir o AdsPower, buscar IDs na Meta, salvar): só ela espera.
        if (isMain(account) && changing) return json(res,409,{error:'Aguarde a operação atual terminar.'});
        target.start(body.mode,body); if (isMain(account)) activeRunner = runner;
        return json(res,202,{ok:true});
      }
      if (path === '/api/login' && !isMain(body.account)) {
        if (accountBusy(body.account)) return json(res,409,{error:'Aguarde a rodada desta conta terminar.'});
        await facebookFor(body.account).login(); return json(res,200,{ok:true,browser:'chrome'});
      }
      // Países: só chamadas à API da Meta (sem navegador), podem rodar junto com as rodadas.
      if (path === '/api/countries/pages') return json(res,200,await countries.pages(body.account));
      if (path === '/api/countries/start') return json(res,200,countries.start(body));
      if (path === '/api/countries/stop') return json(res,200,countries.stop());
      // Mensagens automáticas: só API da Meta.
      if (path === '/api/replies/pages') return json(res,200,await replies.pages(body.account));
      if (path === '/api/replies/rule') return json(res,200,replies.saveRule(body));
      if (path === '/api/replies/enable') return json(res,200,replies.setPages(body));
      if (path === '/api/replies/active') return json(res,200,replies.setActive(Boolean(body.active)));
      if (path === '/api/replies/check') return json(res,200,replies.checkNow());
      // Avatares: banco de imagens e aplicação pela API da Meta.
      // Avatares e capas: /api/avatars/... e /api/covers/... (mesmas ações, bancos separados).
      const bankMatch = path.match(/^\/api\/(avatars|covers)\/(upload|drive\/list|drive\/fetch|remove|pages|start|stop)$/);
      if (bankMatch) {
        const bank = imageBanks[bankMatch[1]], action = bankMatch[2];
        if (action === 'upload') return json(res,200,await bank.addImage(body));
        if (action === 'drive/list') return json(res,200,await bank.driveList(body.link));
        if (action === 'drive/fetch') return json(res,200,await bank.driveFetch(body));
        if (action === 'remove') return json(res,200,await bank.removeImage(String(body.id || '')));
        if (action === 'pages') return json(res,200,await bank.pages(body.account));
        if (action === 'start') return json(res,200,bank.start(body));
        return json(res,200,bank.stop(body));
      }
      // Dados das Páginas: também só API da Meta.
      if (path === '/api/profile/pages') return json(res,200,await profile.pages(body.account));
      if (path === '/api/profile/bank') return json(res,200,profile.setBank(body));
      if (path === '/api/profile/settings') return json(res,200,profile.setSettings(body));
      if (path === '/api/profile/assign') return json(res,200,profile.assign(body));
      if (path === '/api/profile/start') return json(res,200,profile.start(body));
      if (path === '/api/profile/stop') return json(res,200,profile.stop());
      if (path === '/api/profile/cancel') return json(res,200,profile.cancel(body));
      if (path === '/api/pages/import-ids' && !isMain(body.account)) {
        // "Buscar IDs no Miwra" de uma conta extra: só lê o Miwra (e a Meta dela) e grava os IDs das
        // Páginas dela, sem navegador. Pode rodar com a principal (ou outra conta) postando.
        extraFor(body.account);
        if (accountBusy(body.account)) return json(res,409,{error:'Aguarde a rodada desta conta terminar.'});
        if (importingIds.has(body.account)) return json(res,409,{error:'A busca de IDs desta conta já está em andamento.'});
        importingIds.add(body.account);
        try { return json(res,200,await importPageIds(body.account)); } finally { importingIds.delete(body.account); }
      }
      if (path === '/api/resolve' && extraOwner(body.id)) {
        // Conferência de um envio de conta extra: só espera a rodada daquela conta.
        await runnerFor(extraOwner(body.id)).resolve(body.id,body.action); return json(res,200,{ok:true});
      }
      if (path === '/api/accounts/pages') {
        // Divisão por ID: as Páginas que o token da conta extra enxerga (só ID e nome, para a lista dela).
        if (isMain(body.account)) return json(res,400,{error:'A divisão por ID é das contas extras. A conta principal fica com as Páginas que sobram.'});
        extraFor(body.account);
        const pages = await tokens.pageIds(body.account);
        return json(res,200,{pages:pages.map(page => ({ id: String(page.id), name: String(page.name || '') }))});
      }
      if (path === '/api/accounts/token') {
        // Token da Meta de uma conta extra: só no próprio computador, como o da Conexão com a Meta.
        if (!allowedPeer(req.socket.remoteAddress,false)) return json(res,403,{error:'Configure o token no próprio computador usando http://127.0.0.1:'+port+'. Ele não deve atravessar a rede HTTP.'});
        if (isMain(body.account)) return json(res,400,{error:'O token da conta principal fica em Conexão com a Meta.'});
        extraFor(body.account);
        return json(res,200,body.remove === true ? await tokens.remove(body.account) : await tokens.set(body.account, body.token, body.apiVersion || views.config.apiVersion || 'v26.0'));
      }
      if (path === '/api/settings' && runners().some(item => item.progress.running) && !changing && !repost.progress.running && !drive.progress.running && !ages.progress.running) {
        // Com rodada em andamento: o resto da configuração pode mudar (cada rodada já leu a dela ao
        // começar), mas não o perfil, o navegador nem a conta de uma rodada que está rodando.
        const previous = store.data.settings, next = validateSettings(body,previous);
        const same = (a, b) => JSON.stringify(a ?? '') === JSON.stringify(b ?? '');
        if (runner.progress.running && ['profile','browser','adsPowerUserId','adsPowerApi'].some(key => !same(next[key], previous[key]))) return json(res,409,{error:'A conta principal está rodando: o perfil do Miwra e o navegador só mudam quando a rodada dela terminar.'});
        for (const [id, item] of extra) if (item.runner.progress.running && !same(next.accounts.find(account => account.id === id), previous.accounts.find(account => account.id === id))) return json(res,409,{error:'A conta ' + item.runner.account.name + ' está rodando: ela só pode ser alterada ou removida quando a rodada terminar.'});
        store.data.settings = next;
        try { await store.save(); } catch (error) { store.data.settings = previous; throw error; }
        await scheduled.keepAccounts((store.data.settings.accounts || []).map(account => account.id));
        await topSchedule.keepAccounts((store.data.settings.accounts || []).map(account => account.id));
        return json(res,200,{...publicSettings(store.data.settings),networkMode:lan});
      }
      if (path !== '/api/pages/delete/stop' && deleter.progress.running) return json(res,409,{error:'A exclusão de Páginas está rodando. Espere terminar ou clique em Parar exclusão.'});
      if (runner.progress.running || repost.progress.running || drive.progress.running||ages.progress.running || changing) return json(res,409,{error:'Aguarde a operação atual terminar.'});
      changing = true; locked = true;
      if (path === '/api/drive/load') return json(res,200,await drive.load(body.folderUrl));
      if (path === '/api/drive/prepare') return json(res,200,drive.prepare(body));
      if (path === '/api/drive/start') { drive.start(body); activeRunner=drive; return json(res,202,{ok:true}); }
      if (path === '/api/auto/run') return json(res,200,await auto.runNow(body.id));
      if (path === '/api/views/prepare') return json(res,200,repost.prepare(body));
      if (path === '/api/views/prepare-miwra') return json(res,200,await repost.prepareFromAnalytics(body));
      if (path === '/api/views/start') {
        // "Repostar pelo Chrome" e "Repostar pelo AdsPower" dizem o navegador; pela API não se aplica.
        if (body.method !== 'api') await chooseBrowser(body.browser);
        repost.start(body); activeRunner = repost; return json(res,202,{ok:true,browser:store.data.settings.browser || 'chrome'});
      }
      if (path === '/api/pages/age/scan') {
        // Só navegação: abre a Transparência de cada Página ativa que ainda não tem a data guardada.
        const settings = structuredClone(store.data.settings);
        const started = ages.start(scanTargets(await makeMiwra(settings).summary(), settings));
        return json(res,202,{ok:true,...started,scan:ages.report()});
      }
      if (path === '/api/pages/delete/password') {
        // Senha do Facebook de uma conta (principal ou extra), só para a exclusão de Páginas.
        const account = String(body.account || ''), password = String(body.password || '');
        if (!password) return json(res,400,{error:'Digite a senha.'});
        if (!accountList(store.data.settings).some(item => item.id === account)) return json(res,400,{error:'Conta do Facebook não encontrada. Atualize a tela.'});
        const previous = store.data.settings;
        store.data.settings = validateSettings(isMain(account) ? { facebookPassword: password } : { deletePasswords: { [account]: password } }, previous);
        try { await store.save(); } catch (error) { store.data.settings = previous; throw error; }
        return json(res,200,{ok:true});
      }
      if (path === '/api/pages/delete/start') {
        // Exclui no Facebook as Páginas marcadas na aba (só as que o plano aceita), uma por vez.
        const wanted = [...new Set((Array.isArray(body.ids) ? body.ids : []).map(value => String(value).trim().toLowerCase()).filter(Boolean))];
        if (!wanted.length) return json(res,400,{error:'Marque ao menos uma Página.'});
        if (wanted.length > 300) return json(res,400,{error:'Máximo de 300 Páginas por lote.'});
        const plan = await deletionPlan(wanted), chosen = plan.pages.filter(item => item.elegivel);
        // Um lote = uma conta (a aba escolhida na tela). Páginas de outra conta não entram.
        if (body.account !== undefined && chosen.some(item => item.conta !== String(body.account))) return json(res,400,{error:'Há Páginas de outra conta na seleção (' + chosen.filter(item => item.conta !== String(body.account)).map(item => item.nome + ' · ' + item.contaNome).slice(0, 5).join('; ') + '). Atualize a lista e marque só as Páginas da conta escolhida.'});
        if (new Set(chosen.map(item => item.conta)).size > 1) return json(res,400,{error:'Escolha Páginas de uma conta só por lote.'});
        if (!chosen.length) return json(res,400,{error:'Nenhuma das Páginas marcadas pode ser excluída: ' + plan.pages.map(item => item.nome + ' (' + item.motivo + ')').slice(0, 5).join('; ')});
        startDeletion(chosen, { locked: true });
        return json(res,202,{ok:true,started:chosen.length,skipped:plan.pages.filter(item => !item.elegivel),progress:deletionReport()});
      }
      if (path === '/api/pages/import-ids') return json(res,200,await importPageIds(MAIN_ACCOUNT));
      if (path === '/api/settings') {
        const previous = store.data.settings;
        store.data.settings = validateSettings(body,previous);
        try { await store.save(); } catch (error) { store.data.settings = previous; throw error; }
        // Conta removida: fecha o Chrome dela e esquece o token.
        const ids = (store.data.settings.accounts || []).map(account => account.id);
        for (const [id, item] of [...extra]) if (!ids.includes(id)) { extra.delete(id); await item.facebook.close().catch(() => {}); }
        await tokens.keepOnly(ids);
        await scheduled.keepAccounts(ids);
        await topSchedule.keepAccounts(ids);
        return json(res,200,{...publicSettings(store.data.settings),networkMode:lan});
      }
      if (path === '/api/diagnose/screen') {
        // Só leitura: abre um endereço do Facebook no navegador da automação e descreve a tela.
        return json(res,200,await describeUrl(fb, body.url, body.wait));
      }
      if (path === '/api/diagnose/profile-menu') {
        // Só leitura: descreve o menu da foto do perfil no navegador da automação. Não troca de perfil.
        return json(res,200,await profileMenuDiagnosis(fb, uniqueVisible, String(body.pageName || '').slice(0,200)));
      }
      if (path === '/api/login') {
        // Os botões "Abrir Facebook (Chrome)" e "(AdsPower)" escolhem o navegador: a escolha fica
        // salva e vale também para as rodadas pelo Chrome. Com uma operação em andamento a rota já foi recusada acima.
        await chooseBrowser(body.browser);
        await fb.login(); return json(res,200,{ok:true,browser:store.data.settings.browser || 'chrome'});
      }
      if (path === '/api/history/release') {
        // Liberar Páginas bloqueadas pelo histórico: o Miwra passa para o dia seguinte os vídeos não
        // postados até 23:59, com o mesmo lote. Se a rodada anterior foi interrompida e o usuário conferiu
        // que nada saiu no Facebook, as tentativas desses lotes viram "não publicado" e o vídeo volta para
        // a rodada. Só tentativas de rodadas de Publicações sem publicação confirmada; nada é apagado.
        const account = body.account || MAIN_ACCOUNT;
        if (!isMain(account) && extraFor(account).runner.progress.running) return json(res,409,{error:'A rodada desta conta está em andamento.'});
        const settings = structuredClone(accountSettings(store.data.settings, account));
        const date = publicationContext({ sourceDate: body.date || undefined }).sourceDate;
        const summary = await makeMiwra(settings).summary({ fresh: true });
        const keys = new Map();
        for (const page of profilePages(summary, settings)) for (const slot of summary.estado?.slots?.[date]?.[String(page.id)] || [])
          if (slot?.status === 'buffer' && slot.jobId) keys.set(JSON.stringify([String(page.id), String(slot.jobId)]), page.nome || page.name || String(page.id));
        // Tudo que bloqueia esses lotes (mesma regra da rodada), menos o que o Facebook confirmou como publicado.
        const confirmedOnFacebook = new Set(['posted', 'confirmed', 'pending_sync']);
        const blocking = store.data.history.filter(item => !['drive', 'views'].includes(item.source) && blockedStates.has(item.status) &&
          keys.has(JSON.stringify([String(item.pageId), String(item.jobId)])));
        const items = blocking.filter(item => !confirmedOnFacebook.has(item.status));
        const statuses = {};
        for (const item of blocking) statuses[item.status] = (statuses[item.status] || 0) + 1;
        const pages = [...new Set(items.map(item => keys.get(JSON.stringify([String(item.pageId), String(item.jobId)]))))].sort((a, b) => String(a).localeCompare(String(b), 'pt-BR'));
        if (body.apply !== true) return json(res,200,{count:items.length,pages,statuses,slotsChecked:keys.size,date});
        const at = new Date().toISOString();
        for (const item of items) Object.assign(item, { status: 'not_posted', releasedAt: at, previousStatus: item.status, error: 'Liberado pelo usuário: a rodada foi interrompida e o vídeo não saiu no Facebook. O Miwra passou o lote para ' + date + '.' });
        await store.save();
        return json(res,200,{count:items.length,pages,released:true});
      }
      if (path === '/api/resolve') { const item=store.data.history.find(row=>row.id===body.id), source=item?.source; await (source==='drive'?drive:source==='views'?repost:item?.account && (store.data.settings.accounts||[]).some(account=>account.id===item.account) ? runnerFor(item.account) : runner).resolve(body.id,body.action); return json(res,200,{ok:true}); }
      return json(res,404,{error:'Rota não encontrada.'});
    } catch (error) { json(res,400,{error:error.message}); }
    finally { if (locked) changing = false; }
  });
  server.once('listening',()=>{ views.start(); plays.start(); health.start(); });
  // Grava só o navegador escolhido por um botão (Chrome próprio ou AdsPower); o resto fica como está.
  const chooseBrowser = async browser => {
    if (browser === undefined || browser === (store.data.settings.browser || 'chrome')) return;
    const previous = store.data.settings;
    store.data.settings = validateSettings({browser},previous);
    try { await store.save(); } catch (error) { store.data.settings = previous; throw error; }
  };
  const isBusy = () => changing || ['downloading','installing'].includes(updater.phase) || runners().some(item => item.progress.running) || repost.progress.running || drive.progress.running||ages.progress.running;
  let closing;
  const close = () => closing ||= (async()=>{shuttingDown=true;updater.close();scheduled.close();remote.close();await topSchedule.close();await auto.close();runner.stop(); repost.stop(); drive.stop(); ages.stop(); await views.close(); await plays.close(); await health.close(); await metaStatus.close(); await countries.close(); await replies.close(); await avatars.close(); await covers.close(); await profile.close(); for (const item of extra.values()) { item.runner.stop(); } await fb.close(); for (const item of extra.values()) { await item.runner.task; await item.facebook.close().catch(() => {}); } await tokens.close(); await runner.task; await repost.task; await drive.task; await ages.task; await store.tail; await new Promise(resolve=>server.close(resolve));})();
  const api = {server,store,scheduled,ages,plays,health,countries,replies,profile,runner,tokens,runnerFor,facebookFor,views,repost,drive,auto,publisher,sessionKey,port,host:lan?'0.0.0.0':'127.0.0.1',lan,addresses,isBusy,close,onShutdown:null,
    closeIfIdle:async()=>{if(isBusy())return false;await close();return true;}};
  return api;
}
async function readJson(req, limit) {
  if (Number(req.headers['content-length']) > limit) { req.resume(); throw new Error('Requisição muito grande.'); }
  const chunks = []; let length = 0;
  for await (const chunk of req) { length += chunk.length; if (length > limit) throw new Error('Requisição muito grande.'); chunks.push(chunk); }
  let body;
  try { body = JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}'); }
  catch { throw new Error('JSON inválido.'); }
  if (!body || Array.isArray(body) || typeof body !== 'object') throw new Error('Use um objeto JSON.');
  return body;
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const app = await createApp({lan:process.argv.includes('--lan')});
  app.server.on('error',error=>{ console.error(error.code === 'EADDRINUSE' ? 'A porta está ocupada. Feche o outro Autofy ou altere PORT no .env.' : error.message); process.exitCode = 1; });
  app.server.listen(app.port,app.host,()=>{
    console.log('Autofy: http://127.0.0.1:' + app.port + '\nMantenha esta janela aberta.');
    if (app.lan) {
      for (const ip of app.addresses) console.log('Rede: http://' + ip + ':' + app.port);
      if (!app.addresses.length) console.log('Nenhum IPv4 privado encontrado. Conecte o notebook ao Wi-Fi/cabo e reinicie.');
      console.log('Acesso com senha. HTTP sem criptografia: somente rede privada confiavel.');
      console.log('Se necessario, permita Node.js no Firewall apenas na rede Privada; nunca abra a porta no roteador.');
      console.log('O Chrome e as postagens rodam neste computador. Login do Facebook deve ser feito aqui.');
    }
  });
  let closing = false;
  for (const signal of ['SIGINT','SIGTERM']) process.on(signal,async()=>{ if(closing)return; closing=true; await app.close(); process.exit(0); });
}
