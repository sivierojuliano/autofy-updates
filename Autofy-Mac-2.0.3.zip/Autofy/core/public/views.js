(() => {
  const el = id => document.getElementById(id);
  const key = document.querySelector('meta[name=publisher-key]').content;
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const date = value => value && Number.isFinite(Date.parse(value)) ? new Date(value).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : '—';
  const number = value => value == null ? '—' : Number(value).toLocaleString('pt-BR');
  let offset = 0, sequence = 0, data, editing = false, saving = false, timer, searchTimer;
  let working = false;
  let topPlan = null, topLoaded = 0, topSig = '', topSelected = new Set(), topBusy = false, wasRunning = false;
  // Conta do Facebook da aba Melhores vídeos: cada uma com as Páginas, o token e o Chrome dela.
  let topAccount = (() => { try { return localStorage.getItem('jsautopost-melhores-conta') || 'main'; } catch { return 'main'; } })();
  const topExtras = () => (typeof settings === 'object' && settings?.accounts) || [];
  const topIsMain = () => topAccount === 'main' || !topExtras().some(item => item.id === topAccount);
  const topAccountName = () => typeof accountName === 'function' ? accountName(topIsMain() ? 'main' : topAccount) : 'Conta principal';
  const withAccount = body => topIsMain() ? body : { ...body, account: topAccount };
  const dateCriteria = () => ({ dateFrom: el('views-date-from').value, dateTo: el('views-date-to').value });
  function dateError(criteria = dateCriteria()) {
    const { dateFrom, dateTo } = criteria;
    for (const value of [dateFrom, dateTo]) if (value && (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(Date.parse(value + 'T12:00:00Z')) || new Date(value + 'T12:00:00Z').toISOString().slice(0, 10) !== value)) return 'Informe datas válidas.';
    return dateFrom && dateTo && dateFrom > dateTo ? 'A data inicial não pode ser posterior à data final.' : '';
  }
  function engagementCell(video, metric) {
    const value = video[metric];
    return '<td class="views-engagement"><strong>' + number(value) + '</strong><small>' + (value == null ? 'Indisponível' : 'Leitura: ' + date(video[metric + 'LastSuccessAt'])) + '</small>' +
      (video[metric + 'Stale'] && value != null ? '<small class="views-warning">Valor anterior / não atualizado</small>' : '') +
      (video[metric + 'Error'] ? '<small class="views-warning">' + escape(video[metric + 'Error']) + '</small>' : '') + '</td>';
  }
  function error(message) {
    // The connection form and the library now live on separate screens.
    for (const id of ['views-error', 'views-config-error']) { el(id).hidden = !message; el(id).textContent = message || ''; }
  }
  async function request(path, body) {
    const response = await fetch('/api/views' + path, { method: body === undefined ? 'GET' : 'POST', headers: { 'x-publisher-key': key, 'content-type': 'application/json' }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    const result = await response.json();
    if (response.status === 401) { location.assign('/login'); throw new Error('Entre novamente no Autofy.'); }
    if (!response.ok) throw new Error(result.error || 'Falha ao consultar views.');
    return result;
  }
  function controls() {
    el('views-save').disabled = saving || !data || data.changing;
    el('views-disconnect').disabled = saving || !data?.tokenConfigured || data.changing;
    el('views-refresh').disabled = saving || !data?.enabled || !data?.tokenConfigured || data.running || data.changing || data.authBlocked || Boolean(data.retryAt);
    el('views-token').disabled = saving || !data?.canSetToken;
    el('views-version').disabled = saving; el('views-enabled').disabled = saving;
    if (data?.operation?.running) { el('views-save').disabled = true; el('views-disconnect').disabled = true; }
    topControls();
  }
  function render(result) {
    data = result; controls();
    const operation = data.operation;
    el('views-operation-status').textContent = operation?.running ? (operation.mode === 'download' ? 'Baixando do Facebook…' : 'Republicando na própria Página…') : operation?.results?.length ? 'Lote encerrado: ' + operation.results.filter(r => r.status === 'downloaded').length + ' baixado(s), ' + operation.results.filter(r => ['views_sent','views_posted'].includes(r.status)).length + ' envio(s), ' + operation.results.filter(r => ['failed','uncertain'].includes(r.status)).length + ' ocorrência(s).' : '';
    el('views-operation-log').hidden = !operation?.logs?.length;
    el('views-operation-log').textContent = (operation?.logs || []).map(row => row.at + '  ' + row.message).join('\n');
    if (!editing) { el('views-version').value = data.apiVersion; el('views-enabled').checked = data.enabled; }
    el('views-token-state').textContent = data.tokenConfigured ? 'Token salvo. Deixe vazio para manter.' : 'Ainda não configurado.';
    el('views-local-note').textContent = data.canSetToken ? 'O token é enviado à Meta por HTTPS e guardado somente no servidor. Proteja a pasta data: ela contém credenciais.' : 'Cadastre ou troque o token no próprio notebook, acessando 127.0.0.1 na porta do Autofy. O envio de tokens pela rede HTTP está bloqueado; consultar views por aqui funciona normalmente.';
    el('views-page-count').textContent = number(data.stats.pages); el('views-video-count').textContent = number(data.stats.videos);
    el('views-known-count').textContent = number(data.stats.withViews); el('views-stale-count').textContent = number(data.stats.stale);
    const status = data.running ? data.current || 'Consultando Meta…' : !data.enabled ? 'Atualização pausada.' : data.authBlocked ? 'Atualização bloqueada: confira o token.' : 'Aguardando próxima consulta.';
    el('views-status').textContent = (data.user?.name ? data.user.name + ' · ' : '') + status + ' Último ciclo concluído: ' + date(data.lastFinishedAt) + (data.nextAt ? ' · Próximo: ' + date(data.nextAt) : '');
    error([data.error, data.user?.warning].filter(Boolean).join(' '));
    const selected = el('views-page').value;
    el('views-page').innerHTML = '<option value="">Todas as Páginas</option>' + data.pages.map(p => '<option value="' + escape(p.id) + '">' + escape(p.name) + ' (' + p.videoCount + ')</option>').join('');
    if (data.pages.some(p => p.id === selected)) el('views-page').value = selected;
    el('views-pages').innerHTML = data.pages.map(p => '<div class="views-page-diagnostic"><b>' + escape(p.name) + '</b><span>' + escape(p.error || (p.scanComplete ? p.videoCount + ' vídeo(s) · ' + date(p.updatedAt) : 'Consulta ainda não concluída')) + '</span></div>').join('') || '<p class="hint">Nenhuma Página consultada ainda.</p>';
    el('views-rows').innerHTML = data.videos.map(v => '<tr><td><a href="' + escape(v.url) + '" target="_blank" rel="noreferrer noopener">' + escape(v.title) + '</a><small>' + escape(v.pageName) + ' · ' + (v.type === 'reel' ? 'Reel' : 'Vídeo') + ' · ID ' + escape(v.id) + '</small>' + (v.present === false ? '<small class="views-warning">Não retornado pela Meta nesta consulta</small>' : '') + '</td><td>' + date(v.createdAt) + '</td><td><strong>' + number(v.views) + '</strong><small>' + escape(v.metricLabel || 'Métrica indisponível') + '</small></td>' + engagementCell(v, 'likes') + engagementCell(v, 'comments') + '<td>' + date(v.lastSuccessAt) + (v.stale ? '<small class="views-warning">' + (v.views == null ? 'Sem dados' : 'Valor anterior / não atualizado') + '</small>' : '') + (v.error ? '<small class="views-warning">' + escape(v.error) + '</small>' : '') + '</td></tr>').join('') || '<tr><td colspan="6">Nenhum vídeo neste filtro. Configure a conexão e aguarde a consulta inicial.</td></tr>';
    el('views-result-count').textContent = data.total ? 'Exibindo ' + (data.offset + 1) + '–' + Math.min(data.offset + data.limit, data.total) + ' de ' + number(data.total) + ' vídeo(s)' : 'Nenhum vídeo listado.';
    el('views-prev').disabled = offset === 0; el('views-next').disabled = offset + data.limit >= data.total;
    topAuto();
  }
  async function load() {
    const serial = ++sequence;
    const invalid = dateError();
    el('views-filter-error').textContent = invalid; el('views-filter-error').hidden = !invalid;
    el('views-clear-dates').disabled = !el('views-date-from').value && !el('views-date-to').value;
    if (invalid) {
      el('views-rows').innerHTML = '<tr><td colspan="6">Corrija o intervalo de datas para consultar os vídeos.</td></tr>';
      el('views-result-count').textContent = ''; el('views-prev').disabled = true; el('views-next').disabled = true; return;
    }
    const query = new URLSearchParams({ pageId: el('views-page').value, search: el('views-search').value, sort: el('views-sort').value, ...dateCriteria(), offset, ...(topIsMain() ? {} : { account: topAccount }) });
    try { const result = await request('?' + query); if (serial === sequence) render(result); }
    catch (cause) { if (serial === sequence) error(cause.message); }
  }
  // Só consulta com frequência nas telas de Views e Melhores vídeos (ou com lote rodando); nas outras, a cada 60 s.
  let pollGen = 0;
  async function poll(gen = ++pollGen) {
    const here = ['#views', '#melhores'].includes(location.hash);
    if (here || data?.operation?.running || !data) await load();
    if (gen !== pollGen) return;   // outra consulta começou no meio: só uma fila de consultas
    timer = setTimeout(() => poll(gen), data?.operation?.running ? 2000 : !here || document.hidden ? 60000 : data?.running ? 5000 : 15000);
  }
  window.addEventListener('hashchange', () => { if (['#views', '#melhores'].includes(location.hash)) { clearTimeout(timer); void poll(); } });
  el('views-stop').onclick = async () => { try { await request('/stop', withAccount({})); await load(); } catch (cause) { topError(cause.message); } };
  for (const id of ['views-token', 'views-version', 'views-enabled']) el(id).addEventListener('input', () => { editing = true; });
  el('views-save').onclick = async () => {
    saving = true; controls(); error('Validando conexão…');
    try {
      await request('/settings', { token: el('views-token').value, apiVersion: el('views-version').value.trim(), enabled: el('views-enabled').checked });
      topReset();
      el('views-token').value = ''; editing = false; await load();
      if (data?.tokenConfigured) el('views-setup').open = false;
    } catch (cause) { error(cause.message); }
    finally { saving = false; controls(); }
  };
  el('views-disconnect').onclick = async () => {
    saving = true; controls();
    try { await request('/disconnect', {}); topReset(); el('views-token').value = ''; editing = false; await load(); }
    catch (cause) { error(cause.message); } finally { saving = false; controls(); }
  };
  el('views-refresh').onclick = async () => {
    saving = true; controls();
    try { await request('/refresh', {}); await load(); }
    catch (cause) { error(cause.message); } finally { saving = false; controls(); }
  };
  el('views-search').oninput = () => { clearTimeout(searchTimer); searchTimer = setTimeout(() => { offset = 0; void load(); }, 300); };
  for (const id of ['views-page', 'views-sort']) el(id).onchange = () => { offset = 0; void load(); };
  for (const id of ['views-date-from', 'views-date-to']) {
    el(id).oninput = () => { ++sequence; };
    el(id).onchange = () => { offset = 0; void load(); };
  }
  el('views-clear-dates').onclick = () => { el('views-date-from').value = ''; el('views-date-to').value = ''; offset = 0; void load(); };
  el('views-prev').onclick = () => { offset = Math.max(0, offset - 100); void load(); };
  el('views-next').onclick = () => { offset += 100; void load(); };

  // ===== Painel: os 3 melhores vídeos de cada Página (só com 1.500 plays ou mais) =====
  // Fonte: Analytics do Miwra (plays acumulados), filtrado pela data de publicação do calendário.
  // Independe dos filtros da tela de Views e da leitura de views da Meta (a Meta só é usada para baixar e repostar).
  const TOP_REFRESH = 10 * 60000;
  const RETRY_AFTER_ERROR = 60000;
  let topUsed = '', topRetryAt = 0, topDay = '';
  const clock = value => value && Number.isFinite(Date.parse(value)) ? new Date(value).toLocaleTimeString('pt-BR', { timeZone: 'America/Sao_Paulo', hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—';
  const day = value => value && Number.isFinite(Date.parse(value)) ? new Date(value).toLocaleDateString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : '—';
  const ago = value => { const hours = (Date.now() - Date.parse(value)) / 3600000; return !Number.isFinite(hours) ? 'sem data' : hours < 1 ? 'há menos de 1 h' : hours < 48 ? 'há ' + Math.round(hours) + ' h' : 'há ' + Math.round(hours / 24) + ' d'; };
  const saoPaulo = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Sao_Paulo', year: 'numeric', month: '2-digit', day: '2-digit' });
  const topCriteria = () => ({ dateFrom: el('top-date-from').value, dateTo: el('top-date-to').value });
  function topError(message) { el('top-error').hidden = !message; el('top-error').textContent = message || ''; }
  function topBest() {
    if (!topPlan) return [];
    // O servidor já devolve até 3 vídeos por Página (com o mínimo de plays), agrupados por Página e em ordem de posição.
    return topPlan.entries;
  }
  const topPages = () => new Set(topBest().map(v => v.pageId)).size;
  function topRender() {
    const box = el('top-pages'), list = topBest();
    if (!topPlan) {
      box.innerHTML = '<p class="empty">' + (topBusy ? 'Buscando os vídeos no Analytics do Miwra…' : 'O painel aparece aqui assim que os dados do Miwra forem carregados.') + '</p>';
    } else {
      box.innerHTML = list.map(v => '<label class="top-card' + (v.repostBlocked ? ' blocked' : '') + '"><input type="checkbox" data-key="' + escape(v.key) + '"' + (v.repostBlocked ? ' disabled' : '') + '>' +
        '<span class="top-card-page">' + (v.product ? '<span class="product-tag product-' + escape(v.product) + '">' + escape(v.product.toUpperCase()) + '</span>' : '') + '<b class="top-card-rank top-rank-' + ([2, 3].includes(v.rank) ? v.rank : 1) + '">' + (v.rank || 1) + 'º</b> ' + escape(v.pageName) + '</span><strong class="top-card-views">' + number(v.views) + '</strong><span class="top-card-label">plays</span>' +
        '<span class="top-card-title">' + escape(v.title || '(sem título)') + '</span>' +
        '<small>Publicado em ' + day(v.createdAt) + ' · dados ' + ago(v.lastSuccessAt) + '</small>' +
        '<small>ID ' + escape(v.id) + '</small>' + (v.repostBlocked ? '<small class="top-card-today">' + (v.repostToday?.uncertain ? 'Envio de hoje com resultado incerto' + (v.repostToday.at ? ' (' + clock(v.repostToday.at).slice(0, 5) + ')' : '') + ' · confira no Histórico' : 'Repostado hoje' + (v.repostToday?.at ? ' às ' + clock(v.repostToday.at).slice(0, 5) : '') + (v.repostToday?.method === 'api' ? ' pela API' : '')) + ' · libera à meia-noite</small>' : '') + '</label>').join('') || '<p class="empty">' + (topPlan.meta?.inRange ? 'Nenhum reel deste período chegou a ' + number(topPlan.meta.minViews || 7000) + ' plays.' : 'Nenhum reel publicado neste período.') + '</p>';
    }
    topSync();
  }
  function topSync() {
    const list = topBest(), blocked = list.filter(v => v.repostBlocked).length, meta = topPlan?.meta;
    for (const input of el('top-pages').querySelectorAll('input[data-key]')) { input.checked = topSelected.has(input.dataset.key); input.closest('.top-card').classList.toggle('selected', input.checked); }
    el('top-stat-pages').textContent = topPlan ? number(topPages()) : '—';
    el('top-stat-blocked').textContent = topPlan ? number(blocked) : '—';
    el('top-stat-selected').textContent = number(topSelected.size);
    el('top-stat-updated').textContent = clock(meta?.collectedAt);
    el('top-status').textContent = !topPlan ? '' : 'Analytics do Miwra · ' + number(meta?.inRange) + ' reel(s) no período' + (meta?.minViews ? ' · ' + number(meta.eligible) + ' com ' + number(meta.minViews) + ' plays ou mais' : '') + (meta?.truncated ? ' (leitura limitada: refine o período)' : '') + ' · conferido às ' + clock(topLoaded ? new Date(topLoaded).toISOString() : null) + ' (atualiza sozinho a cada 10 minutos)';
    const notes = [], stale = list.filter(v => v.collectError).length;
    if (topPlan?.skipped?.length) notes.push(topPlan.skipped.length + ' Página(s) com reel no período ficaram de fora por não estarem na conexão Meta do Autofy: ' + topPlan.skipped.slice(0, 5).map(s => s.pageName).join(', ') + (topPlan.skipped.length > 5 ? '…' : '') + '.');
    if (topPlan?.inactive?.length) notes.push(topPlan.inactive.length + ' Página(s) ' + (topExtras().length ? 'de outra conta, inativas ou removidas do Miwra' : 'inativas ou removidas do Miwra') + ' ficaram de fora: ' + topPlan.inactive.slice(0, 5).join(', ') + (topPlan.inactive.length > 5 ? '…' : '') + '.');
    if (stale) notes.push(stale + ' dos vídeos abaixo são de Páginas com erro de coleta no Miwra: os plays delas podem estar parados.');
    el('top-notes').textContent = notes.join(' '); el('top-notes').hidden = !notes.length;
    topControls();
  }
  function topControls() {
    const busy = working || topBusy || data?.publisherBusy, count = topSelected.size;
    el('top-select-all').disabled = busy || !topPlan || !topBest().some(v => !v.repostBlocked);
    for (const rank of [1, 2, 3]) el('top-select-' + rank).disabled = busy || !topPlan || !topBest().some(v => !v.repostBlocked && (v.rank || 1) === rank);
    el('top-clear').disabled = busy || !count;
    el('top-refresh').disabled = busy;
    for (const [id, label] of [['top-publish', 'Repostar pelo Chrome'], ['top-publish-ads', 'Repostar pelo AdsPower'], ['top-publish-api', 'Repostar pela API']]) { el(id).disabled = busy || !topPlan || !count; el(id).textContent = count ? label + ' (' + count + ')' : label; }
    if (!topIsMain()) { el('top-publish-ads').disabled = true; el('top-publish-ads').title = 'As contas extras repostam pelo Chrome delas ou pela API.'; } else el('top-publish-ads').title = 'Reposta numa aba do perfil do AdsPower, com o proxy dele';
    el('top-selected-label').textContent = count ? count + ' vídeo(s) selecionado(s) em ' + new Set([...topSelected].map(k => k.split(':')[0])).size + ' Página(s)' : 'Nenhum vídeo selecionado';
    const short = text => text ? (text.length > 60 ? text.slice(0, 60) + '…' : text) : 'vazia';
    // Descrição dos Melhores vídeos (caixa desta tela; sem salvar ainda, a de Publicações).
    const capEd = String(settings.topCaption ?? settings.caption ?? ''), capWl = String(settings.topCaptionWl ?? settings.captionWl ?? '');
    el('top-caption').textContent = !topPlan ? '' : capEd === capWl ? 'Descrição (ED e WL): ' + (capEd ? short(capEd) : 'nenhuma') : 'Descrição ED: ' + short(capEd) + ' · WL: ' + short(capWl);
    el('views-stop').disabled = !data?.operation?.running;
  }
  async function topAnalyze(force = false) {
    if (topBusy || working || data?.publisherBusy) return;
    const criteria = topCriteria(), signature = JSON.stringify(criteria), invalid = dateError(criteria);
    if (invalid) { topError(invalid); return; }
    topBusy = true; topControls(); if (!topPlan) topRender();
    try {
      const asked = topAccount;
      const result = await request('/prepare-miwra', withAccount({ ...criteria, force }));
      if (asked !== topAccount) return; // trocou de conta durante a leitura: descarta
      if (signature !== JSON.stringify(topCriteria())) return; // o calendário mudou durante a leitura: descarta
      topLoaded = Date.now(); topUsed = signature; topRetryAt = 0; topError('');
      const sig = JSON.stringify(result.entries.map(v => [v.key, v.views, v.repostBlocked, v.rank, v.repostToday?.at]));
      topPlan = result;
      const valid = new Set(topBest().filter(v => !v.repostBlocked).map(v => v.key)); topSelected = new Set([...topSelected].filter(k => valid.has(k)));
      if (sig !== topSig) { topSig = sig; topRender(); } else topSync(); // sem mudanças: não redesenha, a tela não se mexe
    } catch (cause) {
      if (!/Aguarde o lote atual/.test(cause.message)) { topError(cause.message); topRetryAt = Date.now() + RETRY_AFTER_ERROR; }
    } finally { topBusy = false; topControls(); if (topUsed !== JSON.stringify(topCriteria()) && Date.now() >= topRetryAt) setTimeout(topAuto, 0); }
  }
  function topAuto() {
    const running = Boolean(data?.operation?.running);
    if (wasRunning && !running) topLoaded = 0; // lote terminou: reanalisa para marcar o que foi repostado
    // Virou o dia em São Paulo: os reposts de ontem deixam de bloquear; refaz a lista e limpa a seleção.
    const today = saoPaulo.format(new Date());
    if (topDay && topDay !== today) { topLoaded = 0; topSelected.clear(); }
    topDay = today;
    wasRunning = running;
    if (location.hash !== '#melhores' || working || topBusy || running || Date.now() < topRetryAt) return; // só consulta o Miwra com a aba aberta
    if (topPlan && topUsed === JSON.stringify(topCriteria()) && Date.now() - topLoaded < TOP_REFRESH) { topSync(); return; }
    void topAnalyze();
  }
  function topReset() { topPlan = null; topSig = ''; topSelected.clear(); topLoaded = 0; topRender(); setTimeout(topAuto, 300); }
  function topDatesChanged() { topSelected.clear(); topPlan = null; topSig = ''; topUsed = ''; topRetryAt = 0; topError(''); topRender(); void topAnalyze(); }
  // browser: 'chrome' (Chrome do Autofy) ou 'adspower'; só vale para method 'chrome'.
  async function topStart(method = 'chrome', browser) {
    if (topBusy || working || data?.publisherBusy || !topSelected.size) return;
    if (browser === 'adspower' && !settings.adsPowerUserId) { topError('Informe o ID do perfil do AdsPower em Configurações → Navegador e salve antes de repostar por ele.'); return; }
    const keys = [...topSelected], pages = new Set(keys.map(k => k.split(':')[0])).size;
    if (!topIsMain() && method !== 'api') browser = 'chrome';
    if (!confirm('Repostar ' + keys.length + ' vídeo(s) em ' + pages + ' Página(s) da conta ' + topAccountName() + ' agora, ' + (method === 'api' ? 'pela API da Meta (sem Chrome)' : browser === 'adspower' ? 'pelo AdsPower (aba dentro do perfil, com o proxy dele)' : topIsMain() ? 'pelo Chrome do Autofy' : 'pelo Chrome desta conta') + '?\n\nCada vídeo volta para a própria Página, com a descrição salva em Publicações. Isso publica de verdade, sem outra confirmação.')) return;
    working = true; topControls(); topError('');
    try {
      // Refaz o ranking logo antes de enviar, para usar um plano válido e o histórico de hoje.
      const criteria = topCriteria(), result = await request('/prepare-miwra', withAccount(criteria)), byKey = new Map(result.entries.map(v => [v.key, v]));
      const lost = keys.filter(k => !byKey.has(k) || byKey.get(k).repostBlocked);
      if (lost.length) {
        topPlan = result; topLoaded = Date.now(); topUsed = JSON.stringify(criteria); topSig = ''; topSelected = new Set(keys.filter(k => !lost.includes(k))); topRender();
        throw new Error(lost.length + ' vídeo(s) da seleção mudaram ou já foram republicados hoje. A lista foi atualizada; confira e clique novamente. Nada foi enviado.');
      }
      const started = await request('/start', withAccount({ mode: 'publish', planId: result.id, keys, method, ...(method === 'api' ? {} : { browser }) }));
      // O navegador escolhido passa a ser o do painel (mesmo destaque dos botões Abrir Facebook).
      if (topIsMain() && method !== 'api' && started?.browser) { settings.browser = started.browser; browserChoice(); }
      topSelected.clear(); topSync(); await load(); clearTimeout(timer); timer = setTimeout(poll, 1000);
    } catch (cause) { topError(cause.message); } finally { working = false; topControls(); }
  }
  el('top-clear').onclick = () => { topSelected.clear(); topSync(); };
  el('top-select-all').onclick = () => { for (const v of topBest()) if (!v.repostBlocked) topSelected.add(v.key); topSync(); };
  for (const rank of [1, 2, 3]) el('top-select-' + rank).onclick = () => { topSelected.clear(); for (const v of topBest()) if (!v.repostBlocked && (v.rank || 1) === rank) topSelected.add(v.key); topSync(); };
  el('top-refresh').onclick = () => { void topAnalyze(true); };
  el('top-pages').onchange = event => { const key = event.target.dataset.key; if (!key) return; if (event.target.checked) topSelected.add(key); else topSelected.delete(key); topSync(); };
  el('top-publish').onclick = () => { void topStart('chrome', 'chrome'); };
  el('top-publish-ads').onclick = () => { void topStart('chrome', 'adspower'); };
  el('top-publish-api').onclick = () => { void topStart('api'); };
  for (const id of ['top-date-from', 'top-date-to']) el(id).onchange = topDatesChanged;
  for (const button of document.querySelectorAll('[data-top-days]')) button.onclick = () => {
    const days = Number(button.dataset.topDays);
    el('top-date-from').value = days ? saoPaulo.format(new Date(Date.now() - (days - 1) * 86400000)) : '';
    el('top-date-to').value = days ? saoPaulo.format(new Date()) : '';
    topDatesChanged();
  };
  // ===== Programação diária dos melhores vídeos (por conta da aba) =====
  let tsData = null, tsDraft = null, tsDirty = false, tsFor = '';
  const tsAccount = () => topIsMain() ? 'main' : topAccount;
  const tsWhen = value => value ? new Date(value).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).replace(', ', ' às ') : '';
  function tsRender() {
    const rows = tsDraft || [], main = tsAccount() === 'main', periods = tsData?.periods || { all: 'Todo o período', 30: 'Últimos 30 dias', 7: 'Últimos 7 dias' };
    const methods = main ? { chrome: 'Chrome do Autofy', adspower: 'AdsPower', api: 'API da Meta' } : { chrome: 'Chrome desta conta', api: 'API da Meta' };
    const option = (list, value) => Object.entries(list).map(([k, label]) => '<option value="' + escape(k) + '"' + (String(value) === k ? ' selected' : '') + '>' + escape(label) + '</option>').join('');
    el('ts-rows').innerHTML = rows.map((row, index) => '<div class="ts-row" data-index="' + index + '">'
      + '<label>Horário<input class="ts-time" type="time" value="' + escape(row.time || '09:00') + '"></label>'
      + '<label>Posição<select class="ts-rank">' + option({ 1: '1º (top 1)', 2: '2º', 3: '3º' }, row.rank || 1) + '</select></label>'
      + '<label>Ranking de<select class="ts-period">' + option(periods, row.period ?? 'all') + '</select></label>'
      + '<label>Repostar pelo<select class="ts-method">' + option(methods, row.method || 'chrome') + '</select></label>'
      + '<label class="check-line"><input class="ts-enabled" type="checkbox"' + (row.enabled !== false ? ' checked' : '') + '> Ligado</label>'
      + '<button class="ts-run" type="button"' + (row.id && !tsDirty ? '' : ' disabled title="Salve antes de testar"') + '>Testar agora</button>'
      + '<button class="ts-remove danger" type="button">Remover</button>'
      + '<p class="ts-last' + (row.last ? ' ts-' + escape(row.last.status) : '') + '">' + (row.next ? 'Próxima: ' + escape(tsWhen(row.next)) + '. ' : row.enabled === false ? 'Desligado. ' : '') + (row.last ? 'Último: ' + escape(row.last.message) + ' (' + escape(tsWhen(row.last.at)) + ')' : row.id ? 'Ainda não rodou.' : 'Novo: clique em Salvar programação.') + '</p>'
      + '</div>').join('') || '<p class="hint">Nenhum horário programado para ' + escape(topAccountName()) + '.</p>';
    el('ts-add').disabled = rows.length >= (tsData?.max || 4);
    el('ts-save').disabled = !tsDirty;
    const others = (tsData?.others || []).map(item => item.account + ' às ' + item.time + ' (' + item.rank + 'º)');
    el('ts-state').textContent = (tsDirty ? 'Alterações não salvas. ' : '') + (others.length ? 'Outras contas: ' + others.join(', ') + '.' : '');
  }
  function tsCollect() {
    tsDraft = [...el('ts-rows').querySelectorAll('.ts-row')].map(box => ({ ...(tsDraft[Number(box.dataset.index)] || {}), time: box.querySelector('.ts-time').value, rank: Number(box.querySelector('.ts-rank').value), period: box.querySelector('.ts-period').value, method: box.querySelector('.ts-method').value, enabled: box.querySelector('.ts-enabled').checked }));
  }
  async function tsLoad(force = false) {
    if (location.hash !== '#melhores' || (tsDirty && !force && tsFor === tsAccount())) return;
    try {
      const account = tsAccount(), result = await api('top-schedule?account=' + encodeURIComponent(account));
      if (account !== tsAccount()) return;
      tsData = result; tsFor = account;
      if (!tsDirty || force) { tsDraft = result.rows.map(row => ({ ...row })); tsDirty = false; }
      tsRender();
    } catch (cause) { el('ts-state').textContent = 'Não foi possível ler a programação: ' + cause.message; }
  }
  el('ts-rows').addEventListener('input', () => { tsCollect(); tsDirty = true; el('ts-save').disabled = false; el('ts-state').textContent = 'Alterações não salvas.'; });
  el('ts-rows').addEventListener('click', event => {
    const button = event.target.closest('button'), box = button?.closest('.ts-row'); if (!box) return;
    tsCollect();
    if (button.classList.contains('ts-remove')) { tsDraft.splice(Number(box.dataset.index), 1); tsDirty = true; tsRender(); return; }
    if (button.classList.contains('ts-run')) {
      const row = tsDraft[Number(box.dataset.index)];
      if (!confirm('Testar agora o top ' + row.rank + 'º de ' + topAccountName() + '?\n\nIsso reposta de verdade, agora, o vídeo ' + row.rank + 'º de cada Página desta conta.')) return;
      button.disabled = true; el('ts-state').textContent = 'Começando…';
      api('top-schedule/run', { id: row.id }).then(result => { tsData = result; tsDraft = result.rows.map(item => ({ ...item })); tsDirty = false; tsRender(); void load(); })
        .catch(cause => { el('ts-state').textContent = cause.message; button.disabled = false; });
    }
  });
  el('ts-add').onclick = () => { if (tsDraft) tsCollect(); else tsDraft = []; tsDraft.push({ time: '09:00', rank: 1, period: 'all', method: tsAccount() === 'main' ? 'chrome' : 'chrome', enabled: true }); tsDirty = true; tsRender(); };
  el('ts-save').onclick = async () => {
    tsCollect(); el('ts-save').disabled = true;
    try { tsData = await api('top-schedule/save', { account: tsAccount(), rows: tsDraft }); tsDraft = tsData.rows.map(row => ({ ...row })); tsDirty = false; tsRender(); el('ts-state').textContent = 'Programação salva.'; }
    catch (cause) { el('ts-state').textContent = cause.message; el('ts-save').disabled = false; }
  };
  setInterval(() => { void tsLoad(); }, 30000);

  // Abas das contas (só aparecem com conta extra cadastrada).
  let topEffective = null;
  function topTabs() {
    const extras = topExtras();
    // As configurações chegam depois desta tela: se a conta efetiva mudou, a lista anterior não vale.
    const effective = topIsMain() ? 'main' : topAccount;
    if (topEffective !== null && topEffective !== effective) { topPlan = null; topSig = ''; topUsed = ''; topLoaded = 0; topSelected.clear(); topRender(); setTimeout(topAuto, 0); tsDirty = false; void tsLoad(true); }
    topEffective = effective;
    if (!topIsMain() && !extras.some(item => item.id === topAccount)) topAccount = 'main';
    el('top-acct-bar').hidden = !extras.length;
    if (!extras.length) return;
    const list = [{ id: 'main', main: true }, ...extras];
    const html = list.map(item => '<button type="button" role="tab" data-account="' + escape(item.id) + '" aria-selected="' + (item.id === (topIsMain() ? 'main' : topAccount)) + '" class="acct-tab"><b>' + escape(typeof accountName === 'function' ? accountName(item.id) : item.name || item.id) + '</b><small>' + (item.main ? 'principal' : 'conta extra') + '</small></button>').join('');
    if (el('top-tabs').dataset.sig !== html) { el('top-tabs').innerHTML = html; el('top-tabs').dataset.sig = html; }
    el('top-acct-hint').textContent = topIsMain() ? 'Conta principal: Páginas dela, token da Conexão com a Meta e o Chrome do Autofy (ou o AdsPower).' : 'Conta ' + topAccountName() + ': só as Páginas dela, baixadas e repostadas com o token e o Chrome desta conta (ou pela API com o token dela).';
  }
  el('top-tabs').addEventListener('click', event => {
    const button = event.target.closest('button[data-account]');
    if (!button || button.dataset.account === topAccount || working) return;
    topAccount = button.dataset.account; try { localStorage.setItem('jsautopost-melhores-conta', topAccount); } catch {}
    topPlan = null; topSig = ''; topUsed = ''; topLoaded = 0; topRetryAt = 0; topSelected.clear(); topError(''); topTabs(); topRender();
    tsDirty = false; tsDraft = null; tsData = null; tsRender(); void tsLoad(true);
    void load().then(() => topAnalyze());
  });
  setInterval(() => { if (location.hash === '#melhores') topTabs(); }, 2000);
  window.addEventListener('hashchange', () => { topTabs(); topAuto(); void tsLoad(); });
  topTabs();
  topRender();
  void tsLoad(true);

  window.addEventListener('pagehide', () => { clearTimeout(timer); clearTimeout(searchTimer); });
  void poll();
})();

// Descrição e comentário dos Melhores vídeos: textos próprios desta tela (começam iguais aos de
// Publicações). Ficam em settings.top*, salvos pela mesma rota dos textos da API.
(() => {
  const el = id => document.getElementById(id);
  const FIELDS = [['tt-caption-ed', 'topCaption', 'caption'], ['tt-caption-wl', 'topCaptionWl', 'captionWl'], ['tt-comment-ed', 'topComment', 'comment'], ['tt-comment-wl', 'topCommentWl', 'commentWl']];
  let dirty = false, saving = false, sig = '';
  const saved = () => ({ ...Object.fromEntries(FIELDS.map(([, key, fallback]) => [key, String(settings[key] ?? settings[fallback] ?? '')])),
    topCommentOn: (settings.topCommentOn ?? settings.pinComment) === true, topCommentScope: settings.topCommentScope ?? settings.commentScope ?? 'new', topCommentMaxDays: Number(settings.topCommentMaxDays ?? settings.commentMaxDays ?? 7) });
  const daysView = () => { const all = el('tt-comment-scope').value === 'all'; el('tt-comment-days-box').hidden = all; el('tt-comment-scope-help').hidden = all; };
  const state = text => { el('tt-state').textContent = text; };
  function fill() {
    if (dirty || saving || !settings || !('appVersion' in settings)) return;
    const values = saved(), next = JSON.stringify(values);
    if (next === sig) return;
    sig = next;
    for (const [id, key] of FIELDS) el(id).value = values[key];
    el('tt-comment-on').checked = values.topCommentOn; el('tt-comment-scope').value = values.topCommentScope === 'all' ? 'all' : 'new'; el('tt-comment-days').value = String(values.topCommentMaxDays || 7);
    daysView();
  }
  for (const id of ['tt-caption-ed', 'tt-caption-wl', 'tt-comment-ed', 'tt-comment-wl', 'tt-comment-on', 'tt-comment-scope', 'tt-comment-days']) {
    el(id).addEventListener(el(id).tagName === 'TEXTAREA' || el(id).type === 'number' ? 'input' : 'change', () => { dirty = true; state('Alterações não salvas. Os botões Repostar e a programação usam os textos salvos.'); daysView(); });
  }
  el('tt-save').onclick = guarded(async () => {
    const days = Number(el('tt-comment-days').value);
    if (!Number.isInteger(days) || days < 1 || days > 365) throw new Error('O limite de dias para comentar deve ficar entre 1 e 365.');
    const body = { ...Object.fromEntries(FIELDS.map(([id, key]) => [key, el(id).value])), topCommentOn: el('tt-comment-on').checked, topCommentScope: el('tt-comment-scope').value, topCommentMaxDays: days };
    saving = true; el('tt-save').disabled = true; state('Salvando…');
    try {
      const result = await api('api-post/texts', body);
      for (const key of Object.keys(body)) settings[key] = result[key];
      dirty = false; sig = ''; state('Textos dos Melhores vídeos salvos.');
    } catch (cause) { state('Não salvou: ' + cause.message); throw cause; }
    finally { saving = false; el('tt-save').disabled = false; fill(); }
  });
  setInterval(fill, 1000); fill();
})();
