// Botão "Atualizar" do topo: aparece quando há versão nova publicada; baixa, instala e reabre o Autofy.
(() => {
  const button = document.querySelector('#update-app');
  if (!button) return;
  const key = document.querySelector('meta[name=publisher-key]').content;
  const call = async (path, method = 'GET') => {
    const response = await fetch('/api/update' + path, { method, headers: { 'x-publisher-key': key, 'content-type': 'application/json' }, ...(method === 'POST' ? { body: '{}' } : {}) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Falha na comunicação.');
    return data;
  };
  let available = null, installing = false;
  const show = report => {
    if (installing) return;
    available = report.available;
    button.hidden = !available;
    if (available) {
      button.textContent = 'Atualizar para ' + available.version;
      button.title = 'Autofy ' + available.version + ' disponível (você está na ' + report.current + ').' + (available.notes ? '\n\n' + available.notes : '');
    }
  };
  const refresh = () => call('').then(show).catch(() => {});
  button.onclick = async () => {
    if (!available || installing) return;
    const notes = available.notes ? '\n\nO que mudou:\n' + available.notes : '';
    if (!confirm('Atualizar o Autofy para a versão ' + available.version + '?' + notes + '\n\nO Autofy baixa a versão nova, confere os arquivos e reabre sozinho em alguns segundos. Contas, tokens e configurações continuam salvos.')) return;
    installing = true;
    button.disabled = true;
    button.textContent = 'Baixando ' + available.version + '…';
    try {
      const result = await call('/install', 'POST');
      for (let id = setInterval(() => {}, 1e9); id >= 0; id--) { clearInterval(id); clearTimeout(id); }
      document.title = 'Autofy atualizado';
      document.body.className = '';
      const main = document.createElement('main');
      main.className = 'shutdown-screen';
      for (const [tag, text] of [['h1', 'Autofy atualizado para ' + result.version], ['p', 'O Autofy está reabrindo e o painel novo abre sozinho em uma nova aba em alguns segundos. Pode fechar esta.'], ['p', 'Se não abrir em 1 minuto, clique no ícone Autofy.']]) {
        const item = document.createElement(tag); item.textContent = text; main.append(item);
      }
      document.body.replaceChildren(main);
    } catch (error) {
      installing = false;
      button.disabled = false;
      button.textContent = 'Atualizar para ' + available.version;
      alert('Não foi possível atualizar agora.\n\n' + error.message);
    }
  };
  refresh();
  setInterval(refresh, 30 * 60 * 1000);
})();
