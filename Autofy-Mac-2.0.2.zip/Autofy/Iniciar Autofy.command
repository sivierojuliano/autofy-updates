#!/bin/bash
umask 077

if [ "$(uname -s)" != "Darwin" ]; then
  printf '%s\n' 'Este iniciador é somente para macOS.' >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)" || exit 1
unset NODE_OPTIONS NODE_PATH PORT

NODE_BIN="$(command -v node 2>/dev/null)"
if [ -z "$NODE_BIN" ] || [ ! -x "$NODE_BIN" ]; then
  NODE_BIN=''
  for NODE_CANDIDATE in /usr/local/bin/node /opt/homebrew/bin/node; do
    if [ -x "$NODE_CANDIDATE" ]; then
      NODE_BIN="$NODE_CANDIDATE"
      break
    fi
  done
fi

if [ -z "$NODE_BIN" ]; then
  printf '%s\n' \
    'Node.js não encontrado. Instale o Node.js 24 LTS pelo site oficial:' \
    'https://nodejs.org/en/download' \
    'Depois siga LEIA-ME-PRIMEIRO.txt e tente novamente.' >&2
  exit 1
fi

if [ ! -f "$SCRIPT_DIR/start.mjs" ]; then
  printf '%s\n' 'start.mjs não encontrado. Extraia o ZIP completo e mantenha os arquivos juntos.' >&2
  exit 1
fi

exec "$NODE_BIN" "$SCRIPT_DIR/start.mjs"
