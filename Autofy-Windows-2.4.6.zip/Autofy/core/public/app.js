const $ = selector => document.querySelector(selector);
const key = $('meta[name=publisher-key]').content;
let settings = {}, rows = [], loaded = false, dirty = false, running = false, syncing = false, importing = false, wasRunning = false, compatible = false;
let slotSaving = false, slotUnsaved = false;
let publicationDate = '', verifiedContext = null, dateLoading = false;
// Conta de Facebook mostrada em Publicações (e usada por Postar por API): 'main' ou o id de uma extra.
let currentAccount = 'main', accountsInfo = [], anyRunning = false;
try { currentAccount = localStorage.getItem('jsautopost-conta') || 'main'; } catch {}
const accountParam = () => 'account=' + encodeURIComponent(currentAccount);
function accountName(id = currentAccount) { return id === 'main' ? (settings.mainName || (settings.profile && !/[;*]/.test(settings.profile) ? settings.profile : 'Conta principal')) : (settings.accounts || []).find(item => item.id === id)?.name || id; }
// Navegadores anti-detect: o perfil é aberto pela API local do aplicativo (só da conta principal).
const PERFIS = { adspower: 'AdsPower', incogniton: 'Incogniton' };
const nomeNavegador = browser => PERFIS[browser] || 'Chrome do Autofy';
const perfilId = browser => browser === 'adspower' ? settings.adsPowerUserId : browser === 'incogniton' ? settings.incognitonProfileId : '';
// O navegador anti-detect dos botões "(AdsPower/Incogniton)": o escolhido; senão o que tiver perfil configurado.
const perfilExterno = () => PERFIS[settings.browser] ? settings.browser : settings.incognitonProfileId && !settings.adsPowerUserId ? 'incogniton' : 'adspower';
const esc = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function notice(message) { $('#notice').hidden = !message; $('#notice').textContent = message || ''; }
async function api(path,body) {
  const response = await fetch('/api/'+path,{method:body===undefined?'GET':'POST',headers:{'x-publisher-key':key,'content-type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
  const data = await response.json();
  if(response.status===401){location.assign('/login');throw new Error('Entre novamente no Autofy.');}
  if(!response.ok) throw new Error(data.error || 'Falha na comunicação.');
  return data;
}
// Aviso "Carregando" por cima da tela enquanto troca de conta, sincroniza ou confere a conexão.
// Aparece só se demorar mais de 300 ms (para não piscar em operações rápidas).
const busyReasons=new Map();let busyTimer=null;
function busyOverlay(key,text){
  if(text)busyReasons.set(key,text);else busyReasons.delete(key);
  const box=document.getElementById('busy-overlay');if(!box)return;
  const current=[...busyReasons.values()].pop();
  if(!current){clearTimeout(busyTimer);busyTimer=null;box.hidden=true;return;}
  document.getElementById('busy-text').textContent=current;
  if(box.hidden&&!busyTimer)busyTimer=setTimeout(()=>{busyTimer=null;if(busyReasons.size)box.hidden=false;},300);
}
window.busyOverlay=busyOverlay;
let syncQuiet=false;
// Programação por calendário: escolher vários dias para a mesma linha (horário + slot). Usado nas
// programações de Publicações e de Postar por API. Datas no fuso de São Paulo, até 93 dias à frente.
const scheduleDays=(()=>{
  const MAX=93, WEEK=['D','S','T','Q','Q','S','S'], MONTHS=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  const iso=(y,m,d)=>new Date(Date.UTC(y,m,d)).toISOString().slice(0,10);
  const addDays=(day,n)=>{const [y,m,d]=day.split('-').map(Number);return iso(y,m-1,d+n);};
  const short=day=>day.slice(8,10)+'/'+day.slice(5,7);
  const weekday=day=>{const [y,m,d]=day.split('-').map(Number);return new Date(Date.UTC(y,m-1,d)).getUTCDay();};
  const summary=dates=>!dates.length?'Só a próxima vez':dates.length===1?'Só em '+short(dates[0]):dates.length+' dias · de '+short(dates[0])+' a '+short(dates[dates.length-1]);
  const get=box=>{try{return JSON.parse(box.dataset.dates||'[]');}catch{return [];}};
  const set=(box,dates)=>{const list=[...new Set(dates||[])].sort();box.dataset.dates=JSON.stringify(list);const text=box.querySelector('.schedule-days-text');if(text)text.textContent=summary(list);box.classList.toggle('has-days',list.length>0);};
  const html=()=>'<div class="schedule-days-box"><button class="schedule-days" type="button"><svg class="icon" aria-hidden="true"><use href="#icon-calendar"></use></svg>Dias no calendário</button><small class="schedule-days-text">Só a próxima vez</small></div>';
  // Hoje, se o horário já passou, não roda mais: some da conta mostrada na confirmação (o servidor também tira).
  const nowTime=()=>new Intl.DateTimeFormat('en-GB',{timeZone:'America/Sao_Paulo',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date());
  const upcoming=(dates,time)=>dates.filter(day=>day>today()||(day===today()&&time>nowTime()));
  const confirmText=(all,time,dates=upcoming(all,time))=>dates.length>1?' às '+time+' em '+dates.length+' dias (de '+short(dates[0])+' a '+short(dates[dates.length-1])+'): '+dates.slice(0,14).map(short).join(', ')+(dates.length>14?'…':''):dates.length===1?' em '+short(dates[0])+' às '+time:' às '+time;
  function pick(box,title){
    return new Promise(resolve=>{
      const start=today(),limit=addDays(start,MAX);let chosen=new Set(get(box));
      let [y,m]=start.split('-').map(Number);m-=1;
      const wrap=document.createElement('div');wrap.className='cal-backdrop';
      wrap.innerHTML='<div class="cal" role="dialog" aria-modal="true" aria-label="'+title.replace(/"/g,'')+'"><b class="cal-title">'+title+'</b><p class="hint cal-help">Clique nos dias em que esta programação deve rodar, no mesmo horário e slot. Cada dia usa os vídeos daquele dia.</p>'
        +'<div class="cal-head"><button class="cal-prev icon-button" type="button" aria-label="Mês anterior">‹</button><b class="cal-month"></b><button class="cal-next icon-button" type="button" aria-label="Próximo mês">›</button></div>'
        +'<div class="cal-week">'+WEEK.map(w=>'<span>'+w+'</span>').join('')+'</div><div class="cal-grid"></div>'
        +'<div class="cal-quick"><button type="button" data-q="7">Próximos 7 dias</button><button type="button" data-q="util">Dias úteis do mês</button><button type="button" data-q="mes">Mês inteiro</button><button type="button" data-q="limpar">Limpar</button></div>'
        +'<p class="cal-summary" role="status"></p><div class="actions cal-actions"><button class="cal-cancel" type="button">Cancelar</button><button class="cal-ok primary" type="button">Usar estes dias</button></div></div>';
      const $c=sel=>wrap.querySelector(sel);
      const monthDays=()=>{const n=new Date(Date.UTC(y,m+1,0)).getUTCDate();return Array.from({length:n},(_,i)=>iso(y,m,i+1)).filter(d=>d>=start&&d<=limit);};
      const draw=()=>{
        $c('.cal-month').textContent=MONTHS[m]+' '+y;
        const first=new Date(Date.UTC(y,m,1)).getUTCDay(),n=new Date(Date.UTC(y,m+1,0)).getUTCDate();
        let cells='';for(let i=0;i<first;i++)cells+='<span></span>';
        for(let d=1;d<=n;d++){const day=iso(y,m,d),off=day<start||day>limit;cells+='<button type="button" class="cal-day'+(chosen.has(day)?' on':'')+(day===start?' today':'')+'" data-day="'+day+'"'+(off?' disabled':'')+' aria-pressed="'+chosen.has(day)+'">'+d+'</button>';}
        $c('.cal-grid').innerHTML=cells;
        const list=[...chosen].sort();$c('.cal-summary').textContent=list.length?summary(list)+'.':'Nenhum dia marcado: a programação vale só para a próxima vez do horário.';
        $c('.cal-prev').disabled=iso(y,m,1)<=start.slice(0,8)+'01';$c('.cal-next').disabled=iso(y,m+1,1)>limit;
        $c('.cal-ok').textContent=list.length?'Usar '+list.length+' dia(s)':'Só a próxima vez';
      };
      const close=value=>{wrap.remove();document.removeEventListener('keydown',onKey);resolve(value);};
      const onKey=event=>{if(event.key==='Escape')close(null);};
      wrap.addEventListener('click',event=>{
        if(event.target===wrap)return close(null);
        const button=event.target.closest('button');if(!button||button.disabled)return;
        if(button.dataset.day){chosen.has(button.dataset.day)?chosen.delete(button.dataset.day):chosen.add(button.dataset.day);}
        else if(button.classList.contains('cal-prev')){m--;if(m<0){m=11;y--;}}
        else if(button.classList.contains('cal-next')){m++;if(m>11){m=0;y++;}}
        else if(button.dataset.q==='7'){for(let i=0;i<7;i++)chosen.add(addDays(start,i));}
        else if(button.dataset.q==='util'){monthDays().filter(d=>![0,6].includes(weekday(d))).forEach(d=>chosen.add(d));}
        else if(button.dataset.q==='mes'){monthDays().forEach(d=>chosen.add(d));}
        else if(button.dataset.q==='limpar'){chosen=new Set();}
        else if(button.classList.contains('cal-cancel'))return close(null);
        else if(button.classList.contains('cal-ok')){set(box,[...chosen]);return close([...chosen].sort());}
        draw();
      });
      document.addEventListener('keydown',onKey);
      document.body.appendChild(wrap);draw();$c('.cal-ok').focus();
    });
  }
  return {html,get,set,pick,summary,confirmText,short};
})();
window.scheduleDays=scheduleDays;
function setDirty() { dirty=true; $('#save-state').textContent='Alterações não salvas'; buttons(); }
function buttons() {
  const busy=!compatible||running||syncing||importing||slotSaving||dateLoading;
  const pending=dirty||slotUnsaved;
  const ready=rows.filter(p=>!slotChanged(p)&&p.code==='ready').length;
  for(const id of ['save','refresh','login','login-adspower']) $('#'+id).disabled=busy;
  $('#import-page-ids').disabled=busy||pending;$('#release-blocked').disabled=busy||!loaded;
  for(const id of ['test','publish']) $('#'+id).disabled=busy||pending||!loaded||!contextMatches()||!ready;
  $('#download').disabled=busy||pending||!loaded||!contextMatches()||!rows.some(p=>!slotChanged(p)&&['ready','unmapped','blocked'].includes(p.code));
  $('#stop').disabled=!running;
  document.querySelectorAll('#acct-tabs button').forEach(button=>button.disabled=syncing||importing||slotSaving||dateLoading);
  $('#acct-login').disabled=running||syncing;
  document.querySelectorAll('#setup input,#caption,#caption-wl,#pin-comment,#comment,#comment-wl,#comment-wait,#comment-scope,#comment-days,#composer,#posting-slot,#product,#add-followers,#add-hashtag,#pages input,#select-all,#source-date,#date-previous,#date-today,#repost-posted').forEach(input=>input.disabled=busy);
  $('#repost-posted').disabled=busy||!$('#source-date').value||$('#source-date').value>=publicationDate;
  busyOverlay('app',syncing&&!syncQuiet?'Carregando as Páginas de '+accountName()+'…':importing?'Buscando os IDs das Páginas…':slotSaving?'Salvando o slot…':dateLoading?'Carregando os vídeos da data…':'');
}
function videoCount(page) { return page.videoCount ?? (page.entry ? 1 : 0); }
function chosenSlot() { return Number($('#posting-slot').value) || 1; }
function slotReady(page) { return page.slots?.[chosenSlot()-1]?.ready === true; }
function slotChanged(page) { return page.postingSlot !== chosenSlot(); }
function runContext() { return {sourceDate:$('#source-date').value,publicationDate,repost:$('#repost-posted').checked}; }
function contextMatches() {
  const context=runContext();
  return verifiedContext && Object.keys(context).every(key=>context[key]===verifiedContext[key]) && verifiedContext.postingSlot===chosenSlot();
}
function renderDateState() {
  const context=runContext();$('#date-state').dataset.repost=String(context.repost);
  $('#date-state').textContent='Vídeos de '+context.sourceDate+' · publicar agora ('+publicationDate+', São Paulo). '+(context.repost?'Republicação ativada. Envios de hoje e pendências continuam bloqueados.':'Somente vídeos ainda não postados.');
}
function matchesFilter(page, filter) {
  switch (filter) {
    case 'with_video': return slotReady(page);
    case 'without_video': return !slotReady(page);
    case 'download_unavailable': return page.unavailableVideoCount > 0;
    case 'ready': return !slotChanged(page) && page.code === 'ready';
    case 'unmapped': return !settings.mappings[page.id]?.trim();
    case 'selected': return settings.selected.includes(page.id);
    case 'unchecked': return !settings.selected.includes(page.id);
    case 'inactive': return page.active === false || page.code === 'inactive';
    case 'no_slots': return page.slotCount === 0 || page.code === 'no_slots';
    case 'blocked': return page.historyBlocked || page.code === 'blocked';
    case 'excluded': return page.code !== 'ready';
    default: return true;
  }
}
function updateFilterCounts() {
  for (const option of $('#filter').options) {
    option.dataset.label ||= option.textContent;
    option.textContent = option.dataset.label + (loaded ? ' (' + rows.filter(p=>matchesFilter(p,option.value)).length + ')' : '');
  }
}
function renderSlots(page) {
  return '<div class="slot-grid" role="list" aria-label="Slots de '+esc(page.name)+'">'+(page.slots||[]).map(slot=>{
    const tone=slot.ready?'available':slot.code==='posted'?'posted':['empty','no_slot'].includes(slot.code)?'empty':'unavailable';
    return '<div class="slot-card '+tone+(slot.number===chosenSlot()?' chosen':'')+'" role="listitem"'+(slot.jobId?' title="Vídeo: '+esc(slot.jobId)+'"':'')+'><b>Slot '+slot.number+'</b><span>'+esc(slot.message)+'</span>'+(slot.number===chosenSlot()?'<small>Slot deste lote</small>':'')+'</div>';
  }).join('')+'</div>';
}
function renderPages() {
  const query=$('#search').value.trim().toLocaleLowerCase();
  const filter=$('#filter').value;
  const shown=rows.filter(p=>p.name.toLocaleLowerCase().includes(query)&&matchesFilter(p,filter));
  updateFilterCounts();
  $('#filter-summary').textContent=loaded?'Exibindo '+shown.length+' de '+rows.length+' Página(s) ativas · Slot '+chosenSlot()+': '+rows.filter(slotReady).length+' com vídeo · '+rows.filter(p=>!slotReady(p)).length+' sem vídeo pronto':'Sincronize para ver as quantidades.';
  $('#pages').innerHTML=shown.map(p=>'<div class="page-row"><label><span><span class="product-tag product-'+esc(p.product||'ed')+'">'+esc((p.product||'ed').toUpperCase())+'</span> '+esc(p.name)+'</span><input class="page-check" data-id="'+esc(p.id)+'" type="checkbox" '+(settings.selected.includes(p.id)?'checked':'')+' aria-label="Selecionar '+esc(p.name)+'"></label><input class="page-id" data-id="'+esc(p.id)+'" type="text" inputmode="numeric" placeholder="ID da Página no Facebook" value="'+esc(settings.mappings[p.id]||'')+'" aria-label="ID de '+esc(p.name)+'"><span class="page-status"><span class="video-state '+(slotReady(p)?'has-video':'')+'">Slot '+chosenSlot()+': '+(slotReady(p)?'vídeo pronto':'sem vídeo pronto')+'</span><span class="reason '+(!slotChanged(p)&&p.code==='ready'?'ready':'')+'">'+esc(slotChanged(p)?(slotSaving?'Atualizando o diagnóstico deste slot…':'Diagnóstico deste slot pendente.'):p.reason)+'</span></span>'+renderSlots(p)+'</div>').join('')||'<p class="empty">Nenhuma Página neste filtro.</p>';
  const count=rows.filter(p=>settings.selected.includes(p.id)).length;
  $('#select-all').checked=rows.length>0&&count===rows.length;
  $('#select-all').indeterminate=count>0&&count<rows.length;
  $('#total').textContent=loaded?rows.length:'—';
  $('#selected').textContent=loaded?count:'—';
  $('#ready').textContent=slotSaving?'Atualizando…':dirty||slotUnsaved?'Salvar…':loaded?rows.filter(p=>!slotChanged(p)&&p.code==='ready').length:'—';
  buttons();
}
async function sync(force=false,quiet=false) {
  if(syncing)return;
  syncQuiet=quiet;syncing=true;buttons();$('#pages').setAttribute('aria-busy','true');
  verifiedContext=null;
  $('#verification-state').textContent='Verificando os arquivos de cada slot… Aguarde antes de iniciar uma rodada.';
  try {
    const context=runContext(), params=new URLSearchParams(context);
    if(force)params.set('refresh','1');
    params.set('account',currentAccount);
    const data=await api('preview?'+params);
    if(!data.verifiedAt||!Array.isArray(data.pages)||data.pages.some(p=>!Array.isArray(p.slots)))throw new Error('Reinicie o servidor do Autofy para ativar a verificação de slots da versão 1.2 e atualize esta página.');
    if(data.postingSlot!==chosenSlot()||data.pages.some(slotChanged))throw new Error('O slot salvo mudou. Selecione novamente o slot desejado para recalcular as Páginas.');
    if((data.product||'all')!==$('#product').value)throw new Error('O produto da rodada mudou. Selecione novamente o produto para recalcular as Páginas.');
    if(Object.keys(context).some(key=>data[key]!==context[key]))throw new Error('A data ou o modo do lote mudou. Sincronize novamente antes de publicar.');
    verifiedContext={...context,postingSlot:data.postingSlot};renderDateState();
    rows=data.pages;loaded=true;
    const productNames={all:'Todos (ED + WL)',ed:'Somente ED',wl:'Somente WL'},counts=data.productCounts||{ed:0,wl:0};
    $('#page-info').textContent=(currentAccount!=='main'?accountName()+' · perfil ':'')+data.profile+' · '+data.date+' · '+productNames[data.product||'all']+' · '+data.total+' Página(s) ativas no Miwra';
    $('#product-state').textContent='Páginas ativas no Miwra: '+counts.ed+' de ED e '+counts.wl+' de WL. '+(data.product==='all'?'As duas entram na rodada e recebem a mesma descrição.':'Só as Páginas de '+data.product.toUpperCase()+' aparecem abaixo e entram na rodada. Confira se a descrição é a desse produto.');
    $('#inactive-summary').textContent=(data.inactiveCount||0)+' Página(s) inativa(s) ocultas. Nenhuma Página ou histórico foi excluído. A lista volta a incluir uma Página se ela for reativada no Miwra.';
    $('#slot-state').textContent='Slot '+(data.postingSlot||chosenSlot())+' salvo para este lote. Sem vídeo elegível ou bloqueado: pula a Página, sem trocar de slot.';
    $('#verification-state').textContent='Consulta concluída às '+new Date(data.verifiedAt).toLocaleTimeString('pt-BR')+'. A rodada verifica novamente antes de baixar.';
    renderPages();
  } catch(error) {
    rows=[];loaded=false;verifiedContext=null;renderPages();
    $('#verification-state').textContent='Verificação não concluída. Sincronize novamente; a rodada está desabilitada.';
    throw error;
  } finally {syncing=false;$('#pages').setAttribute('aria-busy','false');buttons();}
}
async function history() {
  const items=await api('history');
  const labels={sent_synced:'Postar acionado · slot marcado no Miwra',submitted:'Postar acionado · marcação no Miwra pendente',sent_pending_sync:'Postar acionado · marcação no Miwra pendente',posted:'Publicado e sincronizado',uncertain:'Conferência necessária',sending:'Conferência necessária',confirmed:'Publicado — sincronização pendente',pending_sync:'Publicado — sincronização pendente',failed:'Falhou antes de publicar',not_posted:'Conferido: não publicado',preparing:'Preparação interrompida'};
  Object.assign(labels,{views_sent:'Republicação · Postar acionado (não verificado)',views_posted:'Republicação confirmada',drive_sent:'Google Drive · Postar acionado (não verificado)',drive_posted:'Google Drive · Publicação confirmada'});
  $('#history').innerHTML=items.slice(0,100).map(item=>{
    const uncertain=['uncertain','sending'].includes(item.status);
    const pending=['confirmed','pending_sync','submitted','sent_pending_sync'].includes(item.status);
    const submitted=['submitted','sent_pending_sync','sent_synced','views_sent','drive_sent'].includes(item.status);
    return '<article class="history-row">'+(item.date?'<small>Vídeos de '+esc(item.date)+(item.publicationDate?' · Envio em '+esc(item.publicationDate):'')+(item.repost?' · Republicação':'')+'</small>':'')+'<b>'+(item.accountName?'<span class="acct-tag">'+esc(item.accountName)+'</span> ':'')+esc(item.pageName)+(Number.isInteger(item.slotIndex)?' · Slot '+(item.slotIndex+1):'')+' · '+esc(labels[item.status]||item.status)+(item.method==='api'?' · via API':'')+'</b><small>'+esc(new Date(item.at).toLocaleString('pt-BR'))+' · '+esc(item.fileName || item.jobId)+'</small>'+(submitted?'<small>Publicação no Facebook não verificada. O clique em Postar foi registrado.</small>':'')+(item.comment?'<small class="comment-state comment-'+esc(item.comment)+'">'+esc(({pinned:'Comentário publicado no Reel',pin_clicked:'Comentário publicado no Reel',commented:'Comentário publicado no Reel',failed:'Sem comentário',skipped:'Sem comentário'})[item.comment]||item.comment)+(item.commentDetail?': '+esc(item.commentDetail):'')+'</small>':'')+(item.error?'<p>'+esc(item.error)+'</p>':'')+'<div class="history-actions"><a target="_blank" rel="noreferrer" href="https://www.facebook.com/'+encodeURIComponent(item.facebookPageId)+'">Abrir Página</a>'+(item.reelId?'<a target="_blank" rel="noreferrer" href="https://www.facebook.com/reel/'+encodeURIComponent(item.reelId)+'">Abrir Reel</a>':'')+(item.hasScreenshot?'<button data-shot="'+esc(item.id)+'" type="button">Ver captura da tela</button>':'')+((uncertain||pending)?'<button data-history="'+esc(item.id)+'" data-action="sync" data-sync-only="'+pending+'">'+(uncertain?'Conferi: foi publicado':'Sincronizar Miwra')+'</button>':'')+(uncertain?'<button data-history="'+esc(item.id)+'" data-action="not_posted">Conferi: não foi publicado</button>':'')+'</div></article>';
  }).join('')||'<p class="empty">Nenhuma tentativa.</p>';
  $('#history').querySelectorAll('button').forEach(b=>b.disabled=running);
}
async function progress() {
  const data=await api('progress?'+accountParam());
  running=data.running||data.opening;anyRunning=Boolean(data.anyRunning);
  accountsRender(data.accounts||[]);
  $('#browser').textContent=data.browserOpen?'Aberto':'Fechado';
  const issues=(data.results||[]).filter(item=>['failed','uncertain','pending_sync','sent_pending_sync'].includes(item.status)).length;
  $('#run-state').textContent=data.phase==='done'&&issues?'Concluída com '+issues+' ocorrência(s)':({idle:'Aguardando',running:'Em execução',waiting:'Aguardando você',done:'Concluída',error:'Falhou',stopped:'Interrompida'})[data.phase]||data.phase;
  const others=(data.accounts||[]).filter(item=>item.running&&item.id!==currentAccount);
  $('#header-activity').textContent=running||!others.length?$('#run-state').textContent:'Em execução: '+others.map(item=>item.name).join(', ');
  $('#header-activity').dataset.running=String(running||anyRunning);$('#header-activity').dataset.offline='false';
  scheduleRender(data.scheduled);
  window.apiScheduleRender?.(data.apiScheduled);   // programações da tela Postar por API (api-post.js)
  // Botão do topo: liga sempre que há uma postagem ou um download em andamento, em qualquer tela.
  $('#stop-all').disabled=!anyRunning||stopping;$('#stop-all').textContent=stopping&&anyRunning?'Parando…':'Parar postagem';if(!anyRunning)stopping=false;
  const text=data.logs.length?data.logs.map(l=>l.at+'  '+l.message).join('\n'):'Sem atividade.';
  if($('#logs').textContent!==text){$('#logs').textContent=text;$('#logs').scrollTop=$('#logs').scrollHeight;}
  buttons();
  if(wasRunning&&!running){await history();if(!['views','drive'].includes(data.source)&&!dirty&&!importing&&!slotSaving&&!slotUnsaved&&!dateLoading)await sync(false,true).catch(e=>notice(e.message));}
  wasRunning=running;
}
function guarded(action){return async event=>{try{notice('');await action(event);}catch(error){notice(error.message);}};}
$('#save').onclick=guarded(async()=>{
  if(slotSaving||syncing||importing||running||dateLoading)throw new Error('Aguarde a operação atual terminar.');
  settings={...settings,baseUrl:$('#base-url').value.trim(),profile:$('#profile').value.trim(),cookie:$('#cookie').value,caption:$('#caption').value,captionWl:$('#caption-wl').value,pinComment:$('#pin-comment').checked,comment:$('#comment').value,commentWl:$('#comment-wl').value,commentWait:Number($('#comment-wait').value),commentScope:$('#comment-scope').value,commentMaxDays:Number($('#comment-days').value),composer:$('#composer').value,postingSlot:chosenSlot(),browser:$('#browser-mode').value,adsPowerUserId:$('#adspower-id').value.trim(),adsPowerApi:$('#adspower-api').value.trim(),adsPowerKey:$('#adspower-key').value,incognitonProfileId:$('#incogniton-id').value.trim(),incognitonApi:$('#incogniton-api').value.trim(),facebookPassword:$('#facebook-password').value,
    // "Salvar alterações" também grava o que estiver em Contas do Facebook.
    accounts:accountsDraft(),mainName:$('#main-account-name').value.trim()};
  settings=await api('settings',settings);$('#cookie').value='';$('#adspower-key').value='';$('#facebook-password').value='';browserFields();accountsEditor();accountsSig='';dirty=false;slotUnsaved=false;$('#save-state').textContent='Alterações salvas';
  $('#setup-reminder').hidden=Boolean(settings.cookieConfigured&&settings.profile);
  $('#cookie-state').textContent=settings.cookieConfigured?'Cookie salvo. Cole um novo para trocar.':'Ainda não configurado.';
  await sync();
});
$('#refresh').onclick=guarded(async()=>{if(slotSaving)throw new Error('Aguarde o slot ser salvo.');if(dirty||slotUnsaved)throw new Error('Salve suas alterações antes de sincronizar.');await sync(true);});
// Páginas com "Postar já acionado" de uma rodada interrompida: o Miwra passa o vídeo não postado para o
// dia seguinte com o mesmo lote. Depois de conferir no Facebook que nada saiu, libera em lote.
$('#release-blocked').onclick=guarded(async()=>{
  const date=$('#source-date')?.value||'';
  const check=await api('history/release',{account:currentAccount,date});
  const found=Object.entries(check.statuses||{}).map(([k,v])=>v+' '+k).join(', ');
  if(!check.count)return notice('Nada para liberar em '+accountName()+' ('+check.date+'): '+check.slotsChecked+' vídeo(s) em buffer conferidos no Miwra; tentativas no histórico com esses lotes: '+(found||'nenhuma')+'.');
  if(!confirm('Liberar '+check.pages.length+' Página(s) de '+accountName()+' para reenviar?\n\n'+check.pages.slice(0,15).join(', ')+(check.pages.length>15?'…':'')+'\n\nUse só se você conferiu que esses vídeos NÃO saíram no Facebook (rodada interrompida). Se algum saiu, ele será publicado de novo.'))return;
  const done=await api('history/release',{account:currentAccount,date,apply:true});
  notice(done.count+' tentativa(s) liberada(s). Sincronizando as Páginas…');
  await sync(true);
});
$('#import-page-ids').onclick=guarded(async()=>{
  if(slotSaving)throw new Error('Aguarde o slot ser salvo.');
  if(dirty||slotUnsaved)throw new Error('Salve suas alterações antes de buscar IDs.');
  importing=true;buttons();notice(currentAccount==='main'?'Buscando todas as Páginas acessíveis pela conexão Meta…':'Buscando os IDs das Páginas de '+accountName()+' no Miwra…');
  try {
    const result=await api('pages/import-ids',{account:currentAccount});
    settings=result.settings;
    // Conta extra: as Páginas que acabaram de ganhar ID já entram marcadas.
    const marked=currentAccount!=='main'?await selectLinked(result):0;
    $('#meta-id-results').hidden=false;$('#meta-id-results').open=result.unresolved>0;
    $('#meta-id-summary').textContent=result.metaCount+(result.source==='miwra'?' Página(s) conectada(s) no Miwra · ':result.source==='miwra+meta'?' Página(s) na Meta (e as conectadas no Miwra) · ':' Página(s) na Meta · ')+result.added+' ID(s) preenchido(s) · '+result.kept+' preservado(s) · '+result.unresolved+' para conferir';
    $('#meta-id-rows').innerHTML=result.rows.map(row=>'<div class="meta-id-row"><b>'+esc(row.name)+'</b><span>'+esc(row.facebookPageId||'Sem ID')+'</span><small>'+esc(row.message)+'</small></div>').join('')||'<p class="hint">Nenhuma Página ativa no perfil do Miwra.</p>';
    $('#save-state').textContent='IDs salvos';
    notice((result.listAdded?result.listAdded+' Página(s) nova(s) do token de '+accountName()+' entraram na lista de IDs da conta. ':'')+(marked?marked+' Página(s) com ID novo marcada(s) para as rodadas. ':'')+'Busca concluída. IDs existentes foram preservados. Confira o resultado abaixo de Páginas da rodada.');
    await sync();
  } finally {importing=false;buttons();}
});
// Configurações → Conexão com a Meta: o mesmo "Buscar IDs na Meta" da conta principal.
$('#views-import-ids').onclick=guarded(async()=>{
  const state=$('#views-ids-state'),button=$('#views-import-ids');
  if(importing||syncing)throw new Error('Aguarde a busca ou a sincronização em andamento terminar.');
  if(slotSaving)throw new Error('Aguarde o slot ser salvo.');
  if(dirty||slotUnsaved)throw new Error('Salve suas alterações antes de buscar IDs.');
  importing=true;buttons();button.disabled=true;state.hidden=false;state.textContent='Buscando na Meta as Páginas deste token…';
  try{
    const result=await api('pages/import-ids',{account:'main'});
    settings=result.settings;
    const msg=result.metaCount+' Página(s) encontrada(s) · '+result.added+' ID(s) preenchido(s) · '+result.kept+' já tinham ID · '+result.unresolved+' para conferir.';
    if(currentAccount==='main'){
      $('#meta-id-results').hidden=false;$('#meta-id-results').open=result.unresolved>0;
      $('#meta-id-summary').textContent=result.metaCount+' Página(s) na Meta · '+result.added+' ID(s) preenchido(s) · '+result.kept+' preservado(s) · '+result.unresolved+' para conferir';
      $('#meta-id-rows').innerHTML=result.rows.map(row=>'<div class="meta-id-row"><b>'+esc(row.name)+'</b><span>'+esc(row.facebookPageId||'Sem ID')+'</span><small>'+esc(row.message)+'</small></div>').join('');
    }
    state.textContent=msg+(result.unresolved?(currentAccount==='main'?' Veja quais em Publicações, abaixo de Páginas da rodada.':' Para ver quais, use "Buscar IDs na Meta" em Publicações, na aba da conta principal.'):'');
    $('#save-state').textContent='IDs salvos';
    notice('Busca de IDs concluída: '+msg);
    if(currentAccount==='main')await sync();
  }catch(error){state.textContent='Não deu para buscar os IDs: '+(error?.message||error);throw error;}
  finally{importing=false;button.disabled=false;buttons();}
});
// Dois botões, um por navegador. O escolhido fica salvo e passa a valer para as rodadas pelo Chrome.
function openFacebook(browser){return guarded(async()=>{
  if(browser==='perfil')browser=perfilExterno();
  if(PERFIS[browser]&&!perfilId(browser))throw new Error('Informe o ID do perfil do '+PERFIS[browser]+' em Configurações → Navegador e salve antes de abrir por ele.');
  notice(PERFIS[browser]?'Abrindo o perfil no '+PERFIS[browser]+' e uma aba do Facebook dentro dele…':settings.networkMode?'Abrindo o Chrome no computador servidor. Faça login naquela máquina.':'Abrindo o Chrome. Faça login na janela que aparecer.');
  running=true;buttons();
  try{const result=await api('login',{browser});settings.browser=result.browser||browser;browserChoice();}finally{await progress();}
});}
$('#login').onclick=openFacebook('chrome');$('#login-adspower').onclick=openFacebook('perfil');
$('#logout').onclick=guarded(async()=>{await api('logout',{});location.replace('/login');});
$('#search').oninput=renderPages;$('#filter').onchange=renderPages;
$('#pages').oninput=event=>{
  const input=event.target;
  if(input.matches('.page-id')){settings.mappings[input.dataset.id]=input.value.trim();setDirty();updateFilterCounts();}
};
$('#pages').onchange=event=>{
  const input=event.target;if(!input.matches('.page-check'))return;
  const selected=new Set(settings.selected);input.checked?selected.add(input.dataset.id):selected.delete(input.dataset.id);
  settings.selected=[...selected];setDirty();renderPages();
};
$('#select-all').onchange=event=>{
  const selected=new Set(settings.selected);for(const row of rows)event.target.checked?selected.add(row.id):selected.delete(row.id);
  settings.selected=[...selected];setDirty();renderPages();
};
for(const id of ['caption','caption-wl','pin-comment','comment','comment-wl','comment-wait','comment-scope','comment-days','composer'])$('#'+id).addEventListener('input',setDirty);
function browserFields(){
  $('#browser-mode').value=settings.browser||'chrome';$('#adspower-id').value=settings.adsPowerUserId||'';$('#adspower-api').value=settings.adsPowerApi||'';
  $('#incogniton-id').value=settings.incognitonProfileId||'';$('#incogniton-api').value=settings.incognitonApi||'';
  $('#adspower-key-state').textContent=settings.adsPowerKeyConfigured?'Chave salva. Deixe vazio para manter.':'Nenhuma chave salva.';
  $('#facebook-password-state').textContent=settings.facebookPasswordConfigured?'Senha salva. Deixe vazio para manter.':'Nenhuma senha salva.';
  browserChoice();
}
function browserChoice(){
  const ads=Boolean(PERFIS[settings.browser]),externo=perfilExterno();$('#browser-mode').value=ads?settings.browser:'chrome';
  $('#login-adspower').textContent='Abrir Facebook ('+PERFIS[externo]+')';
  $('#login-adspower').title='Abre o Facebook numa aba do perfil do '+PERFIS[externo]+', com o proxy dele. As rodadas pelo Chrome passam a usar esse navegador.';
  const top=$('#top-publish-ads');if(top)top.textContent=top.textContent.replace(/AdsPower|Incogniton/,PERFIS[externo]);
  $('#login').classList.toggle('chosen',!ads);$('#login-adspower').classList.toggle('chosen',ads);
  $('#login').setAttribute('aria-pressed',String(!ads));$('#login-adspower').setAttribute('aria-pressed',String(ads));
}
$('#product').addEventListener('change',guarded(async()=>{
  // Salva só o produto (como o slot) e recalcula a lista; outras alterações pendentes continuam pendentes.
  if(!compatible||running||syncing||importing||slotSaving||dateLoading){$('#product').value=settings.product||'all';return;}
  const product=$('#product').value;
  slotSaving=true;renderPages();
  try {
    const saved=await api('settings',{product});
    if(saved.product!==product)throw new Error('O servidor não confirmou o produto escolhido.');
    settings.product=saved.product;
    await sync();
  } catch(error) {
    if(settings.product!==product)$('#product').value=settings.product||'all';
    throw error;
  } finally {slotSaving=false;renderPages();}
}));
$('#posting-slot').addEventListener('change',guarded(async()=>{
  if(!compatible||running||syncing||importing||slotSaving||dateLoading)return;
  const slot=chosenSlot();
  slotSaving=true;slotUnsaved=true;renderPages();
  $('#slot-state').textContent='Salvando Slot '+slot+' automaticamente e recalculando as Páginas…';
  try {
    // Save only the slot; the rest of settings/inputs may contain unsaved drafts.
    const saved=await api('settings',{postingSlot:slot});
    if(saved.postingSlot!==slot)throw new Error('O servidor não confirmou o slot escolhido.');
    settings.postingSlot=saved.postingSlot;slotUnsaved=false;
    $('#save-state').textContent=dirty?'Alterações não salvas':'Slot '+slot+' salvo automaticamente';
    await sync();
    $('#slot-state').textContent='Slot '+slot+' salvo automaticamente. '+(dirty?'Outras alterações continuam pendentes; salve-as para liberar o lote.':'Páginas recalculadas. Somente este slot será usado; Páginas sem vídeo disponível serão puladas.');
  } catch(error) {
    $('#slot-state').textContent=slotUnsaved?'Não foi possível confirmar o salvamento do Slot '+slot+'. Selecione novamente ou clique em Salvar alterações para tentar de novo.':'Slot '+slot+' salvo, mas o diagnóstico falhou. Clique em Sincronizar para tentar de novo.';
    if(slotUnsaved)$('#save-state').textContent=dirty?'Alterações e slot pendentes':'Slot não confirmado';
    throw error;
  } finally {slotSaving=false;renderPages();}
}));
async function changeSourceDate(value) {
  $('#source-date').value=value;$('#repost-posted').checked=false;
  verifiedContext=null;renderDateState();buttons();await sync();
}
function dateBusy(){return !compatible||running||syncing||importing||slotSaving||dateLoading;}
$('#source-date').addEventListener('change',guarded(async()=>{if(!dateBusy())await changeSourceDate($('#source-date').value);}));
$('#date-previous').onclick=guarded(async()=>{
  if(dateBusy())return;
  const date=new Date(($('#source-date').value||publicationDate)+'T12:00:00Z');
  date.setUTCDate(date.getUTCDate()-1);await changeSourceDate(date.toISOString().slice(0,10));
});
$('#date-today').onclick=guarded(async()=>{
  if(dateBusy())return;
  dateLoading=true;buttons();
  try { const current=await api('settings');publicationDate=current.today;$('#source-date').max=publicationDate; }
  finally {dateLoading=false;buttons();}
  await changeSourceDate(publicationDate);
});
$('#repost-posted').addEventListener('change',guarded(async()=>{
  if(dateBusy())return;
  verifiedContext=null;renderDateState();buttons();await sync();
}));
function composerHelp(){ $('#composer-help').textContent=$('#composer').value==='facebook'?'Automático: alterna para o perfil da Página, confirma Alternar na janela do Facebook e confere a identidade antes de enviar o vídeo e postar.':'Automático: confere o ID e o nome da Página antes de postar. O Business Suite pode oferecer sugestões de marcação diferentes.'; }
$('#composer').addEventListener('change',composerHelp);
// Os botões + @seguidores e + Hashtag inserem na descrição (ED ou WL) em que o cursor esteve por último.
// Com "Todas as Páginas" o campo de dias não se aplica.
function commentScopeView(){const all=$('#comment-scope').value==='all';$('#comment-days-box').hidden=all;$('#comment-scope-help').hidden=all;}
$('#comment-scope').addEventListener('change',commentScopeView);
let captionField='caption';
for(const id of ['caption','caption-wl'])$('#'+id).addEventListener('focus',()=>{captionField=id;$('#caption-target').textContent='Os botões inserem na descrição de '+(id==='caption'?'ED':'WL')+'.';});
// Texto das duas descrições para as prévias das outras telas.
function captionSummary(ed,wl){const show=text=>text||'(sem descrição salva)';return ed===wl?'ED e WL (mesma descrição):\n'+show(ed):'ED:\n'+show(ed)+'\n\nWL:\n'+show(wl);}
function addCaptionToken(token){
  const field=$('#'+captionField), start=field.selectionStart, end=field.selectionEnd;
  const prefix=start>0&&!/\s/.test(field.value[start-1])?' ':'';
  const suffix=end<field.value.length&&!/\s/.test(field.value[end])?' ':'';
  const value=prefix+token+suffix;
  if(field.value.length-(end-start)+value.length>field.maxLength){notice('A descrição deve ter no máximo 5.000 caracteres.');return;}
  field.setRangeText(value,start,end,'end');field.setSelectionRange(start+prefix.length+token.length,start+prefix.length+token.length);field.focus();setDirty();
}
$('#add-followers').onclick=()=>addCaptionToken('@seguidores');
$('#add-hashtag').onclick=()=>addCaptionToken('#');
for(const [id,mode]of[['test','test'],['publish','publish'],['download','download']]){
  $('#'+id).onclick=guarded(async()=>{
    if(!compatible||slotSaving||syncing||importing||running||dateLoading)throw new Error('Aguarde a operação atual terminar.');
    if(dirty||slotUnsaved)throw new Error('Salve as alterações primeiro.');
    if(!loaded||rows.some(slotChanged)||!contextMatches())throw new Error('Sincronize as Páginas da data e do slot escolhidos antes de iniciar.');
    // Starting the explicitly labelled action authorizes this run; no popup.
    running=true;buttons();
    try { await api('start',{mode,...runContext(),postingSlot:chosenSlot(),product:$('#product').value,account:currentAccount}); } catch(error) { running=false;buttons();throw error; }
    wasRunning=true;
    await progress();
  });
}
$('#stop').onclick=guarded(async()=>{await api('stop',{account:currentAccount});await progress();});
// Início programado das rodadas de Publicações: até três linhas, cada uma com o seu horário e o
// seu slot. Mostra o que está marcado e o resultado da última vez de cada linha.
const SCHEDULE_TIMES=['08:00','13:00','18:00'],SCHEDULE_PRODUCTS={all:'Todos (ED + WL)',ed:'Somente ED',wl:'Somente WL'};
const SCHEDULE_NOTE=$('#schedule-note').textContent;
$('#schedule-rows').innerHTML=SCHEDULE_TIMES.map((time,index)=>{
  const row=index+1;
  return '<div class="schedule-row" data-row="'+row+'"><b class="schedule-name">Programação '+row+'</b>'
    +'<label>Horário<input class="schedule-time" type="time" value="'+time+'" aria-label="Horário da programação '+row+'"></label>'
    +'<label>Slot<select class="schedule-slot" aria-label="Slot da programação '+row+'">'+[1,2,3,4,5].map(n=>'<option value="'+n+'"'+(n===row?' selected':'')+'>Slot '+n+'</option>').join('')+'</select></label>'
    +scheduleDays.html()
    +'<button class="schedule-set" type="button">Programar</button><button class="schedule-cancel danger" type="button" hidden>Cancelar</button>'
    +'<p class="hint schedule-state" role="status">Sem programação.</p></div>';
}).join('');
let scheduleSigs={};let scheduleRows=[];let scheduleServerOk=true,scheduleStale=false;
// Cada conta do Facebook tem as suas três programações: ao trocar de aba, as linhas voltam ao padrão
// e são preenchidas com as da conta escolhida.
function scheduleReset(){
  scheduleSigs={};scheduleRows=[];
  $('#schedule-rows').querySelectorAll('.schedule-row').forEach((box,index)=>{
    box.querySelector('.schedule-time').value=SCHEDULE_TIMES[index];box.querySelector('.schedule-slot').value=String(index+1);
    box.querySelector('.schedule-cancel').hidden=true;box.querySelector('.schedule-set').textContent='Programar';scheduleDays.set(box,[]);
    const state=box.querySelector('.schedule-state');state.textContent='Sem programação.';state.classList.remove('schedule-on');box.classList.remove('on');
  });
}
function scheduleRender(info){
  if(!info?.rows)return;
  // Servidor ainda da versão anterior (programações divididas entre as contas): só a principal programa,
  // para a aba de outra conta não trocar as programações da conta principal por engano.
  scheduleServerOk='account' in info;
  if(!scheduleServerOk&&currentAccount!=='main'){if(!scheduleStale){scheduleStale=true;scheduleReset();scheduleServerOk=false;$('#schedule-note').textContent='Para programar esta conta, encerre o Autofy (botão Encerrar) e abra de novo pelo ícone: a atualização ainda não foi carregada.';}return;}
  scheduleStale=false;
  if(info.account&&info.account!==currentAccount)return;   // resposta de outra aba, chegou atrasada
  scheduleRows=info.rows;
  for(const item of info.rows){
    // Cada linha só é redesenhada quando ela mesma muda, para não desfazer o que está sendo digitado nas outras.
    const sig=JSON.stringify(item);if(scheduleSigs[item.row]===sig)continue;scheduleSigs[item.row]=sig;
    const box=$('#schedule-rows').querySelector('.schedule-row[data-row="'+item.row+'"]');if(!box)continue;
    const pending=item.pending,state=box.querySelector('.schedule-state');
    box.querySelector('.schedule-cancel').hidden=!pending;box.querySelector('.schedule-set').textContent=pending?'Trocar':'Programar';
    if(pending){box.querySelector('.schedule-time').value=pending.time;box.querySelector('.schedule-slot').value=String(pending.postingSlot);scheduleDays.set(box,pending.dates||[]);}
    state.textContent=pending
      ?(pending.repeat?'Programada em '+pending.repeat.count+' dia(s), de '+pending.repeat.first+' a '+pending.repeat.last+' · próxima ':'Programada para ')+pending.label+' · Slot '+pending.postingSlot+' · '+pending.productLabel+' · pelo '+pending.browserLabel+(pending.accountName&&(settings.accounts||[]).length?' · '+pending.accountName:'')+'.'+(pending.queued?' Esperando a operação em andamento terminar para começar.':'')
      :item.last?item.last.message:'Sem programação.';
    state.classList.toggle('schedule-on',Boolean(pending));box.classList.toggle('on',Boolean(pending));
  }
  const waiting=info.rows.filter(item=>item.pending),others=info.others||[];
  const usados=[...new Set([...waiting.map(item=>item.pending.browser),...others.flatMap(item=>item.browsers||[])].filter(browser=>PERFIS[browser]))].map(browser=>PERFIS[browser]);
  const othersText=others.length?' Outras contas: '+others.map(item=>item.name+' ('+item.count+' programada(s), a próxima '+item.next+')').join(', ')+'.':'';
  $('#schedule-note').textContent=waiting.length||others.length
    ?(waiting.length?waiting.length+' rodada(s) programada(s)'+((settings.accounts||[]).length?' de '+accountName()+'.':'.'):'Nenhuma rodada programada de '+accountName()+'.')+othersText+' Deixe o computador ligado e na tomada, com o Autofy'+(usados.length?' e o '+usados.join(' e o '):'')+' abertos. Se o computador estiver dormindo na hora, a rodada ainda começa até '+info.graceMinutes+' minutos depois. Se a rodada anterior da mesma conta ainda estiver em andamento, a seguinte começa assim que ela terminar.'
    :SCHEDULE_NOTE;
  $('#schedule-note').classList.toggle('schedule-on',waiting.length>0||others.length>0);
}
function scheduleApply(info,row){delete scheduleSigs[row];scheduleRender(info);}
$('#schedule-rows').addEventListener('click',guarded(async event=>{
  const button=event.target.closest('button'),box=button?.closest('.schedule-row');if(!box)return;
  const row=Number(box.dataset.row);
  if(button.classList.contains('schedule-cancel')){if(!scheduleServerOk&&currentAccount!=='main')throw new Error('Para mexer nas programações desta conta, encerre o Autofy e abra de novo pelo ícone.');scheduleApply(await api('schedule/cancel',{row,account:currentAccount}),row);return;}
  if(button.classList.contains('schedule-days')){await scheduleDays.pick(box,'Programação '+row+' · dias no calendário');return;}
  if(!button.classList.contains('schedule-set'))return;
  if(!scheduleServerOk&&currentAccount!=='main')throw new Error('Para programar esta conta, encerre o Autofy (botão Encerrar) e abra de novo pelo ícone.');
  if(dirty||slotUnsaved)throw new Error('Salve suas alterações antes de programar a rodada.');
  const account=currentAccount;   // as programações são da conta da aba escolhida no topo
  const time=box.querySelector('.schedule-time').value,slot=Number(box.querySelector('.schedule-slot').value),browser=account==='main'&&PERFIS[settings.browser]?settings.browser:'chrome',product=$('#product').value;
  if(!/^\d\d:\d\d$/.test(time))throw new Error('Escolha o horário da Programação '+row+'.');
  const same=scheduleRows.find(item=>item.row!==row&&item.pending&&item.pending.postingSlot===slot);
  if(!confirm('Programar a rodada de Publicações do Slot '+slot+((settings.accounts||[]).length?' da conta '+accountName(account):'')+' para começar'+scheduleDays.confirmText(scheduleDays.get(box),time)+'?\n\n'+SCHEDULE_PRODUCTS[product]+' · pelo '+(account!=='main'&&acctBrowser(account)?PERFIS[acctBrowser(account).browser]+' (perfil '+acctBrowser(account).browserProfile+')':nomeNavegador(browser))+', com os vídeos do dia em que a rodada começar.'+(same?'\n\nAtenção: a Programação '+same.row+' também está com o Slot '+slot+'. Páginas que já tiverem postado esse slot serão puladas.':'')+'\n\nNa hora ela publica de verdade, sem outra confirmação. Deixe o computador ligado e na tomada, com o Autofy'+(PERFIS[browser]?' e o '+PERFIS[browser]:'')+' abertos.'))return;
  scheduleApply(await api('schedule',{row,time,postingSlot:slot,product,browser,account,dates:scheduleDays.get(box)}),row);
}));
// Para a postagem em andamento sem fechar o painel. A Página que está no meio termina; nenhuma nova começa.
let stopping=false;
$('#stop-all').onclick=guarded(async()=>{
  if(!confirm('Parar a postagem em andamento?\n\nA Página que está sendo postada agora termina e nenhuma nova é iniciada. O painel continua aberto e você pode retomar depois: o que já foi enviado não é repetido.'))return;
  stopping=true;$('#stop-all').disabled=true;$('#stop-all').textContent='Parando…';
  try{const result=await api('stop-all',{});if(!result.stopped){stopping=false;notice('Não há postagem em andamento.');}}catch(error){stopping=false;throw error;}
  await progress();
});
$('#history-refresh').onclick=guarded(history);
// Mostra a captura da tela do navegador feita na hora da falha (fica só neste computador).
async function showShot(id){
  const response=await fetch('/api/history/screenshot?id='+encodeURIComponent(id),{headers:{'x-publisher-key':key}});
  if(!response.ok)throw new Error((await response.json().catch(()=>({}))).error||'Não foi possível abrir a captura.');
  const url=URL.createObjectURL(await response.blob()),box=document.createElement('div');
  box.className='shot-overlay';box.setAttribute('role','dialog');box.setAttribute('aria-label','Captura da tela na hora da falha');
  const image=document.createElement('img');image.src=url;image.alt='Captura da tela do navegador na hora da falha';
  const hint=document.createElement('p');hint.textContent='Clique em qualquer lugar ou aperte Esc para fechar.';
  box.append(image,hint);
  const close=()=>{box.remove();URL.revokeObjectURL(url);document.removeEventListener('keydown',onKey);};
  const onKey=event=>{if(event.key==='Escape')close();};
  box.onclick=close;document.addEventListener('keydown',onKey);document.body.append(box);
}
$('#history').onclick=guarded(async event=>{
  const shot=event.target.closest('button[data-shot]');if(shot){await showShot(shot.dataset.shot);return;}
  const button=event.target.closest('button[data-history]');if(!button)return;
  if(button.dataset.syncOnly!=='true') {
    const message=button.dataset.action==='not_posted'?'Você conferiu a Página e tem certeza de que este vídeo não foi publicado? Isso libera uma nova tentativa.':'Confirmar a publicação e atualizar somente o slot no Miwra? Nenhum vídeo será reenviado.';
    if(!confirm(message))return;
  }
  await api('resolve',{id:button.dataset.history,action:button.dataset.action});await history();await sync();
});
async function init(){
  buttons();
  settings=await api('settings');settings.mappings||={};settings.selected||=[];
  $('#logout').hidden=!settings.networkMode;$('#network-note').hidden=!settings.networkMode;
  $('#workspace-mode').textContent=settings.networkMode?'Computador servidor':'Execução local';
  $('#setup-reminder').hidden=Boolean(settings.cookieConfigured&&settings.profile);
  compatible=settings.appVersion==='2.4.6';buttons();
  if(!compatible)throw new Error('Reinicie o servidor do Autofy e atualize esta página para carregar a versão 2.4.6.');
  publicationDate=settings.today;$('#source-date').value=publicationDate;$('#source-date').max=publicationDate;$('#repost-posted').checked=false;renderDateState();
  $('#base-url').value=settings.baseUrl;$('#profile').value=settings.profile;$('#caption').value=settings.caption||'';$('#caption-wl').value=settings.captionWl||'';$('#pin-comment').checked=settings.pinComment===true;$('#comment').value=settings.comment||'';$('#comment-wl').value=settings.commentWl||'';$('#comment-wait').value=settings.commentWait||120;$('#comment-scope').value=settings.commentScope==='all'?'all':'new';$('#comment-days').value=settings.commentMaxDays||7;commentScopeView();
  $('#composer').value=settings.composer||'facebook';composerHelp();browserFields();accountsEditor();
  if(currentAccount!=='main'&&!(settings.accounts||[]).some(item=>item.id===currentAccount))currentAccount='main';
  $('#posting-slot').value=String(settings.postingSlot||1);$('#product').value=settings.product||'all';
  $('#cookie-state').textContent=settings.cookieConfigured?'Cookie salvo. Cole um novo para trocar.':'Ainda não configurado.';
  $('#setup').open=!settings.cookieConfigured||!settings.profile;
  await window.autofySetup?.start();
  if(settings.cookieConfigured&&settings.profile)await sync().catch(e=>notice(e.message));
  await history();await progress();
}
init().catch(error=>notice(error.message));
// Com a janela do painel escondida (outra aba ou minimizada), consulta a cada 6 s em vez de 1,5 s.
let progressTick=0;
setInterval(()=>{if(document.hidden&&(++progressTick%4))return;progress().catch(()=>{notice('Servidor indisponível. Confira a janela do aplicativo.');$('#header-activity').textContent='Sem conexão';$('#header-activity').dataset.offline='true';});},1500);

// Botão Encerrar: fecha o servidor, o Chrome do Autofy e esta tela.
$('#shutdown').onclick=guarded(async()=>{
  if(!confirm('Encerrar o Autofy agora?\n\nO servidor e o Chrome da automação serão fechados.'))return;
  const send=async force=>{const response=await fetch('/api/shutdown',{method:'POST',headers:{'x-publisher-key':key,'content-type':'application/json'},body:JSON.stringify({force})});return {ok:response.ok,data:await response.json().catch(()=>({}))};};
  let result=await send(false);
  if(!result.ok&&result.data.busy){
    if(!confirm('Há uma operação em andamento.\n\nEncerrar mesmo assim? Uma publicação em andamento pode ser interrompida e ficar como "conferência necessária" no histórico.'))return;
    result=await send(true);
  }
  if(!result.ok)throw new Error(result.data.error||'Não foi possível encerrar.');
  for(let id=setInterval(()=>{},1e9);id>=0;id--){clearInterval(id);clearTimeout(id);}
  document.title='Autofy encerrado';
  document.body.className='';document.body.innerHTML='<main class="shutdown-screen"><h1>Autofy encerrado</h1><p>O servidor e o Chrome da automação foram fechados. Pode fechar esta aba.</p><p>Para abrir de novo, clique no ícone Autofy.</p></main>';
  window.close();
});

// ===== Contas de Facebook =====
// Publicações mostra uma conta por vez (abas no topo). Cada conta extra posta as Páginas de outro perfil
// do Miwra no seu próprio Chrome; as rodadas de contas diferentes podem rodar ao mesmo tempo.
let accountsSig='';
function accountsRender(list){
  accountsInfo=list;accountsTokens();
  const extras=(settings.accounts||[]).length;
  $('#acct-bar').hidden=!extras;
  // Início programado: as linhas são da conta da aba escolhida.
  $('#schedule-account').textContent=extras?' · '+accountName():'';
  if(!extras)return;
  const sig=JSON.stringify([currentAccount,list.map(item=>[item.id,item.name,item.running,item.done,item.total,item.phase,item.browserOpen])]);
  if(sig!==accountsSig){
    accountsSig=sig;
    $('#acct-tabs').innerHTML=list.map(item=>'<button type="button" role="tab" data-account="'+esc(item.id)+'" aria-selected="'+(item.id===currentAccount)+'" class="acct-tab'+(item.running?' running':'')+'">'
      +'<b>'+esc(item.name)+'</b><small>'+esc(item.running?'Rodando'+(item.total?' · '+item.done+'/'+item.total:''):({done:'Rodada concluída',stopped:'Rodada interrompida',error:'Rodada com falha'})[item.phase]||'Parada')+(item.main?' · principal':'')+'</small></button>').join('');
  }
  const current=list.find(item=>item.id===currentAccount);
  $('#import-page-ids').textContent=current&&!current.main?'Buscar IDs no Miwra':'Buscar IDs na Meta';
  $('#acct-login').hidden=!current||current.main;
  const excluded=(settings.accounts||[]).map(item=>item.pageIds?.length?item.name+' ('+item.pageIds.length+' IDs)':item.profile);
  const ids=(settings.accounts||[]).find(item=>item.id===current?.id)?.pageIds?.length||0;
  $('#acct-hint').textContent=!current?'':current.main?'Conta principal: usa o navegador escolhido no topo ('+(PERFIS[settings.browser]||'Chrome')+') e o perfil "'+(settings.profile||'')+'" do Miwra'+(excluded.length?', sem as Páginas de '+excluded.join(', ')+' (que ficam com a conta delas)':'')+'.':(ids?'Divisão por ID: as '+ids+' Página(s) da lista desta conta (qualquer perfil do Miwra; precisam estar com o ID do Facebook ligado — use "Buscar IDs no Miwra"), postadas '+acctBrowserText(current.id):'Páginas do perfil "'+current.profile+'" do Miwra, postadas '+acctBrowserText(current.id))+(current.browserOpen?' (aberto)':'')+'. Na primeira vez, clique em "Abrir o Facebook desta conta" e entre com o Facebook dela.'+(current.token?.tokenConfigured?' Token da Meta: '+(current.token.user||'salvo')+'.':' Sem token da Meta: os IDs das Páginas podem ser preenchidos à mão.');
  buttons();
}
$('#acct-tabs').addEventListener('click',guarded(async event=>{
  const button=event.target.closest('button[data-account]');if(!button||button.dataset.account===currentAccount)return;
  if(syncing||importing||slotSaving||dateLoading)return;
  currentAccount=button.dataset.account;try{localStorage.setItem('jsautopost-conta',currentAccount);}catch{}
  rows=[];loaded=false;verifiedContext=null;wasRunning=false;accountsSig='';renderPages();scheduleReset();
  $('#page-info').textContent='Carregando as Páginas de '+accountName()+'…';
  await progress();
  if(settings.cookieConfigured)await sync();
}));
// Onde as rodadas pelo navegador desta conta extra abrem (escolhido em Configurações → Contas do Facebook).
function acctBrowser(id){const item=(settings.accounts||[]).find(account=>account.id===id);return item&&PERFIS[item.browser]&&item.browserProfile?item:null;}
function acctBrowserText(id){const item=acctBrowser(id);return item?'no perfil '+item.browserProfile+' do '+PERFIS[item.browser]+' desta conta':'no Chrome desta conta';}
$('#acct-login').onclick=guarded(async()=>{
  const own=acctBrowser(currentAccount);
  notice(own?'Abrindo o perfil '+own.browserProfile+' no '+PERFIS[own.browser]+' e uma aba do Facebook dentro dele. Se ainda não estiver logado, entre com o Facebook da conta '+accountName()+' nessa aba.':'Abrindo o Chrome da conta '+accountName()+'. Entre com o Facebook dela na janela que aparecer; o login fica guardado para as próximas rodadas.');
  await api('login',{account:currentAccount});await progress();
});
// Configurações → Contas do Facebook.
function accountsEditor(){
  const list=settings.accounts||[];
  $('#main-account-name').value=settings.mainName||'';$('#main-account-name').placeholder=(settings.profile&&!/[;*]/.test(settings.profile)?settings.profile:'Conta principal');
  $('#accounts-list').innerHTML=list.map((item,index)=>accountRow(item,index)).join('')||'<p class="hint">Nenhuma conta extra. A conta principal continua postando como sempre.</p>';
  $('#accounts-add').disabled=list.length>=6;
  accountsTokens();
}
function accountRow(item,index){
  return '<div class="acct-row" data-index="'+index+'"'+(item.id?' data-id="'+esc(item.id)+'"':'')+'>'
    +'<label>Nome da conta<input class="acct-name" maxlength="60" value="'+esc(item.name||'')+'" placeholder="Ex.: Facebook da Maria"></label>'
    +'<label>Perfil no Miwra<input class="acct-profile" maxlength="120" value="'+esc(item.profile||'')+'" placeholder="Nome exato do perfil no Miwra"></label>'
    +'<button class="acct-remove danger" type="button">Remover</button>'
    +acctBrowserFields(item)
    +'<label class="wide">IDs das Páginas desta conta (divisão por ID, opcional)<textarea class="acct-ids" rows="3" spellcheck="false" placeholder="Um ID do Facebook por linha. Vazio: a conta fica com todas as Páginas do perfil acima.">'+esc((item.pageIds||[]).join('\n'))+'</textarea><small class="acct-ids-state">'+((item.pageIds||[]).length?(item.pageIds.length+' ID(s). Estas Páginas ficam só com esta conta, mesmo que o Miwra as mostre em outro perfil; a conta principal fica com o resto.'):'Use quando o Miwra junta no mesmo perfil Páginas de dois Facebooks.')+'</small></label>'
    +(item.id?'<div class="actions acct-token-actions"><button class="acct-ids-fetch" type="button">Puxar IDs do token desta conta</button><button class="acct-ids-clear" type="button">Limpar lista</button></div>':'')
    +(item.id?'<label class="wide">Token de usuário da Meta desta conta<input class="acct-token" type="password" autocomplete="off" maxlength="8192" placeholder="Cole no computador servidor; vazio mantém o token salvo"><small class="acct-token-state">—</small></label>'
      +'<div class="actions acct-token-actions"><button class="acct-token-save" type="button">Salvar e validar token</button><button class="acct-token-remove" type="button">Remover token</button></div>'
      +'<label class="wide">Senha do Facebook desta conta (só para excluir Páginas)<input class="acct-pass" type="password" autocomplete="off" maxlength="200" placeholder="Vazio mantém a senha salva"><small class="acct-pass-state">—</small></label>'
      +'<div class="actions acct-token-actions"><button class="acct-pass-save" type="button">Salvar senha</button></div>':'<p class="hint wide">Salve a conta para poder cadastrar o token da Meta e a senha do Facebook dela.</p>')
    +'</div>';
}
// Navegador de cada conta extra: o Chrome próprio dela, ou um perfil do AdsPower/Incogniton só dela.
function acctBrowserFields(item){
  const browser=PERFIS[item.browser]?item.browser:'chrome';
  return '<label>Navegador desta conta<select class="acct-browser">'+[['chrome','Chrome do Autofy'],['adspower','AdsPower'],['incogniton','Incogniton']].map(([value,label])=>'<option value="'+value+'"'+(value===browser?' selected':'')+'>'+label+'</option>').join('')+'</select></label>'
    +'<label class="acct-browser-id"'+(browser==='chrome'?' hidden':'')+'>ID do perfil no <span class="acct-browser-name">'+esc(PERFIS[browser]||'AdsPower')+'</span><input class="acct-browser-profile" maxlength="64" spellcheck="false" value="'+esc(item.browserProfile||'')+'" placeholder="ID do perfil onde o Facebook desta conta está logado"></label>';
}
function accountsTokens(){
  for(const box of document.querySelectorAll('.acct-row[data-id]')){
    const info=accountsInfo.find(item=>item.id===box.dataset.id)?.token,state=box.querySelector('.acct-token-state');
    const pass=box.querySelector('.acct-pass-state');
    if(pass)pass.textContent=(settings.deletePasswordAccounts||[]).includes(box.dataset.id)?'Senha salva. Deixe vazio para manter.':'Nenhuma senha salva. Sem ela, a exclusão de Páginas desta conta não roda.';
    if(state)state.textContent=info?.tokenConfigured?'Token salvo'+(info.user?' · '+info.user:'')+'. Deixe vazio para manter.':'Sem token. Sem ele, os IDs das Páginas desta conta são preenchidos à mão e ela fica fora do Analytics e do Postar por API.';
  }
}
function accountsDraft(){
  // Linha nova deixada em branco não conta.
  return [...document.querySelectorAll('.acct-row')].map(box=>({...(box.dataset.id?{id:box.dataset.id}:{}),name:box.querySelector('.acct-name').value.trim(),profile:box.querySelector('.acct-profile').value.trim(),pageIds:(box.querySelector('.acct-ids')?.value||'').split(/[\s,;]+/).map(v=>v.trim()).filter(Boolean),browser:box.querySelector('.acct-browser')?.value||'chrome',browserProfile:box.querySelector('.acct-browser')?.value==='chrome'?'':(box.querySelector('.acct-browser-profile')?.value||'').trim()}))
    .filter(item=>item.id||item.name||item.profile);
}
$('#accounts-add').onclick=()=>{const list=accountsDraft();if(list.length>=6)return;list.push({name:'',profile:''});$('#accounts-list').innerHTML=list.map((item,index)=>accountRow(item,index)).join('');accountsTokens();$('#accounts-state').textContent='Conta nova: preencha o nome e o perfil.';};
$('#accounts-list').addEventListener('click',guarded(async event=>{
  const button=event.target.closest('button'),box=button?.closest('.acct-row');if(!box)return;
  if(button.classList.contains('acct-remove')){
    if(box.dataset.id&&!confirm('Remover a conta '+(box.querySelector('.acct-name').value||'')+'?\n\nAs Páginas do perfil dela deixam de ser postadas por este Autofy. O histórico continua guardado.'))return;
    box.remove();saveAccountsLater();return;
  }
  if(button.classList.contains('acct-pass-save')){
    const input=box.querySelector('.acct-pass');
    if(!input.value)throw new Error('Digite a senha do Facebook desta conta antes de salvar.');
    await api('pages/delete/password',{account:box.dataset.id,password:input.value});input.value='';
    settings.deletePasswordAccounts=[...new Set([...(settings.deletePasswordAccounts||[]),box.dataset.id])];accountsTokens();
    notice('Senha do Facebook de '+(box.querySelector('.acct-name').value||'esta conta')+' salva.');return;
  }
  if(button.classList.contains('acct-ids-fetch')){
    button.disabled=true;$('#accounts-state').textContent='Buscando na Meta as Páginas do token desta conta…';
    try{
      const result=await api('accounts/pages',{account:box.dataset.id});
      box.querySelector('.acct-ids').value=result.pages.map(page=>page.id).join('\n');
      box.querySelector('.acct-ids-state').textContent=result.pages.length+' Página(s) no token: '+result.pages.slice(0,6).map(page=>page.name).join(', ')+(result.pages.length>6?'…':'')+'.';
      saveAccountsLater();
    }finally{button.disabled=false;}
    return;
  }
  if(button.classList.contains('acct-ids-clear')){
    box.querySelector('.acct-ids').value='';saveAccountsLater();return;
  }
  if(button.classList.contains('acct-token-save')){
    const token=box.querySelector('.acct-token').value.trim();if(!token)throw new Error('Cole o token de usuário da Meta desta conta.');
    button.disabled=true;
    try{await api('accounts/token',{account:box.dataset.id,token});box.querySelector('.acct-token').value='';$('#accounts-state').textContent='Token validado e salvo.';await progress();accountsTokens();}
    finally{button.disabled=false;}
    return;
  }
  if(button.classList.contains('acct-token-remove')){
    if(!confirm('Remover o token da Meta desta conta?'))return;
    await api('accounts/token',{account:box.dataset.id,remove:true});await progress();accountsTokens();$('#accounts-state').textContent='Token removido.';
  }
}));
// Páginas que acabaram de ganhar o ID do Facebook entram marcadas para as rodadas.
async function selectLinked(result){
  const ids=(result.rows||[]).filter(row=>row.status==='added'&&row.id).map(row=>String(row.id));
  if(!ids.length)return 0;
  const fresh=result.settings?.selected||settings.selected||[];
  const saved=await api('settings',{selected:[...new Set([...fresh.map(String),...ids])]});
  settings.selected=saved.selected;settings.mappings=saved.mappings;
  return ids.length;
}
$('#accounts-save').onclick=guarded(async()=>{
  const before=new Map((settings.accounts||[]).map(item=>[item.id,new Set(item.pageIds||[])]));
  const saved=await api('settings',{accounts:accountsDraft(),mainName:$('#main-account-name').value.trim()});
  settings.accounts=saved.accounts;settings.mainName=saved.mainName;settings.mappings=saved.mappings;accountsEditor();
  if(currentAccount!=='main'&&!settings.accounts.some(item=>item.id===currentAccount)){currentAccount='main';rows=[];loaded=false;}
  accountsSig='';await progress();accountsTokens();
  // IDs novos na lista de uma conta: liga essas Páginas ao Miwra na hora (o mesmo "Buscar IDs no Miwra")
  // e marca as que ganharam ID, para já aparecerem em Publicações, Países e Dados das Páginas.
  let linked=0;const failed=[];
  for(const item of settings.accounts.filter(account=>before.has(account.id)&&(account.pageIds||[]).some(id=>!before.get(account.id).has(id)))){
    $('#accounts-state').textContent='Contas salvas. Ligando ao Miwra as Páginas novas de '+item.name+'…';
    try{linked+=await selectLinked(await api('pages/import-ids',{account:item.id}));}
    catch(error){failed.push(item.name+': '+error.message);}
  }
  $('#accounts-state').textContent='Contas salvas.'+(linked?' '+linked+' Página(s) nova(s) ligada(s) ao Miwra e marcada(s) para as rodadas.':'')+(failed.length?' Não deu para ligar ao Miwra agora ('+failed.join('; ')+'): use "Buscar IDs no Miwra" na aba da conta, em Publicações.':' Escolha a conta no topo de Publicações.');
  if(loaded&&currentAccount!=='main')await sync().catch(()=>{});
});
