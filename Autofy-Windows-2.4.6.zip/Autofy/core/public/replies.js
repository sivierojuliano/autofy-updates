// Tela "Mensagens automáticas" (modo API): modelo, Páginas ligadas e registro (lib/comment-replies.mjs).
// Usa api(), esc(), guarded() e notice() de app.js. Nenhum token passa por aqui.
(() => {
  const el = id => document.getElementById(id);
  const stamp = new Intl.DateTimeFormat('pt-BR', { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  const when = time => time ? stamp.format(new Date(time)).replace(', ', ' às ') : '';
  let autoTried = '';
  let report = null, list = null, loading = false, timer = null, entered = false, ticket = 0, formReady = false, dirty = false;
  let current = (() => { try { return localStorage.getItem('autofy-mensagens-conta') || ''; } catch { return ''; } })();
  const selected = new Set();
  let shown = [];

  const profiles = () => report?.profiles || [];
  const profile = () => { const all = profiles(); return all.find(item => item.account === current) || all[0] || null; };
  const record = row => report?.pages?.[row.id] || row.record || null;
  const isOn = row => Boolean(record(row)?.enabled);

  // ---------- modelo ----------
  const formRule = () => ({ name: el('rp-name').value, keywords: el('rp-keywords').value, anyComment: el('rp-any').checked, privateMessage: el('rp-private').value, publicReply: el('rp-public').value, interval: Number(el('rp-interval').value) });
  function fillForm() {
    if (!report || formReady) return;
    const rule = report.rule;
    el('rp-interval').innerHTML = report.intervals.map(min => '<option value="' + min + '">' + min + ' minutos</option>').join('');
    el('rp-name').value = rule.name; el('rp-keywords').value = rule.keywords.join('\n'); el('rp-any').checked = rule.anyComment;
    el('rp-private').value = rule.privateMessage; el('rp-public').value = rule.publicReply; el('rp-interval').value = String(rule.interval);
    formReady = true; preview();
  }
  const sample = text => String(text || '').replace(/\{nome\}/gi, 'Maria');
  function preview() {
    const rule = formRule();
    const words = rule.keywords.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
    el('rp-keywords').disabled = rule.anyComment;
    el('rp-prev-comment').textContent = rule.anyComment ? 'Que lindo! 😍' : (words[0] || 'quero');
    el('rp-prev-public').textContent = sample(rule.publicReply);
    el('rp-prev-public-wrap').hidden = !rule.publicReply.trim();
    el('rp-prev-private').textContent = sample(rule.privateMessage) || 'Sua mensagem privada aparece aqui.';
    el('rp-prev-private').classList.toggle('rp-empty', !rule.privateMessage.trim());
    el('rp-private-count').textContent = rule.privateMessage.length + ' / 1000';
    el('rp-public-count').textContent = rule.publicReply.length + ' / 500';
  }

  // ---------- abas, Páginas ----------
  function renderTabs() {
    const all = profiles(), chosen = profile();
    if (chosen) current = chosen.account;
    el('rp-acct-bar').hidden = all.length < 2;
    const on = id => Object.values(report?.pages || {}).filter(page => page.enabled && page.account === id).length;
    const tabs = all.map(item => {
      const count = on(item.account), note = !item.token ? 'Sem token da Meta' : count ? count + ' ligada(s)' : 'Token salvo';
      return '<button type="button" role="tab" data-account="' + esc(item.account) + '" aria-selected="' + (item.account === current) + '" class="acct-tab' + (item.token ? '' : ' no-token') + '"><b>' + esc(item.name) + '</b><small>' + esc(note + (item.main ? ' · principal' : '')) + '</small></button>';
    }).join('');
    if (el('rp-tabs').dataset.sig !== tabs) { el('rp-tabs').innerHTML = tabs; el('rp-tabs').dataset.sig = tabs; }
    const app = chosen?.dmApp;
    el('rp-dmapp-state').textContent = app?.tokenConfigured ? 'Token salvo' + (app.user ? ' (' + app.user + ')' : '') + '. O Auto DM desta conta usa só esse app.' : 'Usando o token normal da conta.';
    el('rp-dmapp-remove').hidden = !app?.tokenConfigured;
    el('rp-dmapp-save').textContent = app?.tokenConfigured ? 'Trocar token' : 'Salvar token';
    const missing = Boolean(chosen && !chosen.token);
    el('rp-notoken').hidden = !missing;
    if (missing) el('rp-notoken-name').textContent = chosen.name;
  }
  function situation(row) {
    const r = record(row);
    if (!r || !r.enabled) return '<span class="cr-badge">Desligada</span>' + (r?.private || r?.public ? '<small>' + esc((r.private || 0) + ' privada(s) · ' + (r.public || 0) + ' pública(s) enviadas antes') + '</small>' : '');
    const notes = ['Ligada em ' + when(r.since)];
    if (r.private || r.public) notes.push((r.private || 0) + ' privada(s) · ' + (r.public || 0) + ' pública(s)' + (r.failed ? ' · ' + r.failed + ' falha(s)' : ''));
    if (r.checkedAt) notes.push('Última leitura ' + when(r.checkedAt));
    if (r.error) notes.push('⚠ ' + r.error);
    return '<span class="cr-badge cr-applied">Ligada</span>' + notes.map(text => '<small>' + esc(text) + '</small>').join('');
  }
  function render() {
    renderTabs();
    const active = Boolean(report?.active), state = report?.state || {};
    el('rp-on').hidden = active; el('rp-off').hidden = !active; el('rp-check').hidden = !active;
    el('rp-check').disabled = Boolean(state.checking);
    const label = !report ? '—' : !active ? 'Desligado' : state.checking ? 'Lendo comentários…' : state.pausedUntil > Date.now() ? 'Pausado pela Meta' : 'Ligado';
    el('rp-state').textContent = label;
    el('rp-stat-state').textContent = label;
    el('rp-stat-pages').textContent = report ? report.enabledCount : '—';
    el('rp-stat-private').textContent = report ? report.totals.private : '—';
    el('rp-stat-public').textContent = report ? report.totals.public : '—';
    const next = active && state.nextAt && !state.checking ? ' Próxima leitura às ' + new Date(state.nextAt).toLocaleTimeString('pt-BR', { timeZone: 'America/Sao_Paulo', hour: '2-digit', minute: '2-digit' }) + '.' : '';
    el('rp-rule-status').textContent = dirty ? 'Alterações não salvas.' : active ? 'Respondendo em ' + report.enabledCount + ' Página(s).' + next : report ? 'Desligado. Salve o modelo, ligue a resposta nas Páginas e clique em Ligar respostas.' : '';
    const logs = state.logs?.length ? state.logs.map(line => line.at + '  ' + line.message).join('\n') : 'Sem atividade.';
    if (el('rp-log').textContent !== logs) { el('rp-log').textContent = logs; el('rp-log').scrollTop = el('rp-log').scrollHeight; }
    const recent = report?.recent || [];
    const cell = value => !value ? '<span class="hint">—</span>' : value === 'ok' ? '<span class="cr-badge cr-applied">Enviada</span>' : value.startsWith('skip') ? '<span class="cr-badge">Pulada</span><small>' + esc(value.slice(5)) + '</small>' : '<span class="cr-badge cr-failed">Falhou</span><small>' + esc(value.slice(5)) + '</small>';
    const recentHtml = recent.map(item => '<tr><td>' + esc(when(item.at)) + '</td><td>' + esc(item.page) + '</td><td><b>' + esc(item.who || 'Alguém') + '</b><small>' + esc(item.text) + '</small></td><td>' + cell(item.private) + '</td><td>' + cell(item.public) + '</td></tr>').join('') || '<tr><td colspan="5" class="empty">Nenhuma resposta ainda.</td></tr>';
    if (el('rp-recent').dataset.sig !== recentHtml) { el('rp-recent').innerHTML = recentHtml; el('rp-recent').dataset.sig = recentHtml; }
    const busy = loading;
    el('rp-load').disabled = busy || !profile()?.token;
    const rows = list?.rows || [], marked = rows.filter(row => selected.has(row.id));
    el('rp-enable').disabled = busy || !marked.length; el('rp-disable').disabled = busy || !marked.length;
    el('rp-enable').textContent = 'Ligar nas marcadas' + (marked.length ? ' (' + marked.length + ')' : '');
    if (!list) return;
    const show = el('rp-show').value, product = el('rp-product').value, search = el('rp-search').value.trim().toLocaleLowerCase('pt-BR');
    const wanted = { active: row => list.miwraMissing || row.miwra?.active, all: () => true, on: isOn, off: row => !isOn(row) }[show];
    shown = rows.filter(row => wanted(row) && (product === 'all' || row.miwra?.product === product) && (!search || row.name.toLocaleLowerCase('pt-BR').includes(search) || row.id.includes(search)));
    el('rp-summary').textContent = 'Exibindo ' + shown.length + ' de ' + rows.length + ' Página(s) do token de ' + list.accountName + ' · ' + rows.filter(isOn).length + ' ligada(s) · ' + marked.length + ' marcada(s).';
    el('rp-select-all').checked = shown.length > 0 && shown.every(row => selected.has(row.id));
    const html = shown.map(row => '<tr>'
      + '<td class="cr-pick"><input type="checkbox" data-id="' + esc(row.id) + '"' + (selected.has(row.id) ? ' checked' : '') + ' aria-label="Marcar ' + esc(row.name) + '"></td>'
      + '<td>' + (row.miwra ? '<span class="product-tag product-' + esc(row.miwra.product) + '">' + esc(row.miwra.product.toUpperCase()) + '</span> ' : '') + esc(row.name)
        + '<small>Facebook ' + esc(row.id) + '</small><small><a href="https://www.facebook.com/' + esc(row.id) + '" target="_blank" rel="noopener noreferrer">Abrir Página</a></small></td>'
      + '<td>' + (row.miwra ? (row.miwra.active ? 'Ativa' : 'Inativa') : 'Fora do Miwra') + '</td>'
      + '<td>' + situation(row) + '</td></tr>').join('') || '<tr><td colspan="4" class="empty">Nenhuma Página neste filtro.</td></tr>';
    if (el('rp-rows').dataset.sig !== html) { el('rp-rows').innerHTML = html; el('rp-rows').dataset.sig = html; }
  }
  async function refresh() {
    report = await api('replies'); fillForm(); render();
    // Token salvo depois de abrir a tela: carrega as Páginas sozinho, sem precisar recarregar.
    if (location.hash === '#mensagens' && !list && !loading && profile()?.token && entered && autoTried !== current) (autoTried = current, load()).catch(error => notice(error.message));
    clearTimeout(timer);
    if (location.hash === '#mensagens') timer = setTimeout(() => refresh().catch(() => {}), report.state.checking ? 2000 : 8000);
  }
  async function load() {
    if (!profile()?.token) { list = null; render(); return; }
    const mine = ++ticket; loading = true; render();
    el('rp-status').textContent = 'Lendo as Páginas no token da Meta (pode levar até 1 minuto)…'; el('rp-warning').hidden = true;
    try {
      const asked = current;
      const fresh = await api('replies/pages', { account: asked || undefined });
      if (asked !== current) return;
      list = fresh; report = { ...report, ...fresh };
      if (list.miwraMissing && el('rp-show').value === 'active') el('rp-show').value = 'all';
      for (const id of [...selected]) if (!list.rows.some(row => row.id === id)) selected.delete(id);
      el('rp-status').textContent = list.rows.length + ' Página(s) no token ' + (list.separateApp ? 'do app do Auto DM' : 'de ' + list.accountName) + ', ' + list.rows.filter(isOn).length + ' com resposta ligada.';
      const warn = [];
      if (list.missingPermissions?.length) warn.push((list.separateApp ? 'O token do app do Auto DM não tem: ' : 'O token desta conta não tem: ') + list.missingPermissions.join(', ') + '. Sem elas a Meta recusa ler os comentários ou mandar a mensagem. Gere o token de novo marcando também essas permissões' + (list.separateApp ? ' e salve no campo do app do Auto DM.' : ' (além das que você já usa) e salve em Configurações.'));
      if (list.miwraMissing) warn.push('O Miwra não respondeu a tempo: a lista mostra todas as Páginas do token.');
      el('rp-warning').textContent = warn.join(' '); el('rp-warning').hidden = !warn.length;
    } finally { if (mine === ticket) loading = false; render(); }
  }
  const markForm = () => { dirty = true; preview(); render(); };
  for (const id of ['rp-name', 'rp-keywords', 'rp-private', 'rp-public']) el(id).addEventListener('input', markForm);
  for (const id of ['rp-any', 'rp-interval']) el(id).addEventListener('change', markForm);
  async function saveRule() { report = await api('replies/rule', formRule()); dirty = false; render(); }
  el('rp-save').onclick = guarded(async () => { await saveRule(); notice('Modelo salvo.'); });
  el('rp-on').onclick = guarded(async () => {
    if (dirty) await saveRule();
    if (!confirm('Ligar as respostas automáticas em ' + report.enabledCount + ' Página(s)?\n\nA partir de agora, cada comentário novo com as palavras-chave recebe ' + [report.rule.privateMessage ? 'a mensagem privada' : '', report.rule.publicReply ? 'a resposta pública' : ''].filter(Boolean).join(' e ') + '. Comentários antigos não recebem nada.\n\nO Autofy lê os comentários a cada ' + report.rule.interval + ' minutos enquanto estiver aberto.')) return;
    report = await api('replies/active', { active: true }); render(); clearTimeout(timer); timer = setTimeout(() => refresh().catch(() => {}), 2500);
  });
  el('rp-off').onclick = guarded(async () => { report = await api('replies/active', { active: false }); render(); });
  el('rp-check').onclick = guarded(async () => { report = await api('replies/check', {}); render(); clearTimeout(timer); timer = setTimeout(() => refresh().catch(() => {}), 2000); });
  el('rp-load').onclick = guarded(load);
  // Token do app separado do Auto DM: vai direto para o Autofy deste computador e não volta para a tela.
  async function afterToken(fresh) {
    report = fresh; list = null; selected.clear(); el('rp-dmapp-token').value = ''; render();
    if (profile()?.token) await load();
  }
  el('rp-dmapp-save').onclick = guarded(async () => {
    const token = el('rp-dmapp-token').value.trim();
    if (!token) throw new Error('Cole o token do app do Auto DM.');
    await afterToken(await api('replies/token', { account: profile()?.account, token }));
    notice('Token do Auto DM salvo. A partir de agora o Auto DM desta conta usa esse app.');
  });
  el('rp-dmapp-remove').onclick = guarded(async () => {
    if (!confirm('Remover o token do app do Auto DM desta conta?\n\nO Auto DM volta a usar o token normal da conta (o mesmo app da postagem).')) return;
    await afterToken(await api('replies/token', { account: profile()?.account, remove: true }));
    notice('Token do Auto DM removido. Voltou a usar o token normal.');
  });
  async function setPages(enabled) {
    const rows = (list?.rows || []).filter(row => selected.has(row.id));
    if (!rows.length) throw new Error('Marque pelo menos uma Página.');
    if (enabled && !confirm('Ligar a resposta automática em ' + rows.length + ' Página(s)?\n\n' + rows.slice(0, 10).map(row => row.name).join(', ') + (rows.length > 10 ? '…' : '') + '\n\nSó comentários feitos a partir de agora contam.' + (report.active ? '' : '\n\nDepois clique em "Ligar respostas" no topo para começar.'))) return;
    report = await api('replies/enable', { account: list.account, ids: rows.map(row => row.id), enabled, names: Object.fromEntries(rows.map(row => [row.id, row.name])) });
    selected.clear(); render();
  }
  el('rp-enable').onclick = guarded(() => setPages(true));
  el('rp-disable').onclick = guarded(() => setPages(false));
  el('rp-tabs').addEventListener('click', guarded(async event => {
    const button = event.target.closest('button[data-account]');
    if (!button || button.dataset.account === current) return;
    current = button.dataset.account; try { localStorage.setItem('autofy-mensagens-conta', current); } catch {}
    list = null; selected.clear(); el('rp-warning').hidden = true;
    el('rp-rows').innerHTML = '<tr><td colspan="4" class="empty">Nada carregado ainda.</td></tr>'; el('rp-rows').dataset.sig = '';
    el('rp-status').textContent = 'Clique em Carregar Páginas para ver as Páginas do token da Meta.';
    render();
    if (profile()?.token) await load();
  }));
  for (const id of ['rp-show', 'rp-product']) el(id).addEventListener('change', render);
  el('rp-search').addEventListener('input', render);
  el('rp-rows').addEventListener('change', event => { const box = event.target.closest('input[data-id]'); if (!box) return; box.checked ? selected.add(box.dataset.id) : selected.delete(box.dataset.id); render(); });
  el('rp-select-all').addEventListener('change', event => { for (const row of shown) event.target.checked ? selected.add(row.id) : selected.delete(row.id); render(); });
  async function enter() {
    if (location.hash !== '#mensagens') { clearTimeout(timer); return; }
    await refresh();
    if (!entered) { entered = true; if (profile()?.token) { autoTried = current; await load(); } }
  }
  window.addEventListener('hashchange', () => enter().catch(error => notice(error.message)));
  enter().catch(error => notice(error.message));
})();
