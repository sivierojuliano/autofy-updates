// Conta do Autofy dentro do painel (completo e Simples): botão "Sair da conta", aviso de versão nova
// ou de modo offline, e volta para a tela de entrar se a conta deixar de valer (suspensa, expirada…).
(() => {
  const logout = document.querySelector('#account-logout'), banner = document.querySelector('#version-banner');
  const post = async path => {
    // Sem resposta nenhuma (o navegador diz "Failed to fetch"): o Autofy foi fechado com a aba aberta.
    const response = await fetch('/conta/' + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' })
      .catch(() => { throw new Error('O Autofy está fechado ou parou de responder. Feche esta aba, abra o Autofy pelo ícone e tente de novo.'); });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Falha na comunicação com o Autofy.');
    return data;
  };
  let state = null;
  const render = next => {
    state = next;
    if (logout) logout.title = 'Conectado como ' + next.email + '. Sai da conta do Autofy neste computador.';
    if (!banner) return;
    const text = banner.querySelector('span'), button = banner.querySelector('button');
    const v = next.versions || {};
    if (next.offline) {
      text.textContent = 'Modo offline: o Autofy não conseguiu conferir sua conta. Conecte à internet; depois de 48 horas sem conferir, ele pede para entrar de novo.';
      button.hidden = true;
    } else if (v.newer) {
      const ready = next.canUpdate && next.updateAvailable;
      text.textContent = 'Autofy ' + v.current + ' disponível (você está na ' + v.local + ').' + (ready ? '' : ' O botão de atualizar aparece aqui assim que o pacote estiver pronto.');
      button.hidden = !ready;
    }
    banner.hidden = !(next.offline || v.newer);
  };
  const check = async () => {
    try {
      const response = await fetch('/conta/estado', { cache: 'no-store' });
      if (!response.ok) return;
      const next = await response.json();
      if (!next.allowed) return location.replace('/entrar');
      render(next);
    } catch { /* servidor fechado: o painel já mostra o aviso dele */ }
  };
  banner?.querySelector('button')?.addEventListener('click', async event => {
    const v = state?.versions || {}, button = event.currentTarget;
    if (!confirm('Atualizar o Autofy para a versão ' + v.current + '?\n\nO Autofy baixa a versão nova, confere os arquivos e reabre sozinho em alguns segundos. Contas, tokens e configurações continuam salvos.')) return;
    button.disabled = true; button.textContent = 'Baixando…';
    try {
      const result = await post('atualizar');
      document.body.className = '';
      const main = document.createElement('main');
      main.className = 'shutdown-screen';
      for (const [tag, text] of [['h1', 'Autofy atualizado para ' + result.version], ['p', 'O Autofy está reabrindo e o painel novo abre sozinho em uma nova aba em alguns segundos. Pode fechar esta.'], ['p', 'Se não abrir em 1 minuto, clique no ícone Autofy.']]) {
        main.append(Object.assign(document.createElement(tag), { textContent: text }));
      }
      document.body.replaceChildren(main);
    } catch (error) { alert('Não foi possível atualizar agora.\n\n' + error.message); button.disabled = false; button.textContent = 'Atualizar'; }
  });
  logout?.addEventListener('click', async () => {
    if (!confirm('Sair da conta do Autofy neste computador?\n\nAs programações, a caixa de comandos e o Auto DM param até alguém entrar de novo. Uma rodada em andamento termina normalmente.')) return;
    logout.disabled = true;
    try { await post('sair'); location.replace('/entrar'); }
    catch (error) { alert(error.message); logout.disabled = false; }
  });
  check();
  setInterval(check, 5 * 60 * 1000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) check(); });
})();
