// Configurações > Controle pelo celular: liga e desliga as duas opções (salvam na hora).
(() => {
  const ver = document.querySelector('#celular-ver'), iniciar = document.querySelector('#celular-iniciar');
  if (!ver || !iniciar) return;
  const key = document.querySelector('meta[name=publisher-key]').content;
  const state = document.querySelector('#celular-state'), tag = document.querySelector('#tag-celular');
  const call = async body => {
    const response = await fetch('/api/celular', { method: body ? 'POST' : 'GET', headers: { 'x-publisher-key': key, 'content-type': 'application/json' }, ...(body ? { body: JSON.stringify(body) } : {}) })
      .catch(() => { throw new Error('O Autofy está fechado ou parou de responder. Feche esta aba, abra o Autofy pelo ícone e tente de novo.'); });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Falha na comunicação com o Autofy.');
    return data;
  };
  const render = report => {
    ver.checked = report.ver; iniciar.checked = report.iniciar; iniciar.disabled = !report.ver;
    if (tag) tag.textContent = report.ver ? (report.iniciar ? 'ligado (completo)' : 'ligado (ver e parar)') : 'desligado';
    state.textContent = !report.ver ? 'Desligado: o celular não vê nem controla este Autofy.'
      : report.conectado ? 'Conectado. Último contato com o celular às ' + new Date(report.ultimoContato).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) + '.'
      : report.erro ? 'Ligado, mas sem conexão agora: ' + report.erro + ' O Autofy tenta de novo sozinho.'
      : 'Ligado. Conectando…';
  };
  const save = async () => {
    ver.disabled = iniciar.disabled = true;
    try { render(await call({ ver: ver.checked, iniciar: ver.checked && iniciar.checked })); }
    catch (error) { alert(error.message); refresh(); }
    finally { ver.disabled = false; iniciar.disabled = !ver.checked; }
  };
  const refresh = () => call().then(render).catch(() => {});
  ver.addEventListener('change', save);
  iniciar.addEventListener('change', () => {
    if (iniciar.checked && !confirm('Ligar "Iniciar e programar pelo celular"?\n\nQuem entrar na sua conta no celular poderá iniciar rodadas e programar postagens neste computador. Use uma senha forte e não a compartilhe.')) { iniciar.checked = false; return; }
    save();
  });
  refresh();
  setInterval(() => { if (!document.hidden) refresh(); }, 15_000);
})();
