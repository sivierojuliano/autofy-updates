(() => {
  const screens = {
    publicacoes: { title: 'Publicações', description: 'Prepare o conteúdo, escolha as Páginas e acompanhe sua rodada.', icon: 'grid' },
    api: { title: 'Postar por API', description: 'Publique a rodada direto pela API da Meta, sem abrir o Chrome. Usa a data, o slot e as Páginas da tela Publicações, com descrição e comentário próprios.', icon: 'bolt' },
    melhores: { title: 'Melhores vídeos', description: 'Os 3 vídeos com mais plays de cada Página no período que você escolher, só os que passaram de 1.500 plays (dados do Analytics do Miwra). Marque o lote e poste.', icon: 'star' },
    views: { title: 'Views dos vídeos', description: 'Acompanhe as visualizações de todos os vídeos das suas Páginas.', icon: 'chart' },
    analytics: { title: 'Analytics', description: 'Plays de todos os Reels das suas Páginas, coletados de hora em hora pela API da Meta. Compare 24h, 48h, 7 dias e 30 dias e veja quais Páginas estão entregando.', icon: 'bars' },
    gestao: { title: 'Gestão de Páginas', description: 'Todo dia, as Páginas ativas que ficaram abaixo do limite de plays no período (Analytics do Miwra), com o histórico de cada dia, para você decidir quais excluir.', icon: 'trend-down' },
    paises: { title: 'Países das Páginas', description: 'Escolha em quais países as suas Páginas aparecem (Estados Unidos, Canadá, Reino Unido, Austrália, Nova Zelândia) e aplique em todas de uma vez pela API da Meta.', icon: 'globe' },
    mensagens: { title: 'Mensagens automáticas', description: 'Responda automaticamente quem comenta nas suas Páginas: mensagem privada no Messenger e resposta pública, pela API da Meta.', icon: 'chat' },
    avatares: { title: 'Avatares', description: 'Bancos de imagens para a foto de perfil e a foto de capa das Páginas, sorteadas e aplicadas pela API da Meta.', icon: 'avatar' },
    dados: { title: 'Customizar páginas', description: 'Banco de descrições e cidades: cada Página recebe uma descrição e uma cidade sorteadas, gravadas pela API da Meta numa fila com limite por dia.', icon: 'idcard' },
    drive: { title: 'Google Drive', description: 'Distribua vídeos da pasta entre suas Páginas, um por Página em cada lote.', icon: 'drive' },
    idade: { title: 'Idade das Páginas', description: 'Veja há quanto tempo cada Página foi criada e quais ainda estão abaixo do limite de dias.', icon: 'clock' },
    excluir: { title: 'Excluir Páginas', description: 'Exclua no Facebook, em lote, as Páginas que ficaram fora do quadro do Miwra. Uma por vez pelo navegador da conta principal.', icon: 'trash' },
    historico: { title: 'Histórico', description: 'Consulte os envios e confira as pendências de publicação.', icon: 'history' },
    configuracoes: { title: 'Configurações', description: 'Gerencie as conexões e credenciais do seu workspace.', icon: 'settings' },
  };
  const el = id => document.getElementById(id);
  const sidebar = el('app-sidebar'), workspace = el('app-workspace');
  const toggle = el('menu-toggle'), close = el('menu-close'), backdrop = el('menu-backdrop');
  const links = [...document.querySelectorAll('[data-view]')];
  const panels = [...document.querySelectorAll('[data-screen]')];
  const narrow = window.matchMedia('(max-width:960px)');
  let opened = false;
  // Desktop: menu flutuante que pode ser escondido na lateral (lembrado por navegador).
  const collapseBtn = el('menu-collapse'), expandBtn = el('menu-expand');
  let collapsed = false;
  try { collapsed = localStorage.getItem('autofy-menu-escondido') === '1'; } catch {}
  function applyCollapsed(focus = false) {
    const on = collapsed && !narrow.matches;
    document.body.classList.toggle('sidebar-collapsed', on);
    expandBtn.hidden = !on;
    collapseBtn.setAttribute('aria-expanded', String(!on)); expandBtn.setAttribute('aria-expanded', String(!on));
    if (!narrow.matches) sidebar.inert = on;
    if (focus) (on ? expandBtn : collapseBtn).focus();
  }
  function setCollapsed(value) {
    collapsed = value;
    try { localStorage.setItem('autofy-menu-escondido', value ? '1' : '0'); } catch {}
    applyCollapsed(true);
  }
  collapseBtn.addEventListener('click', () => setCollapsed(true));
  expandBtn.addEventListener('click', () => setCollapsed(false));
  function menu(value, restoreFocus = false) {
    opened = value && narrow.matches;
    document.body.classList.toggle('sidebar-open', opened);
    toggle.setAttribute('aria-expanded', String(opened));
    backdrop.hidden = !opened; workspace.inert = opened;
    sidebar.inert = narrow.matches ? !opened : collapsed;
    if (opened) close.focus();
    else if (restoreFocus && narrow.matches) toggle.focus();
  }
  function navigate(focus = false) {
    const requested = location.hash.slice(1);
    const name = Object.hasOwn(screens, requested) ? requested : 'publicacoes';
    const screen = screens[name];
    for (const panel of panels) panel.hidden = panel.dataset.screen !== name;
    for (const link of links) {
      const active = link.dataset.view === name;
      link.classList.toggle('active', active);
      if (active) link.setAttribute('aria-current', 'page'); else link.removeAttribute('aria-current');
    }
    el('screen-title').textContent = screen.title;
    el('breadcrumb-title').textContent = screen.title;
    el('screen-description').textContent = screen.description;
    el('header-icon').querySelector('use').setAttribute('href', '#icon-' + screen.icon);
    el('publisher-save').hidden = name !== 'publicacoes';
    document.title = screen.title + ' · Autofy';
    menu(false);
    if (focus) { el('screen-title').focus({ preventScroll: true }); window.scrollTo({ top: 0, behavior: 'instant' }); }
    // Hiding a panel never unmounts inputs, restarts workers or sends API commands.
  }
  toggle.addEventListener('click', () => menu(!opened, opened));
  close.addEventListener('click', () => menu(false, true));
  backdrop.addEventListener('click', () => menu(false, true));
  document.querySelector('.skip-link').addEventListener('click', event => {
    event.preventDefault();
    menu(false);
    el('content-start').focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: 'instant' });
  });
  for (const link of links) link.addEventListener('click', () => { if (link.hash === location.hash) navigate(true); });
  document.addEventListener('keydown', event => {
    if (!opened) return;
    if (event.key === 'Escape') { event.preventDefault(); menu(false, true); }
    if (event.key === 'Tab') {
      const focusable = [...sidebar.querySelectorAll('a[href],button:not(:disabled)')];
      const first = focusable[0], last = focusable.at(-1);
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  window.addEventListener('hashchange', () => navigate(true));
  narrow.addEventListener('change', () => { menu(false); applyCollapsed(); });
  document.addEventListener('keydown', event => {
    if ((event.metaKey || event.ctrlKey) && event.key === '\\' && !narrow.matches) { event.preventDefault(); setCollapsed(!collapsed); }
  });
  applyCollapsed();
  navigate();
})();
